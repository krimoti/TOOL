'use strict';
/* SERVICE: BOM generation */


function generateBOM(){
  var added=0;
  S.elements.forEach(function(el){
    if(el.kind!=="connector")return;
    var lib=CL[el.connId]; if(!lib)return;
    var dup=false;
    S.bomItems.forEach(function(b){if(b.pn===(lib.pn||lib.id)||b.desc===lib.name)dup=true;});
    if(!dup){S.bomItems.push({id:uid(),qty:1,unit:"EA",pn:lib.pn||lib.id,desc:lib.name,cat:"PURCHASED"});added++;}
  });
  var gMap={};
  S.wires.forEach(function(w){if(w.active!==false&&w.gauge)gMap[w.gauge]=(gMap[w.gauge]||0)+1;});
  Object.keys(gMap).forEach(function(g){
    var dup=false;
    S.bomItems.forEach(function(b){if(b.desc&&b.desc.indexOf("wire "+g)>-1)dup=true;});
    if(!dup){S.bomItems.push({id:uid(),qty:Math.ceil(S.cableLength/1000*gMap[g]*1.15*10)/10,unit:"M",pn:"",desc:"Hook-up wire "+g+" x"+gMap[g],cat:"MATERIAL"});added++;}
  });
  if(!added){toast("BOM already up to date");return;}
  saveState();renderBOM();toast("Added "+added+" items to BOM");
}
function addBOM(){S.bomItems.push({id:uid(),qty:1,unit:"EA",pn:"",desc:"",cat:"MATERIAL"});renderAll();}
function delBOM(id){S.bomItems=S.bomItems.filter(function(b){return b.id!==id;});renderAll();}
