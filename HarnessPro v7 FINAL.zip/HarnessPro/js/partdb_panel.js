/* MOTI HarnessPro — Part DB Panel */


/* ============================================================
   PARTDB_PANEL.JS — Part Database UI panel
   MOTI HarnessPro
   ============================================================ */
function renderPartDB() {
  var panel = document.getElementById('panel-partdb');
  if(!panel) return;

  var h = '<div style="display:grid;grid-template-columns:1fr 320px;height:100%;overflow:hidden">';

  /* ── Left: parts table ── */
  h += '<div style="display:flex;flex-direction:column;overflow:hidden;border-right:1px solid var(--border2)">';
  h += '<div style="padding:10px 14px 8px;background:var(--bg1);border-bottom:1px solid var(--border);flex-shrink:0;display:flex;gap:8px;align-items:center">';
  h += '<span style="font-size:10px;color:var(--accent);letter-spacing:2px">PART DATABASE</span>';
  h += '<span style="color:var(--text3);font-size:8px">'+(PART_DB.parts.length)+' parts</span>';
  h += '<span style="flex:1"></span>';
  h += '<input id="pdb-search" placeholder="Search P/N or description…" style="background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:3px 8px;font-size:9px;width:200px;font-family:monospace" oninput="pdbFilter()">';
  h += '<button class="btn btn-g" onclick="pdbAddPart()">+ ADD</button>';
  h += '<button class="btn" onclick="document.getElementById(\'pdb-import-json\').click()">⬆ JSON</button>';
  h += '<input id="pdb-import-json" type="file" accept=".json" style="display:none" onchange="pdbImportJSON(this)">';
  h += '<button class="btn" onclick="document.getElementById(\'pdb-import-csv\').click()">⬆ CSV</button>';
  h += '<input id="pdb-import-csv" type="file" accept=".csv,.txt" style="display:none" onchange="pdbImportCSV(this)">';
  h += '<button class="btn" onclick="pdbExport()">⬇ EXPORT</button>';
  h += '</div>';

  h += '<div style="flex:1;overflow:auto;padding:0">';
  h += '<table class="rt" id="pdb-table"><thead><tr>';
  h += '<th>PART NUMBER</th><th>DESCRIPTION</th><th>CAT</th><th>UNIT</th><th>STANDARD</th><th>USE</th><th>DEL</th>';
  h += '</tr></thead><tbody id="pdb-tbody">';
  h += _pdbRows(PART_DB.parts);
  h += '</tbody></table></div></div>';

  /* ── Right: part editor ── */
  h += '<div id="pdb-editor" style="background:var(--bg0);display:flex;flex-direction:column;overflow:auto">';
  h += '<div style="padding:12px 14px 8px;border-bottom:1px solid var(--border);flex-shrink:0">';
  h += '<span style="font-size:10px;color:var(--accent);letter-spacing:2px">PART EDITOR</span></div>';
  h += '<div style="padding:14px;color:var(--text3);font-size:9px">Select a part to edit, or click + ADD</div>';
  h += '</div>';

  h += '</div>';
  panel.innerHTML = h;
}

function _pdbRows(parts) {
  var fi = 'background:var(--bg1);border:1px solid var(--border);color:var(--accent);padding:2px 4px;font-size:8px;font-family:monospace';
  var h = '';
  parts.forEach(function(p, i){
    h += '<tr onclick="pdbSelectPart(\''+esc(p.pn)+'\')" style="cursor:pointer">';
    h += '<td style="font-weight:bold;color:var(--accent3)">'+esc(p.pn)+'</td>';
    h += '<td>'+esc(p.desc)+'</td>';
    h += '<td><span style="font-size:7px;padding:1px 5px;background:var(--bg3);color:var(--text2);border-radius:8px">'+esc(p.cat||'')+'</span></td>';
    h += '<td style="text-align:center;color:var(--text2)">'+esc(p.unit||'EA')+'</td>';
    h += '<td style="color:var(--text3);font-size:8px">'+esc(p.std||'')+'</td>';
    h += '<td style="text-align:center"><button class="btn btn-g" style="padding:2px 6px;font-size:7px" onclick="event.stopPropagation();pdbUsePart(\''+esc(p.pn)+'\')">+ BOM</button></td>';
    h += '<td style="text-align:center"><button class="del" onclick="event.stopPropagation();pdbDelPart(\''+esc(p.pn)+'\')">&#215;</button></td>';
    h += '</tr>';
  });
  if(!parts.length) h += '<tr><td colspan="7" style="padding:20px;text-align:center;color:var(--text3)">No parts found</td></tr>';
  return h;
}

function pdbFilter() {
  var q = document.getElementById('pdb-search');
  var tbody = document.getElementById('pdb-tbody');
  if(!q||!tbody) return;
  tbody.innerHTML = _pdbRows(partDBSearch(q.value));
}

function pdbSelectPart(pn) {
  var part = null;
  PART_DB.parts.forEach(function(p){ if(p.pn===pn) part=p; });
  if(!part) return;

  var cats = ['CONNECTOR','WIRE','SLEEVE','HEATSHRINK','TERMINAL','HARDWARE','MATERIAL','OTHER'];
  var fi = 'background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:4px 6px;font-size:9px;width:100%;font-family:monospace;box-sizing:border-box';
  var ed = document.getElementById('pdb-editor');
  if(!ed) return;

  ed.innerHTML = '<div style="padding:12px 14px 8px;border-bottom:1px solid var(--border);flex-shrink:0;display:flex;justify-content:space-between;align-items:center">'
    +'<span style="font-size:10px;color:var(--accent);letter-spacing:2px">EDIT PART</span>'
    +'<button class="btn btn-g" onclick="pdbSaveSelected()" style="padding:3px 10px">💾 SAVE</button>'
    +'</div>'
    +'<div style="padding:14px">'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">PART NUMBER</div>'
    +'<input id="ped-pn" value="'+esc(part.pn)+'" style="'+fi+'"/></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">DESCRIPTION</div>'
    +'<input id="ped-desc" value="'+esc(part.desc||'')+'" style="'+fi+'"/></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">CATEGORY</div>'
    +'<select id="ped-cat" style="'+fi+'">'
    +cats.map(function(c){return '<option'+(part.cat===c?' selected':'')+'>'+c+'</option>';}).join('')
    +'</select></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">UNIT</div>'
    +'<select id="ped-unit" style="'+fi+'">'
    +['EA','M','FT','KG','SET','LOT'].map(function(u){return '<option'+(part.unit===u?' selected':'')+'>'+u+'</option>';}).join('')
    +'</select></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">STANDARD / SPEC</div>'
    +'<input id="ped-std" value="'+esc(part.std||'')+'" placeholder="e.g. MIL-C-24308, UL1007" style="'+fi+'"/></div>'
    +'<div><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">NOTES</div>'
    +'<textarea id="ped-notes" rows="3" style="'+fi+';resize:vertical">'+esc(part.notes||'')+'</textarea></div>'
    +'<div style="margin-top:4px"><input type="hidden" id="ped-orig-pn" value="'+esc(part.pn)+'"></div>'
    +'</div>';
}

function pdbSaveSelected() {
  var origPn = document.getElementById('ped-orig-pn');
  if(!origPn) return;
  var pn   = document.getElementById('ped-pn').value.trim();
  var desc = document.getElementById('ped-desc').value.trim();
  var cat  = document.getElementById('ped-cat').value;
  var unit = document.getElementById('ped-unit').value;
  var std  = document.getElementById('ped-std').value.trim();
  var notes= document.getElementById('ped-notes').value.trim();
  if(!pn) { toast('Part number required', true); return; }

  var found = false;
  PART_DB.parts.forEach(function(p){
    if(p.pn === origPn.value) { p.pn=pn; p.desc=desc; p.cat=cat; p.unit=unit; p.std=std; p.notes=notes; found=true; }
  });
  if(!found) PART_DB.parts.push({pn:pn,desc:desc,cat:cat,unit:unit,std:std,notes:notes});
  partDBSave();
  renderPartDB();
  toast('Part saved: '+pn);
}

function pdbAddPart() {
  var newPn = 'PN-' + Date.now().toString(36).toUpperCase();
  PART_DB.parts.push({pn:newPn, desc:'New Part', cat:'MATERIAL', unit:'EA', std:'', notes:''});
  partDBSave();
  renderPartDB();
  pdbSelectPart(newPn);
}

function pdbDelPart(pn) {
  if(!confirm('Delete part '+pn+'?')) return;
  PART_DB.parts = PART_DB.parts.filter(function(p){return p.pn!==pn;});
  partDBSave();
  renderPartDB();
}

function pdbUsePart(pn) {
  var part = null;
  PART_DB.parts.forEach(function(p){ if(p.pn===pn) part=p; });
  if(!part) return;
  pushUndo();
  S.bomItems.push({id:uid(), qty:1, unit:part.unit||'EA', pn:part.pn, desc:part.desc, cat:part.cat||'PURCHASED'});
  saveState();
  toast('Added to BOM: '+pn);
}

function pdbImportJSON(input) {
  var file = input.files[0]; if(!file) return;
  var reader = new FileReader();
  reader.onload = function(ev){
    try {
      partDBImportJSON(ev.target.result);
      renderPartDB();
      toast('Imported '+PART_DB.parts.length+' parts');
    } catch(e) { toast('Import error: '+e.message, true); }
  };
  reader.readAsText(file); input.value='';
}

function pdbImportCSV(input) {
  var file = input.files[0]; if(!file) return;
  var reader = new FileReader();
  reader.onload = function(ev){
    try {
      var n = partDBImportCSV(ev.target.result);
      renderPartDB();
      toast('Imported '+n+' parts from CSV');
    } catch(e) { toast('CSV import error: '+e.message, true); }
  };
  reader.readAsText(file); input.value='';
}

function pdbExport() {
  var b = new Blob([JSON.stringify(PART_DB,null,2)],{type:'application/json'});
  var a = document.createElement('a'); a.href=URL.createObjectURL(b);
  a.download='parts_db_'+(PART_DB.company||'company')+'_'+new Date().toISOString().slice(0,10)+'.json';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('Part database exported');
}


// ════ UNDO/REDO ════
var UNDO_STACK=[], REDO_STACK=[], _undoLock=false;
function _snap(){return JSON.stringify({el:JSON.parse(JSON.stringify(S.elements)),wi:JSON.parse(JSON.stringify(S.wires)),di:JSON.parse(JSON.stringify(S.dimensions))});}
function _restore(s){var d=JSON.parse(s);S.elements=d.el;S.wires=d.wi;S.dimensions=d.di;}
function pushUndo(){if(_undoLock)return;UNDO_STACK.push(_snap());if(UNDO_STACK.length>60)UNDO_STACK.shift();REDO_STACK=[];_udUI();}
function undoAction(){if(!UNDO_STACK.length)return;REDO_STACK.push(_snap());_undoLock=true;_restore(UNDO_STACK.pop());_undoLock=false;saveState();renderAll();_udUI();toast("Undo");}
function redoAction(){if(!REDO_STACK.length)return;UNDO_STACK.push(_snap());_undoLock=true;_restore(REDO_STACK.pop());_undoLock=false;saveState();renderAll();_udUI();toast("Redo");}
function _udUI(){var u=document.getElementById("btn-undo"),r=document.getElementById("btn-redo");if(u)u.style.opacity=UNDO_STACK.length?"1":"0.35";if(r)r.style.opacity=REDO_STACK.length?"1":"0.35";}
function newProject(){if(!confirm("New project? Unsaved changes will be lost."))return;pushUndo();S.elements=[];S.wires=[];S.dimensions=[];S.bomItems=[];S.nextConnLabel=1;H.nodes=[];H.segs=[];UNDO_STACK=[];REDO_STACK=[];saveState();buildSidebar();renderAll();syncTBAll();_udUI();toast("New project");}




// ============================================================
// CONNECTOR LIBRARY (built-in, read-only)
// ============================================================
var CL = {
  "DB9M":  {id:"DB9M",  name:"D-SUB 9P Male",    short:"DB9M",  pins:9,  type:"DSUB",cat:"Serial",builtin:true,
    pinout:[{id:1,n:"DCD",sig:"RS232",g:"28AWG",c:"#e74c3c"},{id:2,n:"RXD",sig:"RS232",g:"28AWG",c:"#3498db"},
            {id:3,n:"TXD",sig:"RS232",g:"28AWG",c:"#27ae60"},{id:4,n:"DTR",sig:"RS232",g:"28AWG",c:"#f39c12"},
            {id:5,n:"GND",sig:"GND",g:"28AWG",c:"#888"},    {id:6,n:"DSR",sig:"RS232",g:"28AWG",c:"#9b59b6"},
            {id:7,n:"RTS",sig:"RS232",g:"28AWG",c:"#1abc9c"},{id:8,n:"CTS",sig:"RS232",g:"28AWG",c:"#e67e22"},
            {id:9,n:"RI",sig:"RS232",g:"28AWG",c:"#c0392b"}]},
  "DB9F":  {id:"DB9F",  name:"D-SUB 9P Female",   short:"DB9F",  pins:9,  type:"DSUB",cat:"Serial",builtin:true,
    pinout:[{id:1,n:"DCD",sig:"RS232",g:"28AWG",c:"#e74c3c"},{id:2,n:"RXD",sig:"RS232",g:"28AWG",c:"#3498db"},
            {id:3,n:"TXD",sig:"RS232",g:"28AWG",c:"#27ae60"},{id:4,n:"DTR",sig:"RS232",g:"28AWG",c:"#f39c12"},
            {id:5,n:"GND",sig:"GND",g:"28AWG",c:"#888"},    {id:6,n:"DSR",sig:"RS232",g:"28AWG",c:"#9b59b6"},
            {id:7,n:"RTS",sig:"RS232",g:"28AWG",c:"#1abc9c"},{id:8,n:"CTS",sig:"RS232",g:"28AWG",c:"#e67e22"},
            {id:9,n:"RI",sig:"RS232",g:"28AWG",c:"#c0392b"}]},
  "DB25M": {id:"DB25M", name:"D-SUB 25P Male",    short:"DB25M", pins:25, type:"DSUB",cat:"Serial",builtin:true,
    pinout:mkpins(25,"P","DATA","28AWG",14)},
  "DB25F": {id:"DB25F", name:"D-SUB 25P Female",  short:"DB25F", pins:25, type:"DSUB",cat:"Serial",builtin:true,
    pinout:mkpins(25,"P","DATA","28AWG",14)},
  "RJ45":  {id:"RJ45",  name:"RJ45 8P8C",         short:"RJ45",  pins:8,  type:"RJ",  cat:"Network",builtin:true,
    pinout:[{id:1,n:"TX+",sig:"ETH",g:"26AWG",c:"#ff8c00"},{id:2,n:"TX-",sig:"ETH",g:"26AWG",c:"#cc6600"},
            {id:3,n:"RX+",sig:"ETH",g:"26AWG",c:"#00aa00"},{id:4,n:"BI3+",sig:"ETH",g:"26AWG",c:"#0044ff"},
            {id:5,n:"BI3-",sig:"ETH",g:"26AWG",c:"#4488ff"},{id:6,n:"RX-",sig:"ETH",g:"26AWG",c:"#006600"},
            {id:7,n:"BI4+",sig:"ETH",g:"26AWG",c:"#885500"},{id:8,n:"BI4-",sig:"ETH",g:"26AWG",c:"#aa7744"}]},
  "USBA":  {id:"USBA",  name:"USB Type-A",         short:"USB-A", pins:4,  type:"USB", cat:"USB",builtin:true,
    pinout:[{id:1,n:"VBUS",sig:"PWR",g:"28AWG",c:"#e74c3c"},{id:2,n:"D-",sig:"USB",g:"28AWG",c:"#bbb"},
            {id:3,n:"D+",sig:"USB",g:"28AWG",c:"#27ae60"},{id:4,n:"GND",sig:"GND",g:"28AWG",c:"#555"}]},
  "USBC":  {id:"USBC",  name:"USB Type-C",         short:"USB-C", pins:12, type:"USB", cat:"USB",builtin:true,
    pinout:mkpins(12,"C","USB","28AWG",30)},
  "XLR3M": {id:"XLR3M", name:"XLR 3P Male",        short:"XLR3M", pins:3,  type:"CIRC",cat:"Audio",builtin:true,
    pinout:[{id:1,n:"GND",sig:"GND",g:"24AWG",c:"#555"},{id:2,n:"HOT",sig:"AUD",g:"24AWG",c:"#e74c3c"},{id:3,n:"COLD",sig:"AUD",g:"24AWG",c:"#3498db"}]},
  "XLR3F": {id:"XLR3F", name:"XLR 3P Female",      short:"XLR3F", pins:3,  type:"CIRC",cat:"Audio",builtin:true,
    pinout:[{id:1,n:"GND",sig:"GND",g:"24AWG",c:"#555"},{id:2,n:"HOT",sig:"AUD",g:"24AWG",c:"#e74c3c"},{id:3,n:"COLD",sig:"AUD",g:"24AWG",c:"#3498db"}]},
  "MF2P":  {id:"MF2P",  name:"Molex Micro-Fit 2P", short:"MF2P",  pins:2,  type:"RECT",cat:"Molex",pn:"43045-0200",builtin:true,
    pinout:[{id:1,n:"VCC",sig:"PWR",g:"22AWG",c:"#e74c3c"},{id:2,n:"GND",sig:"GND",g:"22AWG",c:"#555"}]},
  "MF4P":  {id:"MF4P",  name:"Molex Micro-Fit 4P", short:"MF4P",  pins:4,  type:"RECT",cat:"Molex",pn:"43045-0400",builtin:true,
    pinout:[{id:1,n:"VCC",sig:"PWR",g:"20AWG",c:"#e74c3c"},{id:2,n:"GND",sig:"GND",g:"20AWG",c:"#555"},
            {id:3,n:"SIG1",sig:"DATA",g:"24AWG",c:"#3498db"},{id:4,n:"SIG2",sig:"DATA",g:"24AWG",c:"#27ae60"}]},
  "MF6P":  {id:"MF6P",  name:"Molex Micro-Fit 6P", short:"MF6P",  pins:6,  type:"RECT",cat:"Molex",pn:"43045-0600",builtin:true,
    pinout:mkpins(6,"P","SIG","22AWG",60)},
  "MF8P":  {id:"MF8P",  name:"Molex Micro-Fit 8P", short:"MF8P",  pins:8,  type:"RECT",cat:"Molex",pn:"43045-0800",builtin:true,
    pinout:mkpins(8,"P","SIG","22AWG",45)},
  "MF12P": {id:"MF12P", name:"Molex Micro-Fit 12P",short:"MF12P", pins:12, type:"RECT",cat:"Molex",pn:"43045-1200",builtin:true,
    pinout:mkpins(12,"P","SIG","22AWG",30)},
  "PH2P":  {id:"PH2P",  name:"JST PH 2P",          short:"PH2P",  pins:2,  type:"RECT",cat:"JST",pn:"B2B-PH-K-S",builtin:true,
    pinout:[{id:1,n:"VCC",sig:"PWR",g:"26AWG",c:"#e74c3c"},{id:2,n:"GND",sig:"GND",g:"26AWG",c:"#555"}]},
  "PH3P":  {id:"PH3P",  name:"JST PH 3P",          short:"PH3P",  pins:3,  type:"RECT",cat:"JST",pn:"B3B-PH-K-S",builtin:true,
    pinout:[{id:1,n:"VCC",sig:"PWR",g:"26AWG",c:"#e74c3c"},{id:2,n:"SIG",sig:"DATA",g:"26AWG",c:"#3498db"},{id:3,n:"GND",sig:"GND",g:"26AWG",c:"#555"}]},
  "XH2P":  {id:"XH2P",  name:"JST XH 2P",          short:"XH2P",  pins:2,  type:"RECT",cat:"JST",pn:"B2B-XH-A",builtin:true,
    pinout:[{id:1,n:"VCC",sig:"PWR",g:"24AWG",c:"#e74c3c"},{id:2,n:"GND",sig:"GND",g:"24AWG",c:"#555"}]},
  "XH4P":  {id:"XH4P",  name:"JST XH 4P",          short:"XH4P",  pins:4,  type:"RECT",cat:"JST",pn:"B4B-XH-A",builtin:true,
    pinout:mkpins(4,"P","SIG","24AWG",90)},
  "DT2P":  {id:"DT2P",  name:"Deutsch DT 2P",       short:"DT2P",  pins:2,  type:"CIRC",cat:"Deutsch",pn:"DT06-2S",builtin:true,
    pinout:[{id:1,n:"PWR",sig:"PWR",g:"16AWG",c:"#e74c3c"},{id:2,n:"GND",sig:"GND",g:"16AWG",c:"#555"}]},
  "DT4P":  {id:"DT4P",  name:"Deutsch DT 4P",       short:"DT4P",  pins:4,  type:"CIRC",cat:"Deutsch",pn:"DT06-4S",builtin:true,
    pinout:[{id:1,n:"PWR",sig:"PWR",g:"16AWG",c:"#e74c3c"},{id:2,n:"GND",sig:"GND",g:"16AWG",c:"#555"},
            {id:3,n:"SGA",sig:"ANLG",g:"22AWG",c:"#3498db"},{id:4,n:"SGB",sig:"ANLG",g:"22AWG",c:"#27ae60"}]},
  "DT6P":  {id:"DT6P",  name:"Deutsch DT 6P",       short:"DT6P",  pins:6,  type:"CIRC",cat:"Deutsch",pn:"DT06-6S",builtin:true,
    pinout:[{id:1,n:"PWR",sig:"PWR",g:"16AWG",c:"#e74c3c"},{id:2,n:"GND",sig:"GND",g:"16AWG",c:"#555"},
            {id:3,n:"SGA",sig:"ANLG",g:"22AWG",c:"#3498db"},{id:4,n:"SGB",sig:"ANLG",g:"22AWG",c:"#27ae60"},
            {id:5,n:"CANH",sig:"CAN",g:"22AWG",c:"#f39c12"},{id:6,n:"CANL",sig:"CAN",g:"22AWG",c:"#9b59b6"}]},
  "MIL13": {id:"MIL13", name:"MIL-38999 WB13 13P",  short:"MIL13", pins:13, type:"CIRC",cat:"Military",builtin:true,
    pinout:["A","B","C","D","E","F","G","H","J","K","L","M","N"].map(function(l,i){return{id:l,n:l,sig:"SIG",g:"22AWG",c:hslc(i*28)};})},
  "MIL35": {id:"MIL35", name:"MIL-38999 WB35 35P",  short:"MIL35", pins:35, type:"CIRC",cat:"Military",builtin:true,
    pinout:["A","B","C","D","E","F","G","H","J","K","L","M","N","P","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","j","k","m","n"].map(function(l,i){return{id:l,n:l,sig:"SIG",g:"22AWG",c:hslc(i*10)};})},
  "HDMI":  {id:"HDMI",  name:"HDMI Type A",          short:"HDMI",  pins:19, type:"RECT",cat:"Video",builtin:true,
    pinout:mkpins(19,"P","HDMI","28AWG",19)}
};

// Accessories library
var ACCESSORIES = [
  {id:"HS-3",  name:"Heat Shrink 3mm",   type:"heatshrink", color:"#222", symbol:"HS"},
  {id:"HS-6",  name:"Heat Shrink 6mm",   type:"heatshrink", color:"#222", symbol:"HS"},
  {id:"HS-10", name:"Heat Shrink 10mm",  type:"heatshrink", color:"#555", symbol:"HS"},
  {id:"SP-5",  name:"Split Loom 5mm",    type:"sleeve",     color:"#1a3a1a", symbol:"SP"},
  {id:"SP-10", name:"Split Loom 10mm",   type:"sleeve",     color:"#1a3a1a", symbol:"SP"},
  {id:"BR-BL", name:"Braided Sleeve Black",type:"sleeve",   color:"#111", symbol:"BR"},
  {id:"TM-W",  name:"Wire Marker White", type:"marker",     color:"#eee", symbol:"M"},
  {id:"TM-Y",  name:"Wire Marker Yellow",type:"marker",     color:"#f39c12", symbol:"M"},
  {id:"FR-F",  name:"Ferrule 0.5mm",     type:"terminal",   color:"#e74c3c", symbol:"T"},
  {id:"FR-1",  name:"Ferrule 1.0mm",     type:"terminal",   color:"#3498db", symbol:"T"},
  {id:"FR-2",  name:"Ferrule 2.5mm",     type:"terminal",   color:"#27ae60", symbol:"T"},
  {id:"TIE",   name:"Cable Tie",         type:"cable_tie",  color:"#eee", symbol:"Z"}
];

function mkpins(n,pre,sig,awg,hStep){
  var r=[];
  for(var i=0;i<n;i++) r.push({id:i+1,n:pre+(i+1),sig:sig,g:awg,c:hslc(i*hStep)});
  return r;
}
function hslc(h){return "hsl("+h+",65%,45%)";}
function uid(){return "e"+Date.now().toString(36)+Math.random().toString(36).slice(2,5);}
function esc(s){return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}
function sc(c){return(c&&(c[0]=="#"||c.indexOf("hsl")===0||c.indexOf("rgb")===0))?c:"#888";}
function clamp(v,a,b){return v<a?a:v>b?b:v;}
function toast(msg,err){
  var t=document.getElementById("toast");
  t.textContent=msg; t.className="toast"+(err?" err":"")+" show";
  clearTimeout(t._tid); t._tid=setTimeout(function(){t.className="toast"+(err?" err":"");},2200);
}

// ============================================================
// STATE
// ============================================================
var S = {
  elements:[], wires:[], dimensions:[],
  title:"ASS'Y CABLE", partNo:"LMA-5528-NCA", dwgNo:"RFQ#001-01",
  rev:"A", drawnBy:"", company:"", cableLength:500, lengthTol:20,
  notes:["No open/short or intermittent failures.",
         "100% electrical test required.",
         "Voltage test: DC 300V; Insulation: 5M ohm min.",
         "All dimensions in mm unless noted. RoHS Compliant."],
  bomItems:[], zoom:1, panX:50, panY:50,
  nextConnLabel:1,
  canvasFontSize:9,
  customConnectors:[]  // <-- NEW: array of user-defined connectors
};

function loadState(){
  try{
    var d=JSON.parse(localStorage.getItem("moti_v5")||"{}");
    for(var k in d) if(k!=="elements"&&k!=="wires") S[k]=d[k];
    if(d.elements) S.elements=d.elements;
    if(d.wires) S.wires=d.wires;
    if(d.dimensions) S.dimensions=d.dimensions;
    if(d.customConnectors) S.customConnectors=d.customConnectors;
  }catch(e){}
}
function saveState(){
  try{localStorage.setItem("moti_v5",JSON.stringify(S));}catch(e){}
}

// Merge custom connectors into CL runtime dict
function syncCustomConnectors(){
  // Remove previously synced custom entries
  for(var k in CL){ if(!CL[k].builtin) delete CL[k]; }
  // Add current custom connectors
  for(var i=0;i<S.customConnectors.length;i++){
    var cc=S.customConnectors[i];
    CL[cc.id]=cc;
  }
}

// ============================================================