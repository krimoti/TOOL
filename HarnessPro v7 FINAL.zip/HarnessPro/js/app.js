/* MOTI HarnessPro — App State & Utilities */


/* === wire_colors.js === */
/* ============================================================
   WIRE_COLORS.JS — Wire color standards
   IEC 60757 / DIN 47100 / ICEA + custom combinations
   MOTI HarnessPro
   ============================================================ */

/* ── IEC 60757 / DIN 47100 base colors (number → color) ── */
var WIRE_COLORS_IEC = [
  { code:0,  abbr:'BK', name:'Black',       hex:'#1a1a1a', textColor:'#fff' },
  { code:1,  abbr:'BN', name:'Brown',       hex:'#7b3f00', textColor:'#fff' },
  { code:2,  abbr:'RD', name:'Red',         hex:'#e74c3c', textColor:'#fff' },
  { code:3,  abbr:'OG', name:'Orange',      hex:'#e67e22', textColor:'#fff' },
  { code:4,  abbr:'YE', name:'Yellow',      hex:'#f1c40f', textColor:'#111' },
  { code:5,  abbr:'GN', name:'Green',       hex:'#27ae60', textColor:'#fff' },
  { code:6,  abbr:'BU', name:'Blue',        hex:'#2980b9', textColor:'#fff' },
  { code:7,  abbr:'VT', name:'Violet',      hex:'#8e44ad', textColor:'#fff' },
  { code:8,  abbr:'GY', name:'Grey',        hex:'#95a5a6', textColor:'#111' },
  { code:9,  abbr:'WH', name:'White',       hex:'#ecf0f1', textColor:'#111' },
  { code:10, abbr:'PK', name:'Pink',        hex:'#ff69b4', textColor:'#111' },
  { code:11, abbr:'TQ', name:'Turquoise',   hex:'#1abc9c', textColor:'#fff' },
];

/* ── Grounding / Earth (IEC 60446) ── */
var WIRE_COLOR_GND = { code:'PE', abbr:'GNYE', name:'Green-Yellow (Earth)', hex:'#27ae60', hex2:'#f1c40f', textColor:'#fff', isStripe:true };

/* ── Standard combinations (base + stripe) ── */
var WIRE_COLOR_COMBOS = [
  /* Most common combos in aerospace/industrial */
  { abbr:'BK/WH', name:'Black / White',   c1:'#1a1a1a', c2:'#ecf0f1' },
  { abbr:'BK/RD', name:'Black / Red',     c1:'#1a1a1a', c2:'#e74c3c' },
  { abbr:'BK/BU', name:'Black / Blue',    c1:'#1a1a1a', c2:'#2980b9' },
  { abbr:'BK/YE', name:'Black / Yellow',  c1:'#1a1a1a', c2:'#f1c40f' },
  { abbr:'RD/WH', name:'Red / White',     c1:'#e74c3c', c2:'#ecf0f1' },
  { abbr:'RD/BK', name:'Red / Black',     c1:'#e74c3c', c2:'#1a1a1a' },
  { abbr:'RD/BU', name:'Red / Blue',      c1:'#e74c3c', c2:'#2980b9' },
  { abbr:'WH/BK', name:'White / Black',   c1:'#ecf0f1', c2:'#1a1a1a' },
  { abbr:'WH/RD', name:'White / Red',     c1:'#ecf0f1', c2:'#e74c3c' },
  { abbr:'WH/BU', name:'White / Blue',    c1:'#ecf0f1', c2:'#2980b9' },
  { abbr:'WH/BN', name:'White / Brown',   c1:'#ecf0f1', c2:'#7b3f00' },
  { abbr:'WH/GN', name:'White / Green',   c1:'#ecf0f1', c2:'#27ae60' },
  { abbr:'BU/WH', name:'Blue / White',    c1:'#2980b9', c2:'#ecf0f1' },
  { abbr:'BU/RD', name:'Blue / Red',      c1:'#2980b9', c2:'#e74c3c' },
  { abbr:'GN/YE', name:'Green / Yellow',  c1:'#27ae60', c2:'#f1c40f' },  /* Earth */
  { abbr:'YE/GN', name:'Yellow / Green',  c1:'#f1c40f', c2:'#27ae60' },
  { abbr:'BN/WH', name:'Brown / White',   c1:'#7b3f00', c2:'#ecf0f1' },
  { abbr:'OG/WH', name:'Orange / White',  c1:'#e67e22', c2:'#ecf0f1' },
  { abbr:'GY/WH', name:'Grey / White',    c1:'#95a5a6', c2:'#ecf0f1' },
  { abbr:'VT/WH', name:'Violet / White',  c1:'#8e44ad', c2:'#ecf0f1' },
];

/* ── ICEA/NEMA color sequence (for multi-conductor cables) ── */
var WIRE_COLORS_ICEA = [
  { code:1,  abbr:'BK',    name:'Black',        hex:'#1a1a1a' },
  { code:2,  abbr:'WH',    name:'White',        hex:'#ecf0f1' },
  { code:3,  abbr:'RD',    name:'Red',          hex:'#e74c3c' },
  { code:4,  abbr:'GN',    name:'Green',        hex:'#27ae60' },
  { code:5,  abbr:'OG',    name:'Orange',       hex:'#e67e22' },
  { code:6,  abbr:'BU',    name:'Blue',         hex:'#2980b9' },
  { code:7,  abbr:'WH/BK', name:'White/Black',  hex:'#ecf0f1', hex2:'#1a1a1a', isStripe:true },
  { code:8,  abbr:'RD/BK', name:'Red/Black',    hex:'#e74c3c', hex2:'#1a1a1a', isStripe:true },
  { code:9,  abbr:'GN/BK', name:'Green/Black',  hex:'#27ae60', hex2:'#1a1a1a', isStripe:true },
  { code:10, abbr:'OG/BK', name:'Orange/Black', hex:'#e67e22', hex2:'#1a1a1a', isStripe:true },
  { code:11, abbr:'BU/BK', name:'Blue/Black',   hex:'#2980b9', hex2:'#1a1a1a', isStripe:true },
  { code:12, abbr:'WH/RD', name:'White/Red',    hex:'#ecf0f1', hex2:'#e74c3c', isStripe:true },
];

/* ── Get next sequential color by standard ── */
function getNextWireColor(standard, index) {
  standard = standard || 'IEC';
  var list = standard === 'ICEA' ? WIRE_COLORS_ICEA : WIRE_COLORS_IEC;
  var item = list[index % list.length];
  return { hex: item.hex, hex2: item.hex2||null, abbr: item.abbr, name: item.name, isStripe: !!item.hex2 };
}

/* ── Render wire color swatch SVG (stripe if combo) ── */
function wireColorSwatch(hex, hex2, size) {
  size = size || 16;
  if(!hex2) {
    return '<span style="display:inline-block;width:'+size+'px;height:'+size+'px;border-radius:3px;background:'+hex+';border:1px solid rgba(0,0,0,0.3);vertical-align:middle"></span>';
  }
  // Diagonal stripe
  return '<svg width="'+size+'" height="'+size+'" style="vertical-align:middle;border-radius:3px;border:1px solid rgba(0,0,0,0.3)">'
    +'<rect width="'+size+'" height="'+size+'" fill="'+hex+'"/>'
    +'<polygon points="'+size+',0 '+size+','+size+' 0,'+size+'" fill="'+hex2+'"/>'
    +'</svg>';
}

/* ── Color picker HTML for wire editing ── */
function renderColorPicker(currentHex, currentHex2, onChangeFn, standard) {
  standard = standard || 'IEC';
  var list = standard === 'ICEA' ? WIRE_COLORS_ICEA : WIRE_COLORS_IEC;
  var combos = WIRE_COLOR_COMBOS;

  var h = '<div style="background:var(--bg1);border:1px solid var(--border2);padding:8px;font-size:8px">';
  h += '<div style="color:var(--text3);margin-bottom:6px;letter-spacing:1px">STANDARD: ';
  h += '<select style="background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:1px 4px;font-size:8px" onchange="changeColorStd(this.value)">';
  ['IEC','ICEA','DIN'].forEach(function(s){ h+='<option'+(standard===s?' selected':'')+'>'+s+'</option>'; });
  h += '</select></div>';

  // Base colors
  h += '<div style="color:var(--text3);margin-bottom:4px">BASE COLORS ('+standard+'):</div>';
  h += '<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px">';
  list.forEach(function(c){
    var active = c.hex===currentHex && !currentHex2;
    h += '<div onclick="'+onChangeFn+'(\''+c.hex+'\',null,\''+esc(c.abbr)+'\')" '
      +'title="'+c.code+' — '+c.name+' ('+c.abbr+')" '
      +'style="cursor:pointer;padding:2px 5px;border:1.5px solid '+(active?'var(--accent)':'var(--border2)')+';'
      +'background:var(--bg2);display:flex;align-items:center;gap:4px;border-radius:2px">'
      +wireColorSwatch(c.hex, null, 12)
      +'<span style="color:'+(active?'var(--accent)':'var(--text2)')+'">'+(c.code)+' '+c.abbr+'</span></div>';
  });
  // Earth
  h += '<div onclick="'+onChangeFn+'(\'#27ae60\',\'#f1c40f\',\'GNYE\')" '
    +'title="PE — Green/Yellow Earth" '
    +'style="cursor:pointer;padding:2px 5px;border:1.5px solid var(--border2);background:var(--bg2);display:flex;align-items:center;gap:4px;border-radius:2px">'
    +wireColorSwatch('#27ae60','#f1c40f',12)
    +'<span style="color:var(--text2)">PE GNYE</span></div>';
  h += '</div>';

  // Combos
  h += '<div style="color:var(--text3);margin-bottom:4px">COMBINATIONS:</div>';
  h += '<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:6px">';
  combos.forEach(function(c){
    var active = c.c1===currentHex && c.c2===currentHex2;
    h += '<div onclick="'+onChangeFn+'(\''+c.c1+'\',\''+c.c2+'\',\''+esc(c.abbr)+'\')" '
      +'title="'+c.name+'" '
      +'style="cursor:pointer;padding:2px 5px;border:1.5px solid '+(active?'var(--accent)':'var(--border2)')+';'
      +'background:var(--bg2);display:flex;align-items:center;gap:4px;border-radius:2px">'
      +wireColorSwatch(c.c1,c.c2,12)
      +'<span style="color:'+(active?'var(--accent)':'var(--text2)')+'">'+c.abbr+'</span></div>';
  });
  h += '</div>';

  // Custom hex
  h += '<div style="display:flex;align-items:center;gap:6px">'
    +'<span style="color:var(--text3)">CUSTOM:</span>'
    +'<input type="color" value="'+(currentHex||'#888888')+'" style="width:28px;height:20px;border:none;padding:0;cursor:pointer" '
    +'oninput="'+onChangeFn+'(this.value,null,\'CUSTOM\')"/>'
    +'</div>';

  h += '</div>';
  return h;
}

/* === partdb.js === */
/* ============================================================
   PARTDB.JS — Company Part Number Database
   Supports: JSON file import, CSV import, manual edit
   MOTI HarnessPro
   ============================================================ */
/* Default demo parts — replace with company data */
var PART_DB = {
  version: '1.0',
  company: '',
  parts: [
    { pn:'CON-DB9M-001',  desc:'D-SUB 9P Male Solder',      cat:'CONNECTOR', unit:'EA', std:'MIL-C-24308' },
    { pn:'CON-DB9F-001',  desc:'D-SUB 9P Female Solder',    cat:'CONNECTOR', unit:'EA', std:'MIL-C-24308' },
    { pn:'CON-MF4P-001',  desc:'Molex Micro-Fit 4P Plug',   cat:'CONNECTOR', unit:'EA', std:'Molex 43045' },
    { pn:'CON-DT4P-001',  desc:'Deutsch DT 4P Plug',        cat:'CONNECTOR', unit:'EA', std:'DT Series'   },
    { pn:'WIR-22AWG-BK',  desc:'Wire 22AWG Black PVC',      cat:'WIRE',      unit:'M',  std:'UL1007'      },
    { pn:'WIR-22AWG-RD',  desc:'Wire 22AWG Red PVC',        cat:'WIRE',      unit:'M',  std:'UL1007'      },
    { pn:'WIR-22AWG-WH',  desc:'Wire 22AWG White PVC',      cat:'WIRE',      unit:'M',  std:'UL1007'      },
    { pn:'WIR-20AWG-BK',  desc:'Wire 20AWG Black PVC',      cat:'WIRE',      unit:'M',  std:'UL1007'      },
    { pn:'SLV-BR-BK-10',  desc:'Braided Sleeve Black 10mm', cat:'SLEEVE',    unit:'M',  std:''            },
    { pn:'HSK-3MM-BK',    desc:'Heat Shrink 3mm Black 2:1', cat:'HEATSHRINK',unit:'M',  std:''            },
    { pn:'HSK-6MM-BK',    desc:'Heat Shrink 6mm Black 2:1', cat:'HEATSHRINK',unit:'M',  std:''            },
    { pn:'LUG-M4-YE',     desc:'Lug Terminal M4 Yellow',    cat:'TERMINAL',  unit:'EA', std:''            },
    { pn:'FER-1MM-RD',    desc:'Ferrule 1.0mm Red',         cat:'TERMINAL',  unit:'EA', std:''            },
    { pn:'FER-25MM-BU',   desc:'Ferrule 2.5mm Blue',        cat:'TERMINAL',  unit:'EA', std:''            },
  ]
};

/* Load from localStorage if saved */
function partDBLoad() {
  try {
    var raw = localStorage.getItem('moti_partdb');
    if(raw) PART_DB = JSON.parse(raw);
  } catch(e) {}
}

function partDBSave() {
  try { localStorage.setItem('moti_partdb', JSON.stringify(PART_DB)); } catch(e) {}
}

/* Search parts */
function partDBSearch(query) {
  query = (query||'').toLowerCase().trim();
  if(!query) return PART_DB.parts.slice(0,40);
  return PART_DB.parts.filter(function(p){
    return p.pn.toLowerCase().indexOf(query)>-1 ||
           p.desc.toLowerCase().indexOf(query)>-1 ||
           (p.cat||'').toLowerCase().indexOf(query)>-1;
  }).slice(0,40);
}

/* Import from JSON */
function partDBImportJSON(jsonText) {
  var d = JSON.parse(jsonText);
  if(Array.isArray(d)) { PART_DB.parts = d; }
  else if(d.parts) { PART_DB = d; }
  else { throw new Error('Invalid format. Expected array or {parts:[...]}'); }
  partDBSave();
}

/* Import from CSV: pn,desc,cat,unit,std */
function partDBImportCSV(csvText) {
  var lines = csvText.split('\n').filter(function(l){return l.trim();});
  var header = lines[0].toLowerCase().split(',').map(function(h){return h.trim().replace(/"/g,'');});
  var parts = [];
  for(var i=1;i<lines.length;i++){
    var cols = lines[i].split(',').map(function(c){return c.trim().replace(/^"|"$/g,'');});
    var part = {};
    header.forEach(function(h,idx){ part[h]=cols[idx]||''; });
    if(part.pn) parts.push(part);
  }
  PART_DB.parts = PART_DB.parts.concat(parts);
  partDBSave();
  return parts.length;
}

partDBLoad();

/* === partdb_panel.js === */
/* ============================================================
   PARTDB_PANEL.JS — Part Database UI panel
   MOTI HarnessPro
   ============================================================ */
function renderPartDB() {
  var panel = document.getElementById('panel-partdb');
  if(!panel) return;

  var h = '<div style="display:grid;grid-template-columns:1fr 320px;height:100%;overflow:hidden">';

  /* ── Left: parts table ── */
  h += '<div style="display:flex;flex-direction:column;overflow:hidden;border-right:1px solid var(--border2)">';
  h += '<div style="padding:10px 14px 8px;background:var(--bg1);border-bottom:1px solid var(--border);flex-shrink:0;display:flex;gap:8px;align-items:center">';
  h += '<span style="font-size:10px;color:var(--accent);letter-spacing:2px">PART DATABASE</span>';
  h += '<span style="color:var(--text3);font-size:8px">'+(PART_DB.parts.length)+' parts</span>';
  h += '<span style="flex:1"></span>';
  h += '<input id="pdb-search" placeholder="Search P/N or description…" style="background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:3px 8px;font-size:9px;width:200px;font-family:monospace" oninput="pdbFilter()">';
  h += '<button class="btn btn-g" onclick="pdbAddPart()">+ ADD</button>';
  h += '<button class="btn" onclick="document.getElementById(\'pdb-import-json\').click()">⬆ JSON</button>';
  h += '<input id="pdb-import-json" type="file" accept=".json" style="display:none" onchange="pdbImportJSON(this)">';
  h += '<button class="btn" onclick="document.getElementById(\'pdb-import-csv\').click()">⬆ CSV</button>';
  h += '<input id="pdb-import-csv" type="file" accept=".csv,.txt" style="display:none" onchange="pdbImportCSV(this)">';
  h += '<button class="btn" onclick="pdbExport()">⬇ EXPORT</button>';
  h += '</div>';

  h += '<div style="flex:1;overflow:auto;padding:0">';
  h += '<table class="rt" id="pdb-table"><thead><tr>';
  h += '<th>PART NUMBER</th><th>DESCRIPTION</th><th>CAT</th><th>UNIT</th><th>STANDARD</th><th>USE</th><th>DEL</th>';
  h += '</tr></thead><tbody id="pdb-tbody">';
  h += _pdbRows(PART_DB.parts);
  h += '</tbody></table></div></div>';

  /* ── Right: part editor ── */
  h += '<div id="pdb-editor" style="background:var(--bg0);display:flex;flex-direction:column;overflow:auto">';
  h += '<div style="padding:12px 14px 8px;border-bottom:1px solid var(--border);flex-shrink:0">';
  h += '<span style="font-size:10px;color:var(--accent);letter-spacing:2px">PART EDITOR</span></div>';
  h += '<div style="padding:14px;color:var(--text3);font-size:9px">Select a part to edit, or click + ADD</div>';
  h += '</div>';

  h += '</div>';
  panel.innerHTML = h;
}

function _pdbRows(parts) {
  var fi = 'background:var(--bg1);border:1px solid var(--border);color:var(--accent);padding:2px 4px;font-size:8px;font-family:monospace';
  var h = '';
  parts.forEach(function(p, i){
    h += '<tr onclick="pdbSelectPart(\''+esc(p.pn)+'\')" style="cursor:pointer">';
    h += '<td style="font-weight:bold;color:var(--accent3)">'+esc(p.pn)+'</td>';
    h += '<td>'+esc(p.desc)+'</td>';
    h += '<td><span style="font-size:7px;padding:1px 5px;background:var(--bg3);color:var(--text2);border-radius:8px">'+esc(p.cat||'')+'</span></td>';
    h += '<td style="text-align:center;color:var(--text2)">'+esc(p.unit||'EA')+'</td>';
    h += '<td style="color:var(--text3);font-size:8px">'+esc(p.std||'')+'</td>';
    h += '<td style="text-align:center"><button class="btn btn-g" style="padding:2px 6px;font-size:7px" onclick="event.stopPropagation();pdbUsePart(\''+esc(p.pn)+'\')">+ BOM</button></td>';
    h += '<td style="text-align:center"><button class="del" onclick="event.stopPropagation();pdbDelPart(\''+esc(p.pn)+'\')">&#215;</button></td>';
    h += '</tr>';
  });
  if(!parts.length) h += '<tr><td colspan="7" style="padding:20px;text-align:center;color:var(--text3)">No parts found</td></tr>';
  return h;
}

function pdbFilter() {
  var q = document.getElementById('pdb-search');
  var tbody = document.getElementById('pdb-tbody');
  if(!q||!tbody) return;
  tbody.innerHTML = _pdbRows(partDBSearch(q.value));
}

function pdbSelectPart(pn) {
  var part = null;
  PART_DB.parts.forEach(function(p){ if(p.pn===pn) part=p; });
  if(!part) return;

  var cats = ['CONNECTOR','WIRE','SLEEVE','HEATSHRINK','TERMINAL','HARDWARE','MATERIAL','OTHER'];
  var fi = 'background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:4px 6px;font-size:9px;width:100%;font-family:monospace;box-sizing:border-box';
  var ed = document.getElementById('pdb-editor');
  if(!ed) return;

  ed.innerHTML = '<div style="padding:12px 14px 8px;border-bottom:1px solid var(--border);flex-shrink:0;display:flex;justify-content:space-between;align-items:center">'
    +'<span style="font-size:10px;color:var(--accent);letter-spacing:2px">EDIT PART</span>'
    +'<button class="btn btn-g" onclick="pdbSaveSelected()" style="padding:3px 10px">💾 SAVE</button>'
    +'</div>'
    +'<div style="padding:14px">'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">PART NUMBER</div>'
    +'<input id="ped-pn" value="'+esc(part.pn)+'" style="'+fi+'"/></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">DESCRIPTION</div>'
    +'<input id="ped-desc" value="'+esc(part.desc||'')+'" style="'+fi+'"/></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">CATEGORY</div>'
    +'<select id="ped-cat" style="'+fi+'">'
    +cats.map(function(c){return '<option'+(part.cat===c?' selected':'')+'>'+c+'</option>';}).join('')
    +'</select></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">UNIT</div>'
    +'<select id="ped-unit" style="'+fi+'">'
    +['EA','M','FT','KG','SET','LOT'].map(function(u){return '<option'+(part.unit===u?' selected':'')+'>'+u+'</option>';}).join('')
    +'</select></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">STANDARD / SPEC</div>'
    +'<input id="ped-std" value="'+esc(part.std||'')+'" placeholder="e.g. MIL-C-24308, UL1007" style="'+fi+'"/></div>'
    +'<div><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">NOTES</div>'
    +'<textarea id="ped-notes" rows="3" style="'+fi+';resize:vertical">'+esc(part.notes||'')+'</textarea></div>'
    +'<div style="margin-top:4px"><input type="hidden" id="ped-orig-pn" value="'+esc(part.pn)+'"></div>'
    +'</div>';
}

function pdbSaveSelected() {
  var origPn = document.getElementById('ped-orig-pn');
  if(!origPn) return;
  var pn   = document.getElementById('ped-pn').value.trim();
  var desc = document.getElementById('ped-desc').value.trim();
  var cat  = document.getElementById('ped-cat').value;
  var unit = document.getElementById('ped-unit').value;
  var std  = document.getElementById('ped-std').value.trim();
  var notes= document.getElementById('ped-notes').value.trim();
  if(!pn) { toast('Part number required', true); return; }

  var found = false;
  PART_DB.parts.forEach(function(p){
    if(p.pn === origPn.value) { p.pn=pn; p.desc=desc; p.cat=cat; p.unit=unit; p.std=std; p.notes=notes; found=true; }
  });
  if(!found) PART_DB.parts.push({pn:pn,desc:desc,cat:cat,unit:unit,std:std,notes:notes});
  partDBSave();
  renderPartDB();
  toast('Part saved: '+pn);
}

function pdbAddPart() {
  var newPn = 'PN-' + Date.now().toString(36).toUpperCase();
  PART_DB.parts.push({pn:newPn, desc:'New Part', cat:'MATERIAL', unit:'EA', std:'', notes:''});
  partDBSave();
  renderPartDB();
  pdbSelectPart(newPn);
}

function pdbDelPart(pn) {
  if(!confirm('Delete part '+pn+'?')) return;
  PART_DB.parts = PART_DB.parts.filter(function(p){return p.pn!==pn;});
  partDBSave();
  renderPartDB();
}

function pdbUsePart(pn) {
  var part = null;
  PART_DB.parts.forEach(function(p){ if(p.pn===pn) part=p; });
  if(!part) return;
  pushUndo();
  S.bomItems.push({id:uid(), qty:1, unit:part.unit||'EA', pn:part.pn, desc:part.desc, cat:part.cat||'PURCHASED'});
  saveState();
  toast('Added to BOM: '+pn);
}

function pdbImportJSON(input) {
  var file = input.files[0]; if(!file) return;
  var reader = new FileReader();
  reader.onload = function(ev){
    try {
      partDBImportJSON(ev.target.result);
      renderPartDB();
      toast('Imported '+PART_DB.parts.length+' parts');
    } catch(e) { toast('Import error: '+e.message, true); }
  };
  reader.readAsText(file); input.value='';
}

function pdbImportCSV(input) {
  var file = input.files[0]; if(!file) return;
  var reader = new FileReader();
  reader.onload = function(ev){
    try {
      var n = partDBImportCSV(ev.target.result);
      renderPartDB();
      toast('Imported '+n+' parts from CSV');
    } catch(e) { toast('CSV import error: '+e.message, true); }
  };
  reader.readAsText(file); input.value='';
}

function pdbExport() {
  var b = new Blob([JSON.stringify(PART_DB,null,2)],{type:'application/json'});
  var a = document.createElement('a'); a.href=URL.createObjectURL(b);
  a.download='parts_db_'+(PART_DB.company||'company')+'_'+new Date().toISOString().slice(0,10)+'.json';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('Part database exported');
}


// ════ UNDO/REDO ════
var UNDO_STACK=[], REDO_STACK=[], _undoLock=false;
function _snap(){return JSON.stringify({el:JSON.parse(JSON.stringify(S.elements)),wi:JSON.parse(JSON.stringify(S.wires)),di:JSON.parse(JSON.stringify(S.dimensions))});}
function _restore(s){var d=JSON.parse(s);S.elements=d.el;S.wires=d.wi;S.dimensions=d.di;}
function pushUndo(){if(_undoLock)return;UNDO_STACK.push(_snap());if(UNDO_STACK.length>60)UNDO_STACK.shift();REDO_STACK=[];_udUI();}
function undoAction(){if(!UNDO_STACK.length)return;REDO_STACK.push(_snap());_undoLock=true;_restore(UNDO_STACK.pop());_undoLock=false;saveState();renderAll();_udUI();toast("Undo");}
function redoAction(){if(!REDO_STACK.length)return;UNDO_STACK.push(_snap());_undoLock=true;_restore(REDO_STACK.pop());_undoLock=false;saveState();renderAll();_udUI();toast("Redo");}
function _udUI(){var u=document.getElementById("btn-undo"),r=document.getElementById("btn-redo");if(u)u.style.opacity=UNDO_STACK.length?"1":"0.35";if(r)r.style.opacity=REDO_STACK.length?"1":"0.35";}
function newProject(){if(!confirm("New project? Unsaved changes will be lost."))return;pushUndo();S.elements=[];S.wires=[];S.dimensions=[];S.bomItems=[];S.nextConnLabel=1;H.nodes=[];H.segs=[];UNDO_STACK=[];REDO_STACK=[];saveState();buildSidebar();renderAll();syncTBAll();_udUI();toast("New project");}




// ============================================================
// CONNECTOR LIBRARY (built-in, read-only)
// ============================================================
function mkpins(n,pre,sig,awg,hStep){
  var r=[];
  for(var i=0;i<n;i++) r.push({id:i+1,n:pre+(i+1),sig:sig,g:awg,c:hslc(i*hStep)});
  return r;
}
function hslc(h){return "hsl("+h+",65%,45%)";}
function uid(){return "e"+Date.now().toString(36)+Math.random().toString(36).slice(2,5);}
function esc(s){return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}
function sc(c){return(c&&(c[0]=="#"||c.indexOf("hsl")===0||c.indexOf("rgb")===0))?c:"#888";}
function clamp(v,a,b){return v<a?a:v>b?b:v;}
function toast(msg,err){
  var t=document.getElementById("toast");
  t.textContent=msg; t.className="toast"+(err?" err":"")+" show";
  clearTimeout(t._tid); t._tid=setTimeout(function(){t.className="toast"+(err?" err":"");},2200);
}

// ============================================================
// STATE
// ============================================================
var S = {
  elements:[], wires:[], dimensions:[],
  title:"ASS'Y CABLE", partNo:"LMA-5528-NCA", dwgNo:"RFQ#001-01",
  rev:"A", drawnBy:"", company:"", cableLength:500, lengthTol:20,
  notes:["No open/short or intermittent failures.",
         "100% electrical test required.",
         "Voltage test: DC 300V; Insulation: 5M ohm min.",
         "All dimensions in mm unless noted. RoHS Compliant."],
  bomItems:[], zoom:1, panX:50, panY:50,
  nextConnLabel:1,
  canvasFontSize:9,
  customConnectors:[]  // <-- NEW: array of user-defined connectors
};

function loadState(){
  try{
    var d=JSON.parse(localStorage.getItem("moti_v5")||"{}");
    for(var k in d) if(k!=="elements"&&k!=="wires") S[k]=d[k];
    if(d.elements) S.elements=d.elements;
    if(d.wires) S.wires=d.wires;
    if(d.dimensions) S.dimensions=d.dimensions;
    if(d.customConnectors) S.customConnectors=d.customConnectors;
  }catch(e){}
}
function saveState(){
  try{localStorage.setItem("moti_v5",JSON.stringify(S));}catch(e){}
}

// Merge custom connectors into CL runtime dict
function syncCustomConnectors(){
  // Remove previously synced custom entries
  for(var k in CL){ if(!CL[k].builtin) delete CL[k]; }
  // Add current custom connectors
  for(var i=0;i<S.customConnectors.length;i++){
    var cc=S.customConnectors[i];
    CL[cc.id]=cc;
  }
}

// ============================================================