/* MOTI HarnessPro — Engineering Drawing */


var DWG_SCALE = 1;

function openDwgModal(){
  if(!H.nodes)H.nodes=[];
  if(!H.segs) H.segs=[];
  hvBuildTopology();
  document.getElementById("dwg-modal").style.display="flex";
  setTimeout(function(){ dwgRegen(); },100);
}
function closeDwgModal(){document.getElementById("dwg-modal").style.display="none";}

function dwgZoom(f){DWG_SCALE=Math.max(.25,Math.min(3,DWG_SCALE*f));dwgApplyScale();}
function dwgFit(){
  var scroll=document.getElementById("dwg-scroll");
  var paper=document.getElementById("dwg-paper");
  if(!scroll||!paper)return;
  DWG_SCALE=Math.max(.2,Math.min(1.2,(scroll.clientWidth-56)/(paper.scrollWidth/DWG_SCALE||1340)));
  dwgApplyScale();
}
function dwgApplyScale(){
  var p=document.getElementById("dwg-paper");
  if(p)p.style.transform="scale("+DWG_SCALE+")";
}
function dwgRegen(){
  var paper=document.getElementById("dwg-paper");
  if(!paper)return;
  try{
    // Make sure harness topology is built
    if(!H.nodes)H.nodes=[];
    if(!H.segs)H.segs=[];
    hvBuildTopology();
    var sheets=buildDrawing({S:S,CL:CL,H:H});
    paper.innerHTML=sheets.join("\n");
    paper.style.transformOrigin="top left";
    setTimeout(dwgFit,60);
  }catch(err){
    paper.innerHTML='<div style="padding:40px;font-family:monospace;color:#e74c3c;font-size:11px">Drawing error: '+String(err)+'<br><br>Try adding connectors on the Canvas tab first.</div>';
    console.error("buildDrawing error:",err);
  }
}
function dwgPrint(){
  var paper=document.getElementById("dwg-paper");
  if(!paper)return;
  var win=window.open("","_blank","width=1400,height=960");
  if(!win)return;
  win.document.write([
    "<!DOCTYPE html><html><head><meta charset='UTF-8'>",
    "<title>"+esc(S.title||"Engineering Drawing")+"</title>",
    "<style>@page{size:A3 landscape;margin:4mm}body{margin:0;padding:0;background:#fff}</style>",
    "</head><body>",
    paper.innerHTML,
    "</body></html>"
  ].join(""));
  win.document.close();win.focus();
  setTimeout(function(){win.print();},500);
}

// Drag-to-pan inside modal
(function(){
  var el,dragging=false,sx,sy,sl,st;
  function init(){el=document.getElementById("dwg-scroll");}
  document.addEventListener("mousedown",function(e){
    if(!el)init();if(!el||!el.contains(e.target)||e.target.tagName==="BUTTON")return;
    dragging=true;sx=e.clientX;sy=e.clientY;sl=el.scrollLeft;st=el.scrollTop;el.style.cursor="grabbing";
  });
  document.addEventListener("mousemove",function(e){
    if(!dragging)return;el.scrollLeft=sl-(e.clientX-sx);el.scrollTop=st-(e.clientY-sy);
  });
  document.addEventListener("mouseup",function(){
    if(!dragging)return;dragging=false;if(el)el.style.cursor="grab";
  });
  document.addEventListener("wheel",function(e){
    if(!el)init();if(!el||!el.contains(e.target))return;
    if(e.ctrlKey||e.metaKey){e.preventDefault();dwgZoom(e.deltaY<0?1.1:.91);}
  },{passive:false});
})();

// Keyboard shortcuts
document.addEventListener("keydown",function(e){
  var ctrl=e.ctrlKey||e.metaKey;
  if(ctrl&&e.key==="z"){e.preventDefault();undoAction();return;}
  if(ctrl&&(e.key==="y"||(e.shiftKey&&e.key==="z"))){e.preventDefault();redoAction();return;}
  if(ctrl&&e.key==="n"){e.preventDefault();newProject();return;}
  if(e.key==="Escape"){
    if(document.getElementById("dwg-modal").style.display!=="none")closeDwgModal();
    if(wireStart){wireStart=null;updateRouteHint(null);renderCanvas();}
  }
});

// ═══ SVG DRAWING ENGINE ═══

function buildDrawing(data){
  var S=data.S, CL=data.CL, H=data.H;
  // Safety defaults
  if(!S) S={elements:[],wires:[],bomItems:[],notes:[],title:"",partNo:"",dwgNo:"",rev:"A",drawnBy:"",company:"",cableLength:500,lengthTol:20};
  if(!S.elements) S.elements=[];
  if(!S.wires)    S.wires=[];
  if(!S.bomItems) S.bomItems=[];
  if(!S.notes)    S.notes=[];
  if(!H) H={nodes:[],segs:[]};
  if(!H.nodes) H.nodes=[];
  if(!H.segs)  H.segs=[];
  if(!CL) CL={};
  var today=new Date().toLocaleDateString('en-GB');

  // ── Figure out how many sheets we need ──
  // Each sheet = A3 landscape: 420×297mm → at 3.2px/mm = 1344×950px
  // We use logical units, scale with viewBox
  var PW=1340, PH=940; // paper width/height per sheet
  var ML=22,MR=22,MT=18,MB=18; // margins
  var TB_H=62; // title block height
  var BOM_W=0; // BOM goes on sheet 2 if needed or below

  // Drawing zone
  var DX=ML, DY=MT;
  var DW=PW-ML-MR, DH=PH-MT-MB-TB_H;

  // Zones inside drawing area
  var HARNESS_H = Math.round(DH*0.55); // harness diagram
  var PIN_H     = DH-HARNESS_H-6;     // pin tables below

  // ────────────────────────────────
  // Layout harness nodes in draw zone
  // ────────────────────────────────
  var hNodes=H.nodes, hSegs=H.segs;

  // Guard: if no nodes, use defaults
  if(!hNodes.length){
    hNodes=[{id:'_demo',label:'(No connectors on canvas)',connId:null,x:0,y:0,angle:0,isJunction:false}];
  }
  // Find bounding box
  var xs=hNodes.map(function(n){return n.x;}), ys=hNodes.map(function(n){return n.y;});
  var minX=(xs.length?Math.min.apply(null,xs):0)-80;
  var maxX=(xs.length?Math.max.apply(null,xs):400)+80;
  var minY=(ys.length?Math.min.apply(null,ys):0)-80;
  var maxY=(ys.length?Math.max.apply(null,ys):200)+80;
  var rnX=maxX-minX||400, rnY=maxY-minY||200;

  var hPad=60;
  var hScaleX=(DW-hPad*2)/rnX;
  var hScaleY=(HARNESS_H-hPad*2)/rnY;
  var hScale=Math.min(hScaleX,hScaleY)*0.88;
  var hOX=DX+hPad+(DW-hPad*2)/2-(minX+rnX/2)*hScale;
  var hOY=DY+hPad+(HARNESS_H-hPad*2)/2-(minY+rnY/2)*hScale;

  function mapNode(node){
    return{x:hOX+node.x*hScale, y:hOY+node.y*hScale};
  }

  // Build SVG per sheet
  var sheets=[];

  // ────────────────────────────────────────────
  // SHEET 1: Title + Harness Diagram + Pin Tables
  // ────────────────────────────────────────────
  var svg=[];
  function p(s){svg.push(s);}

  p('<?xml version="1.0" encoding="UTF-8"?>');
  p('<svg xmlns="http://www.w3.org/2000/svg" width="'+PW+'" height="'+PH+'" viewBox="0 0 '+PW+' '+PH+'"');
  p(' style="font-family:\'Courier New\',Courier,monospace;background:#fff;display:block">');

  // ── Background ──
  p('<rect width="'+PW+'" height="'+PH+'" fill="#f8f7f2"/>');

  // ── Border + inner border ──
  p('<rect x="'+ML+'" y="'+MT+'" width="'+(PW-ML-MR)+'" height="'+(PH-MT-MB)+'" fill="none" stroke="#222" stroke-width="2"/>');
  p('<rect x="'+(ML+5)+'" y="'+(MT+5)+'" width="'+(PW-ML-MR-10)+'" height="'+(PH-MT-MB-10)+'" fill="none" stroke="#222" stroke-width="0.5"/>');

  // ── Zone marks (A–H top, 1–6 side) ──
  var zW=(PW-ML-MR)/8;
  for(var zi=0;zi<8;zi++){
    var zx=ML+zW*(zi+0.5);
    p('<text x="'+zx.toFixed(0)+'" y="'+(MT-4)+'" text-anchor="middle" font-size="8" fill="#999">'+'ABCDEFGH'[zi]+'</text>');
    p('<text x="'+zx.toFixed(0)+'" y="'+(PH-MB+10)+'" text-anchor="middle" font-size="8" fill="#999">'+'ABCDEFGH'[zi]+'</text>');
  }
  var zH=(PH-MT-MB)/6;
  for(var zi=0;zi<6;zi++){
    var zy=MT+zH*(zi+0.5);
    p('<text x="'+(ML-7)+'" y="'+(zy+3).toFixed(0)+'" text-anchor="middle" font-size="8" fill="#999">'+(zi+1)+'</text>');
    p('<text x="'+(PW-MR+7)+'" y="'+(zy+3).toFixed(0)+'" text-anchor="middle" font-size="8" fill="#999">'+(zi+1)+'</text>');
  }

  // ── Separator lines in draw area ──
  var harBottomY=DY+HARNESS_H;
  var pinTopY=harBottomY+6;
  var tbTopY=PH-MB-TB_H;

  p('<line x1="'+DX+'" y1="'+harBottomY+'" x2="'+(DX+DW)+'" y2="'+harBottomY+'" stroke="#bbb" stroke-width="0.6" stroke-dasharray="4,3"/>');
  p('<line x1="'+DX+'" y1="'+tbTopY+'" x2="'+(DX+DW)+'" y2="'+tbTopY+'" stroke="#444" stroke-width="1"/>');

  // ── Section labels ──
  function secLabel(x,y,txt){
    p('<text x="'+x+'" y="'+y+'" font-size="7" fill="#888" letter-spacing="1.5" font-weight="bold">'+esc(txt)+'</text>');
  }
  secLabel(DX+3, DY+10, 'HARNESS TOPOLOGY DIAGRAM');
  secLabel(DX+3, pinTopY+10, 'CONNECTOR PIN TABLES');

  // ══════════════════════════════════════════════
  // HARNESS DIAGRAM
  // ══════════════════════════════════════════════

  // Define gradient defs
  p('<defs>');
  p('<filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">');
  p('  <feDropShadow dx="1.5" dy="2" stdDeviation="2" flood-opacity="0.3"/>');
  p('</filter>');
  // Connector gradients
  hNodes.filter(function(n){return!n.isJunction&&CL[n.connId];}).forEach(function(nd){
    p('<linearGradient id="cg_'+nd.id+'" x1="0" y1="0" x2="0" y2="1">');
    p('<stop offset="0%" stop-color="#bcb4a4"/><stop offset="35%" stop-color="#d0c8b8"/>');
    p('<stop offset="65%" stop-color="#c0b8a8"/><stop offset="100%" stop-color="#787068"/>');
    p('</linearGradient>');
  });
  p('</defs>');

  // ── Draw segments (cables) ──
  hSegs.forEach(function(seg){
    var n1=null,n2=null;
    hNodes.forEach(function(n){if(n.id===seg.from)n1=n;if(n.id===seg.to)n2=n;});
    if(!n1||!n2)return;
    var p1=mapNode(n1), p2=mapNode(n2);
    var a1=(n1.angle||0)*Math.PI/180, a2=(n2.angle||0)*Math.PI/180;
    var stub=36;
    var s1={x:p1.x+Math.cos(a1)*stub,y:p1.y+Math.sin(a1)*stub};
    var s2={x:p2.x+Math.cos(a2)*stub,y:p2.y+Math.sin(a2)*stub};
    var bendPts=(seg.pts||[]).map(function(bp){return{x:hOX+bp.x*hScale,y:hOY+bp.y*hScale};});
    var allPts=[s1].concat(bendPts).concat([s2]);
    var thick=Math.max(6,Math.min(32,6+(seg.wires||[]).length*2.4));

    var d='M'+s1.x.toFixed(1)+' '+s1.y.toFixed(1);
    allPts.slice(1).forEach(function(pt){d+=' L'+pt.x.toFixed(1)+' '+pt.y.toFixed(1);});

    // Shadow
    p('<path d="'+d+'" stroke="rgba(0,0,0,0.22)" stroke-width="'+(thick+4)+'" fill="none" stroke-linecap="round" stroke-linejoin="round"/>');
    // Outer sheath
    p('<path d="'+d+'" stroke="#2c2820" stroke-width="'+thick+'" fill="none" stroke-linecap="round" stroke-linejoin="round"/>');
    // Sheath highlight
    p('<path d="'+d+'" stroke="rgba(160,145,115,0.4)" stroke-width="'+(thick*0.36)+'" fill="none" stroke-linecap="round" stroke-linejoin="round"/>');

    // Braid diagonal hatch
    for(var pi=0;pi<allPts.length-1;pi++){
      var ax=allPts[pi].x,ay=allPts[pi].y,bx=allPts[pi+1].x,by=allPts[pi+1].y;
      var segL=Math.sqrt((bx-ax)*(bx-ax)+(by-ay)*(by-ay));
      var ang=Math.atan2(by-ay,bx-ax);
      var nx=Math.cos(ang+Math.PI/2)*thick*0.46;
      var ny=Math.sin(ang+Math.PI/2)*thick*0.46;
      var sp=10;
      for(var t=sp/2;t<segL-sp/2;t+=sp){
        var tx=ax+Math.cos(ang)*t,ty=ay+Math.sin(ang)*t;
        var dx=Math.cos(ang)*5,dy=Math.sin(ang)*5;
        p('<line x1="'+(tx+nx).toFixed(1)+'" y1="'+(ty+ny).toFixed(1)+'" x2="'+(tx-nx+dx).toFixed(1)+'" y2="'+(ty-ny+dy).toFixed(1)+'" stroke="rgba(200,188,160,0.38)" stroke-width="0.65"/>');
        p('<line x1="'+(tx-nx).toFixed(1)+'" y1="'+(ty-ny).toFixed(1)+'" x2="'+(tx+nx+dx).toFixed(1)+'" y2="'+(ty+ny+dy).toFixed(1)+'" stroke="rgba(200,188,160,0.38)" stroke-width="0.65"/>');
      }
    }

    // Wire colour stripes
    var wCols=[];
    (seg.wires||[]).forEach(function(wid){
      (S.wires||[]).forEach(function(w){if(w.id===wid)wCols.push(sc(w.color||'#888'));});
    });
    var maxS=Math.min(wCols.length,8);
    if(maxS>0){
      var sw=Math.max(1,thick*0.1),spread=thick*0.3;
      wCols.slice(0,maxS).forEach(function(col,ci){
        var t2=maxS===1?0:((ci/(maxS-1))*2-1)*spread;
        var dOff='';
        for(var pi2=0;pi2<allPts.length-1;pi2++){
          var ddx=allPts[pi2+1].x-allPts[pi2].x,ddy=allPts[pi2+1].y-allPts[pi2].y;
          var l=Math.sqrt(ddx*ddx+ddy*ddy)||1;
          var nnx=-ddy/l*t2,nny=ddx/l*t2;
          if(pi2===0)dOff='M'+(allPts[0].x+nnx).toFixed(1)+' '+(allPts[0].y+nny).toFixed(1);
          dOff+=' L'+(allPts[pi2+1].x+nnx).toFixed(1)+' '+(allPts[pi2+1].y+nny).toFixed(1);
        }
        p('<path d="'+dOff+'" stroke="'+col+'" stroke-width="'+sw.toFixed(1)+'" fill="none" stroke-linecap="butt"/>');
      });
    }
  });

  // ── Dimension annotations ──
  hSegs.forEach(function(seg,si){
    var n1=null,n2=null;
    hNodes.forEach(function(n){if(n.id===seg.from)n1=n;if(n.id===seg.to)n2=n;});
    if(!n1||!n2)return;
    var p1=mapNode(n1),p2=mapNode(n2);
    var a1=(n1.angle||0)*Math.PI/180,a2=(n2.angle||0)*Math.PI/180;
    var stub=36;
    var s1={x:p1.x+Math.cos(a1)*stub,y:p1.y+Math.sin(a1)*stub};
    var s2={x:p2.x+Math.cos(a2)*stub,y:p2.y+Math.sin(a2)*stub};
    var bendPts=(seg.pts||[]).map(function(bp){return{x:hOX+bp.x*hScale,y:hOY+bp.y*hScale};});
    var allPts=[s1].concat(bendPts).concat([s2]);

    var totLen=0,cumL=[0];
    for(var i=0;i<allPts.length-1;i++){
      var ddx=allPts[i+1].x-allPts[i].x,ddy=allPts[i+1].y-allPts[i].y;
      var l=Math.sqrt(ddx*ddx+ddy*ddy);
      totLen+=l; cumL.push(totLen);
    }
    if(totLen<10)return;

    var half=totLen/2,midPt={x:0,y:0},midAng=0;
    for(var i=1;i<allPts.length;i++){
      if(cumL[i]>=half){
        var tt=(half-cumL[i-1])/(cumL[i]-cumL[i-1]);
        midPt={x:allPts[i-1].x+(allPts[i].x-allPts[i-1].x)*tt,y:allPts[i-1].y+(allPts[i].y-allPts[i-1].y)*tt};
        midAng=Math.atan2(allPts[i].y-allPts[i-1].y,allPts[i].x-allPts[i-1].x);break;
      }
    }

    var thick=Math.max(6,Math.min(32,6+(seg.wires||[]).length*2.4));
    var perpX=Math.cos(midAng+Math.PI/2),perpY=Math.sin(midAng+Math.PI/2);
    // Flip perp upward in general
    if(perpY>0){perpX=-perpX;perpY=-perpY;}
    var off=thick/2+20;
    var lx=midPt.x+perpX*off,ly=midPt.y+perpY*off;

    // Endpoint dim positions
    var ep1={x:lx-Math.cos(midAng)*totLen*0.48,y:ly-Math.sin(midAng)*totLen*0.48};
    var ep2={x:lx+Math.cos(midAng)*totLen*0.48,y:ly+Math.sin(midAng)*totLen*0.48};

    // Extension lines
    p('<line x1="'+s1.x.toFixed(1)+'" y1="'+s1.y.toFixed(1)+'" x2="'+ep1.x.toFixed(1)+'" y2="'+ep1.y.toFixed(1)+'" stroke="#336699" stroke-width="0.65" stroke-dasharray="2.5,2"/>');
    p('<line x1="'+s2.x.toFixed(1)+'" y1="'+s2.y.toFixed(1)+'" x2="'+ep2.x.toFixed(1)+'" y2="'+ep2.y.toFixed(1)+'" stroke="#336699" stroke-width="0.65" stroke-dasharray="2.5,2"/>');

    // Dim line
    var dp1={x:ep1.x+Math.cos(midAng)*8,y:ep1.y+Math.sin(midAng)*8};
    var dp2={x:ep2.x-Math.cos(midAng)*8,y:ep2.y-Math.sin(midAng)*8};
    p('<line x1="'+ep1.x.toFixed(1)+'" y1="'+ep1.y.toFixed(1)+'" x2="'+ep2.x.toFixed(1)+'" y2="'+ep2.y.toFixed(1)+'" stroke="#336699" stroke-width="0.9"/>');

    // Arrowheads (SVG)
    function svgArrow(px,py,ang2){
      var sz=8,a1=ang2+2.65,a2=ang2-2.65;
      p('<line x1="'+px.toFixed(1)+'" y1="'+py.toFixed(1)+'" x2="'+(px+Math.cos(a1)*sz).toFixed(1)+'" y2="'+(py+Math.sin(a1)*sz).toFixed(1)+'" stroke="#336699" stroke-width="0.9"/>');
      p('<line x1="'+px.toFixed(1)+'" y1="'+py.toFixed(1)+'" x2="'+(px+Math.cos(a2)*sz).toFixed(1)+'" y2="'+(py+Math.sin(a2)*sz).toFixed(1)+'" stroke="#336699" stroke-width="0.9"/>');
    }
    svgArrow(ep1.x,ep1.y,Math.atan2(ep2.y-ep1.y,ep2.x-ep1.x)+Math.PI);
    svgArrow(ep2.x,ep2.y,Math.atan2(ep1.y-ep2.y,ep1.x-ep2.x)+Math.PI);

    // Dim label
    var drawAng2=(midAng>Math.PI/2||midAng<-Math.PI/2)?midAng+Math.PI:midAng;
    var dimTxt=(seg.label?seg.label+'  ':'')+seg.lengthMm+' mm'+(S.lengthTol?' ±'+S.lengthTol:'');
    var tx=lx.toFixed(1),ty=ly.toFixed(1),r=(drawAng2*180/Math.PI).toFixed(1);
    p('<g transform="translate('+tx+','+ty+') rotate('+r+')">');
    p('<rect x="-36" y="-10" width="72" height="12" rx="1.5" fill="rgba(248,246,238,0.96)" stroke="#336699" stroke-width="0.7"/>');
    p('<text x="0" y="0" text-anchor="middle" font-size="8.5" fill="#336699" font-weight="bold">'+esc(dimTxt)+'</text>');
    p('</g>');
  });

  // ── Draw connector bodies ──
  var connMap={};
  hNodes.forEach(function(nd){
    var m=mapNode(nd);
    connMap[nd.id]=m;

    if(nd.isJunction){
      // Junction point
      p('<circle cx="'+m.x.toFixed(1)+'" cy="'+m.y.toFixed(1)+'" r="8" fill="#2c2820" stroke="#888" stroke-width="1.2" filter="url(#shadow)"/>');
      p('<text x="'+m.x.toFixed(1)+'" y="'+(m.y+3).toFixed(1)+'" text-anchor="middle" font-size="7" fill="#f0e8d0" font-weight="bold">'+esc(nd.label||'J')+'</text>');
      return;
    }

    var lib=CL[nd.connId]; if(!lib) return;
    var pins=lib.pins;
    var bw=Math.max(26,Math.min(46,22+pins*1.2));
    var bh=Math.max(20,Math.min(42,14+pins*1.8));
    var ang=(nd.angle||0);

    p('<g transform="translate('+m.x.toFixed(1)+','+m.y.toFixed(1)+') rotate('+ang+')" filter="url(#shadow)">');
    // Outer shell
    p('<rect x="'+(-bw/2).toFixed(1)+'" y="'+(-bh/2).toFixed(1)+'" width="'+bw+'" height="'+bh+'" rx="3" fill="url(#cg_'+nd.id+')" stroke="#50483c" stroke-width="1.2"/>');
    // Insert
    p('<rect x="'+(-bw*0.42).toFixed(1)+'" y="'+(-bh*0.40).toFixed(1)+'" width="'+(bw*0.84).toFixed(1)+'" height="'+(bh*0.80).toFixed(1)+'" rx="2" fill="#282010" stroke="#181008" stroke-width="0.6"/>');
    // Keying tab
    p('<rect x="'+(-bw*0.24).toFixed(1)+'" y="'+(-bh/2-4).toFixed(1)+'" width="'+(bw*0.48).toFixed(1)+'" height="5" rx="2" fill="#807868" stroke="#605848" stroke-width="0.7"/>');
    // Pin dots
    var cols=Math.ceil(Math.sqrt(pins)),rows=Math.ceil(pins/cols);
    var cw2=bw*0.84/cols,ch2=bh*0.8/rows;
    var dr=Math.max(1.8,Math.min(4,cw2*0.32));
    lib.pinout.forEach(function(pp,i){
      var c=i%cols,r2=Math.floor(i/cols);
      var px2=-bw*0.42+cw2*(c+0.5),py2=-bh*0.4+ch2*(r2+0.5);
      p('<circle cx="'+px2.toFixed(1)+'" cy="'+py2.toFixed(1)+'" r="'+dr+'" fill="'+sc(pp.c)+'" stroke="rgba(0,0,0,0.65)" stroke-width="0.4"/>');
      p('<circle cx="'+(px2-dr*.22).toFixed(1)+'" cy="'+(py2-dr*.22).toFixed(1)+'" r="'+(dr*.3).toFixed(1)+'" fill="rgba(255,255,255,0.32)"/>');
    });
    p('</g>');

    // Label (unrotated, below connector)
    var lby=m.y+bh/2+14;
    p('<text x="'+m.x.toFixed(1)+'" y="'+lby.toFixed(1)+'" text-anchor="middle" font-size="9.5" fill="#111" font-weight="bold">'+esc(nd.label||'?')+'</text>');
    p('<text x="'+m.x.toFixed(1)+'" y="'+(lby+11).toFixed(1)+'" text-anchor="middle" font-size="7.5" fill="#555">'+esc(lib.name)+'</text>');
  });

  // ── Item balloons ──
  hNodes.filter(function(n){return!n.isJunction;}).forEach(function(nd,idx){
    var m=connMap[nd.id]; if(!m) return;
    var lib=CL[nd.connId]; if(!lib) return;
    var bw=Math.max(26,Math.min(46,22+lib.pins*1.2));
    var bh=Math.max(20,Math.min(42,14+lib.pins*1.8));
    var itemN=nd.itemNo||String.fromCharCode(65+idx);
    var bx=m.x+bw/2+20,by=m.y-bh/2-18;
    p('<line x1="'+bx.toFixed(1)+'" y1="'+by.toFixed(1)+'" x2="'+m.x.toFixed(1)+'" y2="'+m.y.toFixed(1)+'" stroke="#444" stroke-width="0.8"/>');
    p('<circle cx="'+bx.toFixed(1)+'" cy="'+by.toFixed(1)+'" r="10" fill="white" stroke="#222" stroke-width="1.2"/>');
    p('<text x="'+bx.toFixed(1)+'" y="'+(by+3.5).toFixed(1)+'" text-anchor="middle" font-size="9" fill="#111" font-weight="bold">'+esc(itemN)+'</text>');
  });

  // ══════════════════════════════════════════════
  // PIN TABLES (below harness)
  // ══════════════════════════════════════════════
  var connEls=hNodes.filter(function(n){return!n.isJunction&&CL[n.connId];});
  var ptRowH=11,ptHdrH=15,ptColHdrH=11;
  var maxPins=0;
  connEls.forEach(function(nd){var l=CL[nd.connId];if(l&&l.pins>maxPins)maxPins=l.pins;});
  var ptH=ptHdrH+ptColHdrH+(maxPins+1)*ptRowH;
  var ptCols=Math.max(1,Math.floor(DW/(Math.max(180,DW/connEls.length-4))));
  var ptW=Math.floor((DW-4*(ptCols-1))/ptCols);

  connEls.forEach(function(nd,idx){
    var lib=CL[nd.connId]; if(!lib) return;
    var col=idx%ptCols,row=Math.floor(idx/ptCols);
    var px=DX+col*(ptW+4);
    var py=pinTopY+14+row*(ptH+8);
    if(py+ptH>tbTopY-4)return; // overflow protection
    var m=connMap[nd.id];
    var itemN=nd.itemNo||String.fromCharCode(65+idx);

    // Table background
    p('<rect x="'+px+'" y="'+py+'" width="'+ptW+'" height="'+(ptHdrH+ptColHdrH+lib.pins*ptRowH+2)+'" fill="#fff" stroke="#b0a890" stroke-width="0.8"/>');
    // Header
    p('<rect x="'+px+'" y="'+py+'" width="'+ptW+'" height="'+ptHdrH+'" fill="#c4bfb0"/>');
    p('<rect x="'+px+'" y="'+(py+ptHdrH)+'" width="'+ptW+'" height="'+ptColHdrH+'" fill="#dcd8cc"/>');
    // Title
    p('<text x="'+(px+5)+'" y="'+(py+11)+'" font-size="8.5" fill="#111" font-weight="bold">'+esc(nd.label||'?')+' — '+esc(lib.short)+' ('+lib.pins+'P)</text>');
    // Item balloon in header
    p('<circle cx="'+(px+ptW-12)+'" cy="'+(py+8)+'" r="7" fill="white" stroke="#222" stroke-width="1"/>');
    p('<text x="'+(px+ptW-12)+'" y="'+(py+11)+'" text-anchor="middle" font-size="7.5" fill="#111" font-weight="bold">'+esc(itemN)+'</text>');
    // Leader line to connector
    if(m){
      p('<line x1="'+(px+ptW-12)+'" y1="'+(py-2)+'" x2="'+m.x.toFixed(1)+'" y2="'+m.y.toFixed(1)+'" stroke="#aaa" stroke-width="0.7" stroke-dasharray="3,2.5"/>');
    }

    // Column widths
    var cws=[12, ptW*0.24-2, ptW*0.23-2, ptW*0.14-1, ptW*0.15-1, ptW*0.18-1];
    var cxs=[px+2];
    cws.forEach(function(w,i){if(i>0)cxs.push(cxs[i-1]+cws[i-1]);});
    var chdrs=['#','NAME','SIGNAL','AWG','CLR','→ TO'];
    chdrs.forEach(function(h,i){
      p('<text x="'+(cxs[i]+1)+'" y="'+(py+ptHdrH+9)+'" font-size="6.5" fill="#333" font-weight="bold">'+h+'</text>');
    });
    // Vertical column lines
    cxs.slice(1).forEach(function(cx2){
      p('<line x1="'+cx2+'" y1="'+py+'" x2="'+cx2+'" y2="'+(py+ptHdrH+ptColHdrH+lib.pins*ptRowH+2)+'" stroke="#ccc" stroke-width="0.4"/>');
    });

    // Pin rows
    lib.pinout.forEach(function(pp,i){
      var ry=py+ptHdrH+ptColHdrH+ptRowH*(i+1);
      if(i%2===0)p('<rect x="'+(px+1)+'" y="'+(ry-ptRowH+1)+'" width="'+(ptW-2)+'" height="'+ptRowH+'" fill="#f6f4ee"/>');
      var wfp=null;
      (S.wires||[]).forEach(function(w){
        if((w.fromEl===nd.id&&String(w.fromPin)===String(pp.id))||(w.toEl===nd.id&&String(w.toPin)===String(pp.id)))wfp=w;
      });
      var toPin='—';
      if(wfp){
        var oe=null;
        (S.elements||[]).forEach(function(e){if(e.id===(wfp.fromEl===nd.id?wfp.toEl:wfp.fromEl))oe=e;});
        toPin=(oe?oe.label||'?':'?')+'.'+( wfp.fromEl===nd.id?wfp.toPin:wfp.fromPin);
      }
      // Text columns
      var rowData=[pp.id, pp.n.substring(0,12), (wfp?wfp.signal||pp.sig:pp.sig).substring(0,8), pp.g.substring(0,6)];
      rowData.forEach(function(d,ci){
        p('<text x="'+(cxs[ci]+1)+'" y="'+ry+'" font-size="'+(ci===0?7.5:7)+'" fill="'+(ci===0?'#336699':'#111')+'"'+(ci===0?' font-weight="bold"':'')+'>'+esc(String(d))+'</text>');
      });
      // Color swatch
      p('<circle cx="'+(cxs[4]+7)+'" cy="'+(ry-4)+'" r="4" fill="'+sc(pp.c)+'" stroke="rgba(0,0,0,0.5)" stroke-width="0.5"/>');
      // To-pin
      p('<text x="'+(cxs[5]+1)+'" y="'+ry+'" font-size="6.5" fill="#336699" font-weight="bold">'+esc(toPin.substring(0,10))+'</text>');
      // Row bottom line
      p('<line x1="'+(px+1)+'" y1="'+(ry+1.5)+'" x2="'+(px+ptW-1)+'" y2="'+(ry+1.5)+'" stroke="#e0dbd0" stroke-width="0.4"/>');
    });
  });

  // ══════════════════════════════════════════════
  // NOTES
  // ══════════════════════════════════════════════
  var NX=DX, NY=tbTopY+2, NW=Math.round(DW*0.52), NH=TB_H-3;
  p('<rect x="'+NX+'" y="'+NY+'" width="'+NW+'" height="'+NH+'" fill="#f8f7f2" stroke="#888" stroke-width="0.7"/>');
  // "NOTES" vertical side
  p('<rect x="'+NX+'" y="'+NY+'" width="20" height="'+NH+'" fill="#c4bfb0"/>');
  p('<text x="'+(NX+10)+'" y="'+(NY+NH/2+4)+'" text-anchor="middle" font-size="8" fill="#333" font-weight="bold" transform="rotate(-90,'+(NX+10)+','+(NY+NH/2)+')">NOTES</text>');
  var notes=(S.notes&&S.notes.length?S.notes:[]);
  notes.forEach(function(note,i){
    var ty=NY+12+i*12;
    if(ty>NY+NH-4)return;
    p('<circle cx="'+(NX+28)+'" cy="'+(ty-4)+'" r="5.5" fill="none" stroke="#333" stroke-width="1.1"/>');
    p('<text x="'+(NX+28)+'" y="'+(ty-1)+'" text-anchor="middle" font-size="6.5" fill="#333" font-weight="bold">'+(i+1)+'</text>');
    p('<text x="'+(NX+39)+'" y="'+ty+'" font-size="7" fill="#222">'+esc(note.length>90?note.substring(0,88)+'…':note)+'</text>');
  });

  // ══════════════════════════════════════════════
  // BOM (right of notes inside title block area)
  // ══════════════════════════════════════════════
  var BX=NX+NW+2, BY=tbTopY+2, BW=DW-NW-2, BH=NH;
  p('<rect x="'+BX+'" y="'+BY+'" width="'+BW+'" height="'+BH+'" fill="#f8f7f2" stroke="#888" stroke-width="0.7"/>');
  p('<rect x="'+BX+'" y="'+BY+'" width="'+BW+'" height="14" fill="#c4bfb0"/>');
  p('<text x="'+(BX+BW/2)+'" y="'+(BY+10)+'" text-anchor="middle" font-size="8" fill="#111" font-weight="bold" letter-spacing="1">BILL OF MATERIALS</text>');

  // BOM column headers
  var bCws=[18,BW*0.27,BW*0.37,22,20];
  var bCxs=[BX+1];
  bCws.forEach(function(w,i){if(i>0)bCxs.push(bCxs[i-1]+bCws[i-1]);});
  p('<rect x="'+BX+'" y="'+(BY+14)+'" width="'+BW+'" height="10" fill="#ddd9cc"/>');
  ['#','PART NUMBER','DESCRIPTION','QTY','UN'].forEach(function(h,i){
    p('<text x="'+(bCxs[i]+1)+'" y="'+(BY+22)+'" font-size="6" fill="#333" font-weight="bold">'+h+'</text>');
  });
  bCxs.slice(1).forEach(function(cx2){
    p('<line x1="'+cx2+'" y1="'+BY+'" x2="'+cx2+'" y2="'+(BY+BH)+'" stroke="#ccc" stroke-width="0.4"/>');
  });

  var bomAll=[];
  hNodes.filter(function(n){return!n.isJunction&&CL[n.connId];}).forEach(function(nd){
    var lib=CL[nd.connId];if(!lib)return;
    bomAll.push({pn:lib.pn||'—',desc:lib.name,qty:1,unit:'EA'});
  });
  (S.bomItems||[]).forEach(function(it){bomAll.push({pn:it.pn||'—',desc:it.desc,qty:it.qty,unit:it.unit});});

  var bRH=9;
  bomAll.forEach(function(it,i){
    var ry=BY+24+bRH*(i+1);
    if(ry>BY+BH-2)return;
    if(i%2===0)p('<rect x="'+(BX+1)+'" y="'+(ry-bRH+1)+'" width="'+(BW-2)+'" height="'+bRH+'" fill="#f4f2ec"/>');
    p('<text x="'+(bCxs[0]+1)+'" y="'+ry+'" font-size="6.5" fill="#336699" font-weight="bold">'+(i+1)+'</text>');
    p('<text x="'+(bCxs[1]+1)+'" y="'+ry+'" font-size="6" fill="#222">'+esc(String(it.pn).substring(0,18))+'</text>');
    p('<text x="'+(bCxs[2]+1)+'" y="'+ry+'" font-size="6" fill="#222">'+esc(String(it.desc).substring(0,24))+'</text>');
    p('<text x="'+(bCxs[3]+1)+'" y="'+ry+'" font-size="6" fill="#333" text-anchor="middle">'+it.qty+'</text>');
    p('<text x="'+(bCxs[4]+1)+'" y="'+ry+'" font-size="6" fill="#555">'+esc(it.unit)+'</text>');
    p('<line x1="'+(BX+1)+'" y1="'+(ry+1)+'" x2="'+(BX+BW-1)+'" y2="'+(ry+1)+'" stroke="#e4e0d8" stroke-width="0.3"/>');
  });

  // RoHS + weight
  p('<rect x="'+(BX+BW-44)+'" y="'+(BY+BH-14)+'" width="41" height="12" fill="none" stroke="#27ae60" stroke-width="1.5"/>');
  p('<text x="'+(BX+BW-23)+'" y="'+(BY+BH-5)+'" text-anchor="middle" font-size="7" fill="#27ae60" font-weight="bold">RoHS ✓</text>');

  // ══════════════════════════════════════════════
  // TITLE BLOCK (far right of bottom strip)
  // ══════════════════════════════════════════════
  var TX=DX+DW+2, TY=MT+4, TW=PW-TX-MR-3, TH=PH-MT-MB-8;
  p('<rect x="'+TX+'" y="'+TY+'" width="'+TW+'" height="'+TH+'" fill="#f0ede4" stroke="#333" stroke-width="1.2"/>');

  // Company logo area
  var logoH=40;
  p('<rect x="'+TX+'" y="'+TY+'" width="'+TW+'" height="'+logoH+'" fill="#e4e0d4" stroke-bottom="#333"/>');
  p('<line x1="'+TX+'" y1="'+(TY+logoH)+'" x2="'+(TX+TW)+'" y2="'+(TY+logoH)+'" stroke="#333" stroke-width="0.8"/>');
  p('<text x="'+(TX+TW/2)+'" y="'+(TY+16)+'" text-anchor="middle" font-size="14" fill="#222" font-weight="bold" letter-spacing="2">'+esc(S.company||'COMPANY')+'</text>');
  p('<text x="'+(TX+TW/2)+'" y="'+(TY+30)+'" text-anchor="middle" font-size="7" fill="#555" letter-spacing="1">ENGINEERING DRAWING</text>');

  // Field rows
  var fields=[
    ['TITLE',S.title||'—',true],
    ['DESCRIPTION','Cable Harness Assembly',false],
    ['PART NUMBER',S.partNo||'—',true],
    ['DWG NUMBER',S.dwgNo||'—',true],
  ];
  var fY=TY+logoH+2,fH=18;
  fields.forEach(function(f){
    p('<rect x="'+TX+'" y="'+fY+'" width="'+TW+'" height="'+fH+'" fill="none" stroke="#ccc" stroke-width="0.4"/>');
    p('<text x="'+(TX+3)+'" y="'+(fY+8)+'" font-size="6" fill="#888" font-weight="bold" letter-spacing="0.5">'+f[0]+'</text>');
    p('<text x="'+(TX+3)+'" y="'+(fY+15)+'" font-size="'+(f[2]?9.5:8)+'" fill="#111" font-weight="'+(f[2]?'bold':'normal')+'">'+esc(f[1])+'</text>');
    fY+=fH;
  });

  // Grid of fields (2-col)
  var gridFields=[
    ['REV',S.rev||'A'],['DRAWN BY',S.drawnBy||'—'],
    ['DATE',today],['SCALE','NTS'],
    ['SHEET','1 / 1'],['TOLERANCE','±'+S.lengthTol+'mm'],
  ];
  var gfH=16, gfW=TW/2;
  gridFields.forEach(function(f,i){
    var gx=TX+(i%2)*gfW, gy=fY+Math.floor(i/2)*gfH;
    p('<rect x="'+gx+'" y="'+gy+'" width="'+gfW+'" height="'+gfH+'" fill="none" stroke="#ccc" stroke-width="0.4"/>');
    p('<text x="'+(gx+3)+'" y="'+(gy+7)+'" font-size="5.5" fill="#888" font-weight="bold">'+f[0]+'</text>');
    p('<text x="'+(gx+3)+'" y="'+(gy+13)+'" font-size="8.5" fill="#111" font-weight="bold">'+esc(f[1])+'</text>');
  });

  p('</svg>');

  sheets.push(svg.join('\n'));
  return sheets;
}

// ── Render ──
function render(){ if(typeof dwgRegen==="function") dwgRegen(); }


// ═══════════════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════════════
function showTab(id,btn){
  document.querySelectorAll(".tab").forEach(function(t){t.classList.remove("on");});
  document.querySelectorAll(".panel").forEach(function(p){p.classList.remove("on");});
  if(btn) btn.classList.add("on");
  var panel=document.getElementById("panel-"+id);
  if(panel) panel.classList.add("on");
  if(id==="canvas") setTimeout(resizeCanvas,50);
  if(id==="harness"){setTimeout(function(){renderHarness();},50);}
  if(id==="connectors") renderConnectorEditor();
}

function setTheme(v){document.body.className=v;localStorage.setItem("moti_theme",v);}

function exportJSON(){
  var d={version:"v6",state:JSON.parse(JSON.stringify(S)),harness:JSON.parse(JSON.stringify(H)),exportedAt:new Date().toISOString()};
  var b=new Blob([JSON.stringify(d,null,2)],{type:"application/json"});
  var a=document.createElement("a");a.href=URL.createObjectURL(b);
  a.download="MOTI_"+(S.dwgNo||"project")+"_"+new Date().toISOString().slice(0,10)+".json";
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast("Project exported");
}
function importJSON(input){
  var file=input.files[0];if(!file)return;
  var reader=new FileReader();
  reader.onload=function(ev){
    try{
      var d=JSON.parse(ev.target.result);
      if(!confirm("Import project? This will replace current data."))return;
      var st=d.state||d;
      for(var k in st)S[k]=st[k];
      if(d.harness){H.nodes=d.harness.nodes||[];H.segs=d.harness.segs||[];}
      syncCustomConnectors();saveState();buildSidebar();renderAll();syncTBAll();
      toast("Imported successfully");
    }catch(e){toast("Import error: "+e.message,true);}
  };
  reader.readAsText(file);input.value="";
}
function saveHTML(){
  var b=new Blob([document.documentElement.outerHTML],{type:"text/html"});
  var a=document.createElement("a");a.href=URL.createObjectURL(b);
  a.download="MOTI_"+(S.dwgNo||"project")+".html";
  document.body.appendChild(a);a.click();document.body.removeChild(a);
}
function renderAll(){
  saveState();renderDrawing();renderRoutes();renderBOM();renderCutList();renderCanvas();
}
function syncTBAll(){
  function stb(id,val){var e=document.getElementById(id);if(e)e.value=val||"";}
  stb("tb-title",S.title);stb("tb-pn",S.partNo);stb("tb-dwg",S.dwgNo);
  stb("tb-rev",S.rev);stb("tb-co",S.company);stb("tb-drawn",S.drawnBy);
  stb("tb-len",S.cableLength);stb("tb-tol",S.lengthTol);
}

loadState();
syncCustomConnectors();
var th=localStorage.getItem("moti_theme")||"";
document.body.className=th;
var thSel=document.getElementById("th-sel");if(thSel)thSel.value=th;
syncTBAll();
buildSidebar();
initCanvas();
renderAll();
setTool("select");


