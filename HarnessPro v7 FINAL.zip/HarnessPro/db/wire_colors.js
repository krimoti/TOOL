/* MOTI HarnessPro — Wire Color Standards */


/* ============================================================
   WIRE_COLORS.JS — Wire color standards
   IEC 60757 / DIN 47100 / ICEA + custom combinations
   MOTI HarnessPro
   ============================================================ */

/* ── IEC 60757 / DIN 47100 base colors (number → color) ── */
var WIRE_COLORS_IEC = [
  { code:0,  abbr:'BK', name:'Black',       hex:'#1a1a1a', textColor:'#fff' },
  { code:1,  abbr:'BN', name:'Brown',       hex:'#7b3f00', textColor:'#fff' },
  { code:2,  abbr:'RD', name:'Red',         hex:'#e74c3c', textColor:'#fff' },
  { code:3,  abbr:'OG', name:'Orange',      hex:'#e67e22', textColor:'#fff' },
  { code:4,  abbr:'YE', name:'Yellow',      hex:'#f1c40f', textColor:'#111' },
  { code:5,  abbr:'GN', name:'Green',       hex:'#27ae60', textColor:'#fff' },
  { code:6,  abbr:'BU', name:'Blue',        hex:'#2980b9', textColor:'#fff' },
  { code:7,  abbr:'VT', name:'Violet',      hex:'#8e44ad', textColor:'#fff' },
  { code:8,  abbr:'GY', name:'Grey',        hex:'#95a5a6', textColor:'#111' },
  { code:9,  abbr:'WH', name:'White',       hex:'#ecf0f1', textColor:'#111' },
  { code:10, abbr:'PK', name:'Pink',        hex:'#ff69b4', textColor:'#111' },
  { code:11, abbr:'TQ', name:'Turquoise',   hex:'#1abc9c', textColor:'#fff' },
];

/* ── Grounding / Earth (IEC 60446) ── */
var WIRE_COLOR_GND = { code:'PE', abbr:'GNYE', name:'Green-Yellow (Earth)', hex:'#27ae60', hex2:'#f1c40f', textColor:'#fff', isStripe:true };

/* ── Standard combinations (base + stripe) ── */
var WIRE_COLOR_COMBOS = [
  /* Most common combos in aerospace/industrial */
  { abbr:'BK/WH', name:'Black / White',   c1:'#1a1a1a', c2:'#ecf0f1' },
  { abbr:'BK/RD', name:'Black / Red',     c1:'#1a1a1a', c2:'#e74c3c' },
  { abbr:'BK/BU', name:'Black / Blue',    c1:'#1a1a1a', c2:'#2980b9' },
  { abbr:'BK/YE', name:'Black / Yellow',  c1:'#1a1a1a', c2:'#f1c40f' },
  { abbr:'RD/WH', name:'Red / White',     c1:'#e74c3c', c2:'#ecf0f1' },
  { abbr:'RD/BK', name:'Red / Black',     c1:'#e74c3c', c2:'#1a1a1a' },
  { abbr:'RD/BU', name:'Red / Blue',      c1:'#e74c3c', c2:'#2980b9' },
  { abbr:'WH/BK', name:'White / Black',   c1:'#ecf0f1', c2:'#1a1a1a' },
  { abbr:'WH/RD', name:'White / Red',     c1:'#ecf0f1', c2:'#e74c3c' },
  { abbr:'WH/BU', name:'White / Blue',    c1:'#ecf0f1', c2:'#2980b9' },
  { abbr:'WH/BN', name:'White / Brown',   c1:'#ecf0f1', c2:'#7b3f00' },
  { abbr:'WH/GN', name:'White / Green',   c1:'#ecf0f1', c2:'#27ae60' },
  { abbr:'BU/WH', name:'Blue / White',    c1:'#2980b9', c2:'#ecf0f1' },
  { abbr:'BU/RD', name:'Blue / Red',      c1:'#2980b9', c2:'#e74c3c' },
  { abbr:'GN/YE', name:'Green / Yellow',  c1:'#27ae60', c2:'#f1c40f' },  /* Earth */
  { abbr:'YE/GN', name:'Yellow / Green',  c1:'#f1c40f', c2:'#27ae60' },
  { abbr:'BN/WH', name:'Brown / White',   c1:'#7b3f00', c2:'#ecf0f1' },
  { abbr:'OG/WH', name:'Orange / White',  c1:'#e67e22', c2:'#ecf0f1' },
  { abbr:'GY/WH', name:'Grey / White',    c1:'#95a5a6', c2:'#ecf0f1' },
  { abbr:'VT/WH', name:'Violet / White',  c1:'#8e44ad', c2:'#ecf0f1' },
];

/* ── ICEA/NEMA color sequence (for multi-conductor cables) ── */
var WIRE_COLORS_ICEA = [
  { code:1,  abbr:'BK',    name:'Black',        hex:'#1a1a1a' },
  { code:2,  abbr:'WH',    name:'White',        hex:'#ecf0f1' },
  { code:3,  abbr:'RD',    name:'Red',          hex:'#e74c3c' },
  { code:4,  abbr:'GN',    name:'Green',        hex:'#27ae60' },
  { code:5,  abbr:'OG',    name:'Orange',       hex:'#e67e22' },
  { code:6,  abbr:'BU',    name:'Blue',         hex:'#2980b9' },
  { code:7,  abbr:'WH/BK', name:'White/Black',  hex:'#ecf0f1', hex2:'#1a1a1a', isStripe:true },
  { code:8,  abbr:'RD/BK', name:'Red/Black',    hex:'#e74c3c', hex2:'#1a1a1a', isStripe:true },
  { code:9,  abbr:'GN/BK', name:'Green/Black',  hex:'#27ae60', hex2:'#1a1a1a', isStripe:true },
  { code:10, abbr:'OG/BK', name:'Orange/Black', hex:'#e67e22', hex2:'#1a1a1a', isStripe:true },
  { code:11, abbr:'BU/BK', name:'Blue/Black',   hex:'#2980b9', hex2:'#1a1a1a', isStripe:true },
  { code:12, abbr:'WH/RD', name:'White/Red',    hex:'#ecf0f1', hex2:'#e74c3c', isStripe:true },
];

/* ── Get next sequential color by standard ── */
function getNextWireColor(standard, index) {
  standard = standard || 'IEC';
  var list = standard === 'ICEA' ? WIRE_COLORS_ICEA : WIRE_COLORS_IEC;
  var item = list[index % list.length];
  return { hex: item.hex, hex2: item.hex2||null, abbr: item.abbr, name: item.name, isStripe: !!item.hex2 };
}

/* ── Render wire color swatch SVG (stripe if combo) ── */
function wireColorSwatch(hex, hex2, size) {
  size = size || 16;
  if(!hex2) {
    return '<span style="display:inline-block;width:'+size+'px;height:'+size+'px;border-radius:3px;background:'+hex+';border:1px solid rgba(0,0,0,0.3);vertical-align:middle"></span>';
  }
  // Diagonal stripe
  return '<svg width="'+size+'" height="'+size+'" style="vertical-align:middle;border-radius:3px;border:1px solid rgba(0,0,0,0.3)">'
    +'<rect width="'+size+'" height="'+size+'" fill="'+hex+'"/>'
    +'<polygon points="'+size+',0 '+size+','+size+' 0,'+size+'" fill="'+hex2+'"/>'
    +'</svg>';
}

/* ── Color picker HTML for wire editing ── */
function renderColorPicker(currentHex, currentHex2, onChangeFn, standard) {
  standard = standard || 'IEC';
  var list = standard === 'ICEA' ? WIRE_COLORS_ICEA : WIRE_COLORS_IEC;
  var combos = WIRE_COLOR_COMBOS;

  var h = '<div style="background:var(--bg1);border:1px solid var(--border2);padding:8px;font-size:8px">';
  h += '<div style="color:var(--text3);margin-bottom:6px;letter-spacing:1px">STANDARD: ';
  h += '<select style="background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:1px 4px;font-size:8px" onchange="changeColorStd(this.value)">';
  ['IEC','ICEA','DIN'].forEach(function(s){ h+='<option'+(standard===s?' selected':'')+'>'+s+'</option>'; });
  h += '</select></div>';

  // Base colors
  h += '<div style="color:var(--text3);margin-bottom:4px">BASE COLORS ('+standard+'):</div>';
  h += '<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px">';
  list.forEach(function(c){
    var active = c.hex===currentHex && !currentHex2;
    h += '<div onclick="'+onChangeFn+'(\''+c.hex+'\',null,\''+esc(c.abbr)+'\')" '
      +'title="'+c.code+' — '+c.name+' ('+c.abbr+')" '
      +'style="cursor:pointer;padding:2px 5px;border:1.5px solid '+(active?'var(--accent)':'var(--border2)')+';'
      +'background:var(--bg2);display:flex;align-items:center;gap:4px;border-radius:2px">'
      +wireColorSwatch(c.hex, null, 12)
      +'<span style="color:'+(active?'var(--accent)':'var(--text2)')+'">'+(c.code)+' '+c.abbr+'</span></div>';
  });
  // Earth
  h += '<div onclick="'+onChangeFn+'(\'#27ae60\',\'#f1c40f\',\'GNYE\')" '
    +'title="PE — Green/Yellow Earth" '
    +'style="cursor:pointer;padding:2px 5px;border:1.5px solid var(--border2);background:var(--bg2);display:flex;align-items:center;gap:4px;border-radius:2px">'
    +wireColorSwatch('#27ae60','#f1c40f',12)
    +'<span style="color:var(--text2)">PE GNYE</span></div>';
  h += '</div>';

  // Combos
  h += '<div style="color:var(--text3);margin-bottom:4px">COMBINATIONS:</div>';
  h += '<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:6px">';
  combos.forEach(function(c){
    var active = c.c1===currentHex && c.c2===currentHex2;
    h += '<div onclick="'+onChangeFn+'(\''+c.c1+'\',\''+c.c2+'\',\''+esc(c.abbr)+'\')" '
      +'title="'+c.name+'" '
      +'style="cursor:pointer;padding:2px 5px;border:1.5px solid '+(active?'var(--accent)':'var(--border2)')+';'
      +'background:var(--bg2);display:flex;align-items:center;gap:4px;border-radius:2px">'
      +wireColorSwatch(c.c1,c.c2,12)
      +'<span style="color:'+(active?'var(--accent)':'var(--text2)')+'">'+c.abbr+'</span></div>';
  });
  h += '</div>';

  // Custom hex
  h += '<div style="display:flex;align-items:center;gap:6px">'
    +'<span style="color:var(--text3)">CUSTOM:</span>'
    +'<input type="color" value="'+(currentHex||'#888888')+'" style="width:28px;height:20px;border:none;padding:0;cursor:pointer" '
    +'oninput="'+onChangeFn+'(this.value,null,\'CUSTOM\')"/>'
    +'</div>';

  h += '</div>';
  return h;
}
