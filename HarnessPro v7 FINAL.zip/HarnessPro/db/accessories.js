/* MOTI HarnessPro — Accessories */


var ACCESSORIES = [
  {id:"HS-3",  name:"Heat Shrink 3mm",   type:"heatshrink", color:"#222", symbol:"HS"},
  {id:"HS-6",  name:"Heat Shrink 6mm",   type:"heatshrink", color:"#222", symbol:"HS"},
  {id:"HS-10", name:"Heat Shrink 10mm",  type:"heatshrink", color:"#555", symbol:"HS"},
  {id:"SP-5",  name:"Split Loom 5mm",    type:"sleeve",     color:"#1a3a1a", symbol:"SP"},
  {id:"SP-10", name:"Split Loom 10mm",   type:"sleeve",     color:"#1a3a1a", symbol:"SP"},
  {id:"BR-BL", name:"Braided Sleeve Black",type:"sleeve",   color:"#111", symbol:"BR"},
  {id:"TM-W",  name:"Wire Marker White", type:"marker",     color:"#eee", symbol:"M"},
  {id:"TM-Y",  name:"Wire Marker Yellow",type:"marker",     color:"#f39c12", symbol:"M"},
  {id:"FR-F",  name:"Ferrule 0.5mm",     type:"terminal",   color:"#e74c3c", symbol:"T"},
  {id:"FR-1",  name:"Ferrule 1.0mm",     type:"terminal",   color:"#3498db", symbol:"T"},
  {id:"FR-2",  name:"Ferrule 2.5mm",     type:"terminal",   color:"#27ae60", symbol:"T"},
  {id:"TIE",   name:"Cable Tie",         type:"cable_tie",  color:"#eee", symbol:"Z"}
];

function mkpins(n,pre,sig,awg,hStep){
  var r=[];
  for(var i=0;i<n;i++) r.push({id:i+1,n:pre+(i+1),sig:sig,g:awg,c:hslc(i*hStep)});
  return r;
}
function hslc(h){return "hsl("+h+",65%,45%)";}
function uid(){return "e"+Date.now().toString(36)+Math.random().toString(36).slice(2,5);}
function esc(s){return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}
function sc(c){return(c&&(c[0]=="#"||c.indexOf("hsl")===0||c.indexOf("rgb")===0))?c:"#888";}
function clamp(v,a,b){return v<a?a:v>b?b:v;}
function toast(msg,err){
  var t=document.getElementById("toast");
  t.textContent=msg; t.className="toast"+(err?" err":"")+" show";
  clearTimeout(t._tid); t._tid=setTimeout(function(){t.className="toast"+(err?" err":"");},2200);
}

// ============================================================
// STATE
// ============================================================
var S = {
  elements:[], wires:[], dimensions:[],
  title:"ASS'Y CABLE", partNo:"LMA-5528-NCA", dwgNo:"RFQ#001-01",
  rev:"A", drawnBy:"", company:"", cableLength:500, lengthTol:20,
  notes:["No open/short or intermittent failures.",
         "100% electrical test required.",
         "Voltage test: DC 300V; Insulation: 5M ohm min.",
         "All dimensions in mm unless noted. RoHS Compliant."],
  bomItems:[], zoom:1, panX:50, panY:50,
  nextConnLabel:1,
  canvasFontSize:9,
  customConnectors:[]  // <-- NEW: array of user-defined connectors
};

function loadState(){
  try{
    var d=JSON.parse(localStorage.getItem("moti_v5")||"{}");
    for(var k in d) if(k!=="elements"&&k!=="wires") S[k]=d[k];
    if(d.elements) S.elements=d.elements;
    if(d.wires) S.wires=d.wires;
    if(d.dimensions) S.dimensions=d.dimensions;
    if(d.customConnectors) S.customConnectors=d.customConnectors;
  }catch(e){}
}
function saveState(){
  try{localStorage.setItem("moti_v5",JSON.stringify(S));}catch(e){}
}

// Merge custom connectors into CL runtime dict
function syncCustomConnectors(){
  // Remove previously synced custom entries
  for(var k in CL){ if(!CL[k].builtin) delete CL[k]; }
  // Add current custom connectors
  for(var i=0;i<S.customConnectors.length;i++){
    var cc=S.customConnectors[i];
    CL[cc.id]=cc;
  }
}

// ============================================================