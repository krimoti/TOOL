'use strict';
/* UI: Panels - Wire List, BOM, CutList, PartDB */


function renderRoutes(){
  var connEls = S.elements.filter(function(e){return e.kind==='connector';});
  var gauges  = ['10AWG','12AWG','14AWG','16AWG','18AWG','20AWG','22AWG','24AWG','26AWG','28AWG','30AWG'];
  var wl      = null; /* wire-level validation done inline per row */
  var fi      = 'background:var(--bg1);border:1px solid var(--border);color:var(--accent);padding:2px 3px;font-size:8px;font-family:monospace';

  /* ── Top bar ── */
  var h = '<div style="display:flex;flex-direction:column;height:100%;overflow:hidden">';
  h += '<div style="padding:8px 12px;background:var(--bg0);border-bottom:1px solid var(--border);flex-shrink:0;display:flex;gap:6px;align-items:center;flex-wrap:wrap">';
  h += '<span style="font-size:10px;color:var(--accent);letter-spacing:2px;font-weight:bold">WIRE LIST</span>';
  h += '<span style="color:var(--text3);font-size:8px">'+S.wires.length+' wires</span>';
  h += '<span style="flex:1"></span>';
  h += '<button class="btn btn-g" onclick="addWireRow()">+ WIRE</button>';
  h += '<button class="btn btn-g" onclick="wireAutoNumber()" title="Auto-assign wire numbers">AUTO #</button>';
  h += '<button class="btn" onclick="clearWires()" title="Remove all wires">CLEAR ALL</button>';
  h += '<button class="btn" onclick="exportP2P()" style="border-color:#1a3a20;color:#5ab04a" title="Export wire list to CSV">EXPORT CSV</button>';
  h += '</div>';

  /* ── Summary strip ── */
  var cuts=0, mismatch=0;
  S.wires.forEach(function(w){ if(w.active!==false){ cuts++; } });
  /* AWG mismatch counted per row below */
  h += '<div style="padding:4px 12px;background:var(--bg1);border-bottom:1px solid var(--border);flex-shrink:0;display:flex;gap:16px;font-size:8px">';
  h += '<span style="color:var(--text2)">ACTIVE: <b style="color:var(--accent)">'+cuts+'</b></span>';
  h += '<span style="color:var(--text2)">CUT LEN: <b style="color:var(--accent)">'+(S.cableLength+S.stripFrom+S.stripTo)+' mm</b></span>';
  h += '<span style="color:var(--text2)">STRIP: <b>'+S.stripFrom+'/'+S.stripTo+' mm</b></span>';
  if(mismatch>0) h += '<span style="color:#e74c3c;font-weight:bold">&#9679; '+mismatch+' AWG MISMATCH</span>';
  h += '</div>';

  /* ── Wire table ── */
  h += '<div style="flex:1;overflow:auto">';
  h += '<table class="rt"><thead><tr style="position:sticky;top:0;z-index:2">';
  h += '<th style="width:28px">ON</th>';
  h += '<th style="width:68px">WIRE #</th>';
  h += '<th>FROM</th><th>F.PIN</th>';
  h += '<th>TO</th><th>T.PIN</th>';
  h += '<th>SIGNAL</th>';
  h += '<th>AWG</th>';
  h += '<th style="width:90px">COLOR</th>';
  h += '<th style="width:60px">CUT mm</th>';
  h += '<th style="width:28px">DEL</th>';
  h += '</tr></thead><tbody>';

  for(var i=0;i<S.wires.length;i++){
    var w=S.wires[i], wid=w.id;
    var active = (w.active!==false);
    var safeC  = (w.color && w.color[0]==='#') ? w.color : '#888888';
    var safeC2 = w.color2 || null;
    var abbr   = w.colorAbbr || iecAbbr(safeC, safeC2);
    var fLib   = w.fromEl ? getElLib(w.fromEl) : null;
    var tLib   = w.toEl   ? getElLib(w.toEl)   : null;

    /* AWG mismatch highlight */
    var awgWarn = false;
    if(fLib && w.gauge) fLib.pinout.forEach(function(p){
      if(String(p.id)===String(w.fromPin) && p.g){
        var wn=parseInt(w.gauge), pn=parseInt(p.g);
        if(!isNaN(wn)&&!isNaN(pn)&&wn>pn+2) awgWarn=true;
      }
    });

    var rowBg = !active ? 'opacity:0.45;' : awgWarn ? 'background:rgba(180,30,30,0.08);' : '';
    h += '<tr style="'+rowBg+'">';

    /* Active checkbox */
    h += '<td style="text-align:center"><input type="checkbox"'+(active?' checked':'');
    h += ' onchange="wUpd(\''+wid+'\',\'active\',this.checked)"/></td>';

    /* Wire number */
    h += '<td><input value="'+esc(w.wireNum||'')+'\" style="'+fi+';width:60px"';
    h += ' placeholder="auto" oninput="wUpd(\''+wid+'\',\'wireNum\',this.value)"/></td>';

    /* FROM connector */
    h += '<td><select style="'+fi+';width:58px" onchange="wUpd(\''+wid+'\',\'fromEl\',this.value)">';
    h += '<option value="">--</option>';
    connEls.forEach(function(el){
      h += '<option value="'+el.id+'"'+(w.fromEl===el.id?' selected':'')+'>'+esc(el.label)+'</option>';
    });
    h += '</select></td>';

    /* FROM pin */
    h += '<td><select style="'+fi+';width:80px" onchange="wUpd(\''+wid+'\',\'fromPin\',this.value)">';
    h += '<option value="">--</option>';
    if(fLib) fLib.pinout.forEach(function(p){
      h += '<option value="'+p.id+'"'+(String(w.fromPin)===String(p.id)?' selected':'')+'>'+p.id+' '+esc(p.n)+'</option>';
    });
    h += '</select></td>';

    /* TO connector */
    h += '<td><select style="'+fi+';width:58px" onchange="wUpd(\''+wid+'\',\'toEl\',this.value)">';
    h += '<option value="">--</option>';
    connEls.forEach(function(el){
      h += '<option value="'+el.id+'"'+(w.toEl===el.id?' selected':'')+'>'+esc(el.label)+'</option>';
    });
    h += '</select></td>';

    /* TO pin */
    h += '<td><select style="'+fi+';width:80px" onchange="wUpd(\''+wid+'\',\'toPin\',this.value)">';
    h += '<option value="">--</option>';
    if(tLib) tLib.pinout.forEach(function(p){
      h += '<option value="'+p.id+'"'+(String(w.toPin)===String(p.id)?' selected':'')+'>'+p.id+' '+esc(p.n)+'</option>';
    });
    h += '</select></td>';

    /* Signal */
    h += '<td><input value="'+esc(w.signal||'')+'" style="'+fi+';width:70px"';
    h += ' placeholder="VCC, GND..." oninput="wUpd(\''+wid+'\',\'signal\',this.value)"/></td>';

    /* AWG */
    h += '<td><select style="'+fi+(awgWarn?';color:#e74c3c':'')+'" onchange="wUpd(\''+wid+'\',\'gauge\',this.value)">';
    gauges.forEach(function(g){ h += '<option'+(w.gauge===g?' selected':'')+'>'+g+'</option>'; });
    h += '</select>'+(awgWarn?'<span title="AWG too thin for pin spec" style="color:#e74c3c;font-size:10px">!</span>':'')+'</td>';

    /* Color — swatch + IEC picker */
    h += '<td style="text-align:center;white-space:nowrap">';
    if(safeC2){
      h += '<svg width="22" height="14" style="vertical-align:middle;border:1px solid #444;border-radius:2px"><rect width="22" height="14" fill="'+safeC+'"/><polygon points="22,0 22,14 0,14" fill="'+safeC2+'"/></svg>';
    } else {
      h += '<span style="display:inline-block;width:14px;height:14px;border-radius:2px;background:'+safeC+';border:1px solid rgba(0,0,0,0.4);vertical-align:middle"></span>';
    }
    h += ' <span style="font-size:7px;color:var(--text3)">'+esc(abbr)+'</span>';
    h += ' <button onclick="openColorPicker(\''+wid+'\')" style="background:none;border:1px solid var(--border);color:var(--text2);cursor:pointer;font-size:7px;padding:1px 4px">IEC</button>';
    h += '</td>';

    /* Cut length */
    var cutL = (S.cableLength||0) + (S.stripFrom||0) + (S.stripTo||0);
    h += '<td style="text-align:center;font-weight:bold;color:var(--accent);font-size:9px">'+cutL+'</td>';

    /* Delete */
    h += '<td style="text-align:center"><button class="del" onclick="delWire(\''+wid+'\')">&#215;</button></td>';
    h += '</tr>';
  }

  if(!S.wires.length){
    h += '<tr><td colspan="11" style="padding:30px;text-align:center;color:var(--text3)">';
    h += 'No wires. Use ROUTE tool on canvas or click + WIRE to add manually.</td></tr>';
  }

  h += '</tbody></table></div>';

  /* ── Unconnected pins ── */
  var connEls2 = S.elements.filter(function(e){return e.kind==='connector';});
  var unpinned = [];
  connEls2.forEach(function(el){
    var lib=CL[el.connId]; if(!lib) return;
    lib.pinout.forEach(function(p){
      if(p.n==='NC'||p.sig==='NC') return;
      var conn=S.wires.some(function(w){
        return (w.fromEl===el.id&&String(w.fromPin)===String(p.id))||
               (w.toEl===el.id&&String(w.toPin)===String(p.id));
      });
      if(!conn) unpinned.push((el.label||el.id)+'.'+p.id+' ('+p.n+')');
    });
  });
  if(unpinned.length){
    h += '<div style="padding:8px 12px;background:rgba(180,80,10,0.08);border-top:1px solid rgba(180,80,10,0.3);flex-shrink:0">';
    h += '<span style="font-size:8px;color:#f39c12;font-weight:bold">UNCONNECTED PINS ('+unpinned.length+'): </span>';
    h += '<span style="font-size:8px;color:var(--text3)">'+unpinned.slice(0,12).map(esc).join(' &bull; ')+'</span>';
    if(unpinned.length>12) h += '<span style="color:var(--text3);font-size:8px"> +' + (unpinned.length-12) + ' more</span>';
    h += '</div>';
  }

  h += '</div>';
  document.getElementById('panel-routes').innerHTML = h;
}


function getElLib(elId){for(var i=0;i<S.elements.length;i++){if(S.elements[i].id===elId&&S.elements[i].kind==="connector"){return CL[S.elements[i].connId];}}return null;}
function wUpd(id,k,v){for(var i=0;i<S.wires.length;i++){if(S.wires[i].id===id){S.wires[i][k]=v;break;}}saveState();renderCanvas();}
function addWireRow(){
  pushUndo();
  S.wires.push({id:uid(),wireNum:'',fromEl:'',fromPin:'',toEl:'',toPin:'',
    signal:'',gauge:'22AWG',color:'#888888',color2:null,colorAbbr:'GY',active:true});
  saveState(); renderRoutes();
}
function clearWires(){if(confirm("Clear all wires?")){S.wires=[];renderAll();}}
function delWire(id){S.wires=S.wires.filter(function(w){return w.id!==id;});renderAll();}

// ============================================================
// BOM + CUTLIST
// ============================================================
function renderBOM(){
  var h='<div style="padding:14px;flex:1;overflow:auto">';
  h+='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">';
  h+='<span style="font-size:11px;color:var(--accent);letter-spacing:2px">BILL OF MATERIALS</span>';
  h+='<button class="btn btn-g" onclick="generateBOM()" title="Auto-generate from canvas">AUTO</button><button class="btn" onclick="addBOM()">+ ADD</button></div>';
  h+='<table class="rt"><thead><tr><th>#</th><th>QTY</th><th>UNIT</th><th>PART NO.</th><th>DESCRIPTION</th><th>CAT</th><th>DEL</th></tr></thead><tbody>';
  for(var i=0;i<S.bomItems.length;i++){
    var it=S.bomItems[i],bid=it.id;
    var fi="background:var(--bg1);border:1px solid var(--border);color:var(--accent);padding:2px 3px;font-size:9px";
    h+='<tr><td style="text-align:center;font-weight:bold;color:var(--accent)">'+(i+1)+'</td>';
    h+='<td><input type="number" min="1" value="'+esc(it.qty||1)+'" style="'+fi+';width:45px" oninput="bUpd(\''+bid+'\',\'qty\',this.value)"/></td>';
    h+="<td><select style='"+fi+"' onchange=\"bUpd('"+bid+"','unit',this.value)\">";
    ["EA","M","FT","SET","LOT"].forEach(function(u){h+='<option'+(it.unit===u?" selected":"")+">"+u+"</option>";});
    h+='</select></td>';
    h+='<td><input value="'+esc(it.pn||"")+'" style="'+fi+';width:90px" oninput="bUpd(\''+bid+'\',\'pn\',this.value)"/></td>';
    h+='<td><input value="'+esc(it.desc||"")+'" style="'+fi+';width:180px" placeholder="Description" oninput="bUpd(\''+bid+'\',\'desc\',this.value)"/></td>';
    h+="<td><select style='"+fi+"' onchange=\"bUpd('"+bid+"','cat',this.value)\">";
    ["MATERIAL","HARDWARE","PURCHASED","REFERENCE"].forEach(function(c){h+='<option'+(it.cat===c?" selected":"")+">"+c+"</option>";});
    h+='</select></td>';
    h+='<td style="text-align:center"><button class="del" onclick="delBOM(\''+bid+'\')">&#215;</button></td></tr>';
  }
  h+='</tbody></table></div>';
  document.getElementById("panel-bom").innerHTML=h;
}
function bUpd(id,k,v){for(var i=0;i<S.bomItems.length;i++){if(S.bomItems[i].id===id){S.bomItems[i][k]=v;break;}}saveState();}

function generateBOM(){
  var added=0;
  S.elements.forEach(function(el){
    if(el.kind!=="connector")return;
    var lib=CL[el.connId]; if(!lib)return;
    var dup=false;
    S.bomItems.forEach(function(b){if(b.pn===(lib.pn||lib.id)||b.desc===lib.name)dup=true;});
    if(!dup){S.bomItems.push({id:uid(),qty:1,unit:"EA",pn:lib.pn||lib.id,desc:lib.name,cat:"PURCHASED"});added++;}
  });
  var gMap={};
  S.wires.forEach(function(w){if(w.active!==false&&w.gauge)gMap[w.gauge]=(gMap[w.gauge]||0)+1;});
  Object.keys(gMap).forEach(function(g){
    var dup=false;
    S.bomItems.forEach(function(b){if(b.desc&&b.desc.indexOf("wire "+g)>-1)dup=true;});
    if(!dup){S.bomItems.push({id:uid(),qty:Math.ceil(S.cableLength/1000*gMap[g]*1.15*10)/10,unit:"M",pn:"",desc:"Hook-up wire "+g+" x"+gMap[g],cat:"MATERIAL"});added++;}
  });
  if(!added){toast("BOM already up to date");return;}
  saveState();renderBOM();toast("Added "+added+" items to BOM");
}
function addBOM(){S.bomItems.push({id:uid(),qty:1,unit:"EA",pn:"",desc:"",cat:"MATERIAL"});renderAll();}
function delBOM(id){S.bomItems=S.bomItems.filter(function(b){return b.id!==id;});renderAll();}

function renderCutList(){
  var active=S.wires.filter(function(w){return w.active&&w.fromEl&&w.toEl;});
  var h='<div style="padding:14px;flex:1;overflow:auto">';
  h+='<div style="font-size:11px;color:var(--accent);letter-spacing:2px;margin-bottom:12px">CUT LIST</div>';
  h+='<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;padding:6px 10px;background:var(--bg1);border:1px solid var(--border);font-size:9px">';
  h+='<span style="color:var(--text3)">STRIP FROM: </span><input type="number" min="1" max="50" value="'+(S.stripFrom||8)+'" style="width:40px;background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:2px 4px;font-size:9px" oninput="S.stripFrom=+this.value;saveState();renderCutList()"/> mm';
  h+='<span style="color:var(--text3);margin-left:8px">STRIP TO: </span><input type="number" min="1" max="50" value="'+(S.stripTo||8)+'" style="width:40px;background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:2px 4px;font-size:9px" oninput="S.stripTo=+this.value;saveState();renderCutList()"/> mm</div>';
  h+='<table class="rt" style="max-width:760px"><thead><tr>';
  h+='<th>#</th><th>FROM</th><th>TO</th><th>SIGNAL</th><th>GAUGE</th><th>COLOR</th><th>CABLE mm</th><th>STRIP A</th><th>STRIP B</th><th>CUT mm</th></tr></thead><tbody>';
  active.forEach(function(w,i){
    var fEl=null,tEl=null;
    S.elements.forEach(function(e){if(e.id===w.fromEl)fEl=e;if(e.id===w.toEl)tEl=e;});
    h+='<tr><td style="text-align:center;color:var(--text2)">'+(i+1)+'</td>';
    h+='<td style="font-weight:bold;color:#5ab0f0">'+esc((fEl?fEl.label:"?")+"."+w.fromPin)+'</td>';
    h+='<td style="font-weight:bold;color:#5ab0f0">'+esc((tEl?tEl.label:"?")+"."+w.toPin)+'</td>';
    h+='<td>'+esc(w.signal||"--")+'</td><td style="text-align:center">'+esc(w.gauge)+'</td>';
    h+='<td style="text-align:center"><span style="display:inline-flex;align-items:center;gap:4px"><span style="display:inline-block;width:14px;height:14px;border-radius:50%;background:'+sc(w.color||"#888")+';border:1px solid #333"></span>'+esc(w.color)+'</span></td>';
    var sA=S.stripFrom||8,sB=S.stripTo||8;
    h+='<td style="text-align:center">'+S.cableLength+' +/-'+S.lengthTol+'</td>';
    h+='<td style="text-align:center;color:#7db84a">'+sA+'</td>';
    h+='<td style="text-align:center;color:#7db84a">'+sB+'</td>';
    h+='<td style="text-align:center;font-weight:bold;color:#c8a840">'+(S.cableLength+sA+sB)+' mm</td></tr>';
  });
  h+='<tr><td colspan="7" style="padding:8px 4px;color:var(--text2);font-size:9px;border-top:1px solid var(--border2)">Total: '+active.length+' wires | Length: '+S.cableLength+'mm +/-'+S.lengthTol+'mm</td></tr>';
  h+='</tbody></table></div>';
  document.getElementById("panel-cutlist").innerHTML=h;
}

// ============================================================
// MAIN RENDER + TABS
// ============================================================
function renderAll(){ setTimeout(runLVS,200);
  saveState();
  renderDrawing();
  renderRoutes();
  renderBOM();
  renderCutList();
  renderCanvas();
  // harness renders lazily when tab is active
}


/* ============================================================
   PARTS DB MODULE
   Company part number database — JSON/CSV import/export
   ============================================================ */

var PART_DB = {
  version: '1.0',
  company: '',
  parts: [
    {pn:'DB9M-001',    desc:'D-SUB 9P Male Solder',      cat:'CONNECTOR',  unit:'EA', std:'MIL-C-24308'},
    {pn:'DB9F-001',    desc:'D-SUB 9P Female Solder',    cat:'CONNECTOR',  unit:'EA', std:'MIL-C-24308'},
    {pn:'MF4P-001',    desc:'Molex Micro-Fit 4P Plug',   cat:'CONNECTOR',  unit:'EA', std:'Molex 43045'},
    {pn:'DT4P-001',    desc:'Deutsch DT 4P Plug',        cat:'CONNECTOR',  unit:'EA', std:'DT Series'},
    {pn:'XLR3M-001',   desc:'XLR 3P Male',               cat:'CONNECTOR',  unit:'EA', std:'IEC 61076'},
    {pn:'RJ45-001',    desc:'RJ45 Cat6 Plug',            cat:'CONNECTOR',  unit:'EA', std:'IEC 60603-7'},
    {pn:'MIL38-15-35', desc:'MIL-DTL-38999 III 15-35',  cat:'CONNECTOR',  unit:'EA', std:'MIL-DTL-38999'},
    {pn:'WIR-22-BK',   desc:'Wire 22AWG Black PVC',      cat:'WIRE',       unit:'M',  std:'UL1007'},
    {pn:'WIR-22-RD',   desc:'Wire 22AWG Red PVC',        cat:'WIRE',       unit:'M',  std:'UL1007'},
    {pn:'WIR-22-WH',   desc:'Wire 22AWG White PVC',      cat:'WIRE',       unit:'M',  std:'UL1007'},
    {pn:'WIR-20-BK',   desc:'Wire 20AWG Black PVC',      cat:'WIRE',       unit:'M',  std:'UL1007'},
    {pn:'SLV-BR-10',   desc:'Braided Sleeve Black 10mm', cat:'SLEEVE',     unit:'M',  std:''},
    {pn:'SLV-BR-15',   desc:'Braided Sleeve Black 15mm', cat:'SLEEVE',     unit:'M',  std:''},
    {pn:'HSK-3-BK',    desc:'Heat Shrink 3mm Black 2:1', cat:'HEATSHRINK', unit:'M',  std:''},
    {pn:'HSK-6-BK',    desc:'Heat Shrink 6mm Black 2:1', cat:'HEATSHRINK', unit:'M',  std:''},
    {pn:'LUG-M4-YE',   desc:'Lug Terminal M4 Yellow',    cat:'TERMINAL',   unit:'EA', std:''},
    {pn:'FER-10-RD',   desc:'Ferrule 1.0mm2 Red',        cat:'TERMINAL',   unit:'EA', std:''},
    {pn:'FER-25-BU',   desc:'Ferrule 2.5mm2 Blue',       cat:'TERMINAL',   unit:'EA', std:''},
    {pn:'TIE-150-NT',  desc:'Cable Tie 150mm Natural',   cat:'HARDWARE',   unit:'EA', std:''},
    {pn:'LABEL-WT-25', desc:'Cable Label White 25mm',    cat:'HARDWARE',   unit:'EA', std:''},
  ]
};

function partDBLoad() {
  try { var r=localStorage.getItem('moti_partdb'); if(r) PART_DB=JSON.parse(r); } catch(e){}
}
function partDBSave() {
  try { localStorage.setItem('moti_partdb', JSON.stringify(PART_DB)); } catch(e){}
}
function partDBSearch(query) {
  query = (query||'').toLowerCase().trim();
  if (!query) return PART_DB.parts.slice(0, 50);
  return PART_DB.parts.filter(function(p){
    return p.pn.toLowerCase().indexOf(query)>-1 ||
           (p.desc||'').toLowerCase().indexOf(query)>-1 ||
           (p.cat||'').toLowerCase().indexOf(query)>-1 ||
           (p.std||'').toLowerCase().indexOf(query)>-1;
  }).slice(0, 50);
}
function partDBImportJSON(text) {
  var d = JSON.parse(text);
  if (Array.isArray(d)) PART_DB.parts = d;
  else if (d.parts) PART_DB = d;
  else throw new Error('Expected array or {parts:[...]}');
  partDBSave();
}
function partDBImportCSV(text) {
  var lines = text.split('\n').filter(function(l){return l.trim();});
  var header = lines[0].toLowerCase().split(',').map(function(h2){return h2.trim().replace(/"/g,'');});
  var added = 0;
  for (var i=1;i<lines.length;i++) {
    var cols = lines[i].split(',').map(function(c){return c.trim().replace(/^"|"$/g,'');});
    var part = {};
    header.forEach(function(h2,idx){part[h2]=cols[idx]||'';});
    if (part.pn) { PART_DB.parts.push(part); added++; }
  }
  partDBSave();
  return added;
}
partDBLoad();

/* ── Parts DB Panel UI ── */
var _pdbSelPn = null;

function renderPartDB() {
  var panel = document.getElementById('panel-partdb');
  if (!panel) return;

  var h = '<div style="display:grid;grid-template-columns:1fr 300px;height:100%;overflow:hidden">';

  /* Left: table */
  h += '<div style="display:flex;flex-direction:column;overflow:hidden;border-right:1px solid var(--border2)">';
  h += '<div style="padding:8px 12px;background:var(--bg0);border-bottom:1px solid var(--border);flex-shrink:0;display:flex;gap:6px;align-items:center;flex-wrap:wrap">';
  h += '<span style="font-size:9px;color:var(--accent);letter-spacing:2px;font-weight:bold">COMPANY PARTS DATABASE</span>';
  h += '<span style="color:var(--text3);font-size:8px">'+PART_DB.parts.length+' parts</span>';
  h += '<span style="flex:1"></span>';
  h += '<input id="pdb-q" placeholder="Search P/N, desc, cat..." onInput="_pdbFilter()" '
    +'style="background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:3px 8px;font-size:9px;width:180px;font-family:monospace">';
  h += '<button class="btn btn-g" onclick="_pdbAdd()">+ ADD</button>';
  h += '<button class="btn" onclick="document.getElementById(\'pdb-ij\').click()">JSON IN</button>';
  h += '<input id="pdb-ij" type="file" accept=".json" style="display:none" onchange="_pdbImportJ(this)">';
  h += '<button class="btn" onclick="document.getElementById(\'pdb-ic\').click()">CSV IN</button>';
  h += '<input id="pdb-ic" type="file" accept=".csv,.txt" style="display:none" onchange="_pdbImportC(this)">';
  h += '<button class="btn" onclick="_pdbExport()">EXPORT</button>';
  h += '</div>';

  h += '<div style="flex:1;overflow:auto">';
  h += '<table class="rt" id="pdb-tbl"><thead><tr>';
  h += '<th>PART NUMBER</th><th>DESCRIPTION</th><th>CAT</th><th>UNIT</th><th>STANDARD</th><th>+BOM</th><th>DEL</th>';
  h += '</tr></thead><tbody id="pdb-tbody">';
  h += _pdbRows(PART_DB.parts.slice(0, 80));
  h += '</tbody></table></div></div>';

  /* Right: editor */
  h += '<div id="pdb-ed" style="background:var(--bg0);display:flex;flex-direction:column;overflow:auto">';
  h += '<div style="padding:10px 12px 8px;border-bottom:1px solid var(--border)">';
  h += '<span style="font-size:9px;color:var(--accent);letter-spacing:2px">PART EDITOR</span></div>';
  h += '<div style="padding:12px;color:var(--text3);font-size:9px">Select a part or click + ADD</div>';
  h += '</div>';

  h += '</div>';
  panel.innerHTML = h;
}

function _pdbRows(parts) {
  var h = '';
  parts.forEach(function(p) {
    var sel = (p.pn === _pdbSelPn);
    h += '<tr onclick="_pdbSelect(\''+esc(p.pn)+'\')" style="cursor:pointer;'+(sel?'background:var(--bg3)':'')+'">';
    h += '<td style="font-weight:bold;color:var(--accent3);white-space:nowrap">'+esc(p.pn)+'</td>';
    h += '<td>'+esc(p.desc||'')+'</td>';
    h += '<td><span style="font-size:7px;padding:1px 5px;background:var(--bg2);color:var(--text2);border-radius:8px">'+esc(p.cat||'')+'</span></td>';
    h += '<td style="text-align:center;color:var(--text2)">'+esc(p.unit||'EA')+'</td>';
    h += '<td style="color:var(--text3);font-size:8px">'+esc(p.std||'')+'</td>';
    h += '<td style="text-align:center"><button class="btn btn-g" style="padding:1px 5px;font-size:7px" onclick="event.stopPropagation();_pdbUsePart(\''+esc(p.pn)+'\')">+</button></td>';
    h += '<td style="text-align:center"><button class="del" onclick="event.stopPropagation();_pdbDel(\''+esc(p.pn)+'\')">x</button></td>';
    h += '</tr>';
  });
  if (!parts.length) h += '<tr><td colspan="7" style="padding:20px;text-align:center;color:var(--text3)">No parts found</td></tr>';
  return h;
}

function _pdbFilter() {
  var q = document.getElementById('pdb-q');
  var tb = document.getElementById('pdb-tbody');
  if (!q||!tb) return;
  tb.innerHTML = _pdbRows(partDBSearch(q.value));
}

function _pdbSelect(pn) {
  _pdbSelPn = pn;
  var part = null;
  PART_DB.parts.forEach(function(p){if(p.pn===pn)part=p;});
  if (!part) return;
  var cats = ['CONNECTOR','WIRE','SLEEVE','HEATSHRINK','TERMINAL','HARDWARE','MATERIAL','OTHER'];
  var units = ['EA','M','FT','KG','SET','LOT'];
  var fi = 'width:100%;background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:3px 6px;font-size:9px;box-sizing:border-box;font-family:monospace';
  var lbl = 'font-size:7px;color:var(--text3);margin-bottom:2px;letter-spacing:1px';
  var ed = document.getElementById('pdb-ed'); if (!ed) return;
  var h = '<div style="padding:10px 12px 8px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center">'
    +'<span style="font-size:9px;color:var(--accent);letter-spacing:2px">EDIT PART</span>'
    +'<button class="btn btn-g" onclick="_pdbSave()" style="padding:2px 10px">SAVE</button>'
    +'</div><div style="padding:12px">';
  h += '<div style="margin-bottom:7px"><div style="'+lbl+'">PART NUMBER</div><input id="ped-pn" value="'+esc(part.pn)+'" style="'+fi+'"/></div>';
  h += '<div style="margin-bottom:7px"><div style="'+lbl+'">DESCRIPTION</div><input id="ped-desc" value="'+esc(part.desc||'')+'" style="'+fi+'"/></div>';
  h += '<div style="margin-bottom:7px;display:grid;grid-template-columns:1fr 1fr;gap:6px">';
  h += '<div><div style="'+lbl+'">CATEGORY</div><select id="ped-cat" style="'+fi+'">'+cats.map(function(c){return '<option'+(c===part.cat?' selected':'')+'>'+c+'</option>';}).join('')+'</select></div>';
  h += '<div><div style="'+lbl+'">UNIT</div><select id="ped-unit" style="'+fi+'">'+units.map(function(u){return '<option'+(u===part.unit?' selected':'')+'>'+u+'</option>';}).join('')+'</select></div>';
  h += '</div>';
  h += '<div style="margin-bottom:7px"><div style="'+lbl+'">STANDARD / SPEC</div><input id="ped-std" value="'+esc(part.std||'')+'" placeholder="e.g. MIL-DTL-38999, UL1007" style="'+fi+'"/></div>';
  h += '<div><div style="'+lbl+'">NOTES</div><textarea id="ped-notes" rows="3" style="'+fi+';resize:vertical">'+esc(part.notes||'')+'</textarea></div>';
  h += '<input type="hidden" id="ped-orig" value="'+esc(part.pn)+'">';
  h += '</div>';
  ed.innerHTML = h;
}

function _pdbSave() {
  var orig = document.getElementById('ped-orig'); if (!orig) return;
  var pn   = (document.getElementById('ped-pn')||{}).value || '';
  var desc = (document.getElementById('ped-desc')||{}).value || '';
  var cat  = (document.getElementById('ped-cat')||{}).value || 'MATERIAL';
  var unit = (document.getElementById('ped-unit')||{}).value || 'EA';
  var std  = (document.getElementById('ped-std')||{}).value || '';
  var notes= (document.getElementById('ped-notes')||{}).value || '';
  if (!pn.trim()) { toast('Part number required', true); return; }
  var found = false;
  PART_DB.parts.forEach(function(p){
    if (p.pn===orig.value){p.pn=pn;p.desc=desc;p.cat=cat;p.unit=unit;p.std=std;p.notes=notes;found=true;}
  });
  if (!found) PART_DB.parts.push({pn:pn,desc:desc,cat:cat,unit:unit,std:std,notes:notes});
  partDBSave(); _pdbSelPn=pn; renderPartDB(); _pdbSelect(pn);
  toast('Saved: '+pn);
}

function _pdbAdd() {
  var pn = 'PN-' + Date.now().toString(36).toUpperCase();
  PART_DB.parts.push({pn:pn,desc:'New Part',cat:'MATERIAL',unit:'EA',std:'',notes:''});
  partDBSave(); renderPartDB(); _pdbSelect(pn);
}

function _pdbDel(pn) {
  if (!confirm('Delete '+pn+'?')) return;
  PART_DB.parts = PART_DB.parts.filter(function(p){return p.pn!==pn;});
  partDBSave(); renderPartDB();
}

function _pdbUsePart(pn) {
  var part = null; PART_DB.parts.forEach(function(p){if(p.pn===pn)part=p;});
  if (!part) return;
  pushUndo();
  S.bomItems.push({id:uid(),qty:1,unit:part.unit||'EA',pn:part.pn,desc:part.desc,cat:part.cat||'PURCHASED'});
  saveState(); renderBOM();
  toast('Added to BOM: '+pn);
}

function _pdbImportJ(input) {
  var file = input.files[0]; if (!file) return;
  var reader = new FileReader();
  reader.onload = function(ev) {
    try { partDBImportJSON(ev.target.result); renderPartDB(); toast('Imported '+PART_DB.parts.length+' parts'); }
    catch(e) { toast('JSON error: '+e.message, true); }
  };
  reader.readAsText(file); input.value='';
}

function _pdbImportC(input) {
  var file = input.files[0]; if (!file) return;
  var reader = new FileReader();
  reader.onload = function(ev) {
    try { var n=partDBImportCSV(ev.target.result); renderPartDB(); toast('Imported '+n+' parts from CSV'); }
    catch(e) { toast('CSV error: '+e.message, true); }
  };
  reader.readAsText(file); input.value='';
}

function _pdbExport() {
  var b = new Blob([JSON.stringify(PART_DB,null,2)],{type:'application/json'});
  var a = document.createElement('a');
  a.href = URL.createObjectURL(b);
  a.download = 'parts_db_'+(PART_DB.company||'company')+'_'+new Date().toISOString().slice(0,10)+'.json';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  toast('Exported parts database');
}


/* ============================================================
   HARNESS VIEW IMPROVEMENTS
   - Smart backbone layout (like RapidHarness)
   - Sub-circuit / template system
   - Harness diameter calculator
   - Improved node rendering
   ============================================================ */

/* ── Smart layout: hub + branches ── */
function hvAutoLayout(){
  var cn = H.nodes.filter(function(n){return !n.isJunction;}), n = cn.length;
  if (!n) return;
  if (n === 1){ cn[0].x=0; cn[0].y=0; cn[0].angle=0; return; }
  if (n === 2){ cn[0].x=-260;cn[0].y=0;cn[0].angle=180;cn[1].x=260;cn[1].y=0;cn[1].angle=0; return; }

  /* Find hub = connector with most wires */
  var wCount = {};
  cn.forEach(function(nd){ wCount[nd.id]=0; });
  S.wires.forEach(function(w){
    if(wCount[w.fromEl]!==undefined) wCount[w.fromEl]++;
    if(wCount[w.toEl]!==undefined)   wCount[w.toEl]++;
  });
  var sorted = cn.slice().sort(function(a,b){ return wCount[b.id]-wCount[a.id]; });
  var hub = sorted[0];
  hub.x = 260; hub.y = 0; hub.angle = 0;

  var branches = sorted.slice(1);
  if (branches.length === 1){
    branches[0].x=-260; branches[0].y=0; branches[0].angle=180;
    return;
  }

  /* Fan layout on left side */
  var fanH = Math.min(340, branches.length * 72);
  branches.forEach(function(nd, i){
    var t = branches.length===1 ? 0.5 : i/(branches.length-1);
    nd.x = -260 + (Math.random()*20-10);
    nd.y = -fanH/2 + t*fanH;
    nd.angle = nd.y > 20 ? 195 : nd.y < -20 ? 165 : 180;
  });
}

/* ── Harness diameter calculator ── */
function hvCalcDiameter(seg) {
  /* Based on wires in segment, approximate bundle diameter */
  var wires = seg.wires || [];
  var totalArea = 0;
  wires.forEach(function(wid){
    S.wires.forEach(function(w){
      if (w.id===wid){
        /* AWG to mm² approximate */
        var awg = parseInt(w.gauge||'22');
        var mm2 = awg<=10?5.26:awg<=12?3.31:awg<=14?2.08:awg<=16?1.31:awg<=18?0.823:awg<=20?0.518:awg<=22?0.326:0.205;
        totalArea += mm2;
      }
    });
  });
  /* Bundle diameter = sqrt(total_area * fill_factor) * 2 */
  var bundleMm = totalArea > 0 ? Math.sqrt(totalArea / 0.55) * 2 : 0;
  return Math.round(bundleMm * 10) / 10;
}

/* ── Sub-circuit template system ── */
var SC_TEMPLATES = [];

function scLoad(){
  try { var r=localStorage.getItem('moti_sc_templates'); if(r) SC_TEMPLATES=JSON.parse(r); } catch(e){}
}
function scSave(){
  try { localStorage.setItem('moti_sc_templates',JSON.stringify(SC_TEMPLATES)); } catch(e){}
}

function scSaveTemplate(){
  var name = prompt('Template name:','My Sub-circuit');
  if (!name) return;
  var tmpl = {
    id: uid(),
    name: name,
    created: new Date().toISOString(),
    elements: JSON.parse(JSON.stringify(S.elements)),
    wires: JSON.parse(JSON.stringify(S.wires)),
    notes: 'Saved from canvas'
  };
  SC_TEMPLATES.push(tmpl);
  scSave();
  toast('Template saved: '+name);
  renderSCPanel();
}

function scLoadTemplate(id){
  var tmpl = null;
  SC_TEMPLATES.forEach(function(t){if(t.id===id)tmpl=t;});
  if (!tmpl) return;
  if (!confirm('Load template "'+tmpl.name+'"? This will add its components to the canvas.')) return;
  pushUndo();
  /* Remap IDs to avoid collisions */
  var idMap = {};
  var newEls = tmpl.elements.map(function(el){
    var newId = uid();
    idMap[el.id] = newId;
    var nel = JSON.parse(JSON.stringify(el));
    nel.id = newId;
    nel.x += 60 + Math.random()*40;
    nel.y += 60 + Math.random()*40;
    nel.label = 'P' + (S.nextConnLabel++);
    return nel;
  });
  var newWires = tmpl.wires.map(function(w){
    var nw = JSON.parse(JSON.stringify(w));
    nw.id = uid();
    nw.fromEl = idMap[w.fromEl] || w.fromEl;
    nw.toEl   = idMap[w.toEl]   || w.toEl;
    return nw;
  });
  S.elements = S.elements.concat(newEls);
  S.wires = S.wires.concat(newWires);
  saveState(); renderAll();
  toast('Loaded template: '+tmpl.name+' ('+newEls.length+' connectors, '+newWires.length+' wires)');
}

function scDeleteTemplate(id){
  if (!confirm('Delete template?')) return;
  SC_TEMPLATES = SC_TEMPLATES.filter(function(t){return t.id!==id;});
  scSave(); renderSCPanel();
}

function scExportTemplate(id){
  var tmpl = null;
  SC_TEMPLATES.forEach(function(t){if(t.id===id)tmpl=t;});
  if (!tmpl) return;
  var b = new Blob([JSON.stringify(tmpl,null,2)],{type:'application/json'});
  var a = document.createElement('a');
  a.href = URL.createObjectURL(b);
  a.download = 'subcircuit_'+tmpl.name.replace(/\s+/g,'_')+'.json';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
}

function scImportTemplate(){
  var inp = document.createElement('input');
  inp.type = 'file'; inp.accept = '.json';
  inp.onchange = function(){
    var file = inp.files[0]; if(!file) return;
    var reader = new FileReader();
    reader.onload = function(ev){
      try {
        var tmpl = JSON.parse(ev.target.result);
        if (!tmpl.name || !tmpl.elements) throw new Error('Invalid template format');
        tmpl.id = uid();
        SC_TEMPLATES.push(tmpl);
        scSave(); renderSCPanel();
        toast('Imported: '+tmpl.name);
      } catch(e){ toast('Import error: '+e.message, true); }
    };
    reader.readAsText(file);
  };
  inp.click();
}

/* ── Sub-circuit Panel ── */
function renderSCPanel(){
  var panel = document.getElementById('panel-sc');
  if (!panel) return;
  scLoad();
  var h = '<div style="display:flex;flex-direction:column;height:100%;overflow:hidden">';
  h += '<div style="padding:8px 12px;background:var(--bg0);border-bottom:1px solid var(--border);flex-shrink:0;display:flex;gap:6px;align-items:center">';
  h += '<span style="font-size:9px;color:var(--accent);letter-spacing:2px;font-weight:bold">SUB-CIRCUIT TEMPLATES</span>';
  h += '<span style="flex:1"></span>';
  h += '<button class="btn btn-g" onclick="scSaveTemplate()" title="Save current canvas as template">SAVE CURRENT</button>';
  h += '<button class="btn" onclick="scImportTemplate()">IMPORT</button>';
  h += '</div>';

  if (!SC_TEMPLATES.length){
    h += '<div style="padding:40px;text-align:center;color:var(--text3);font-size:10px">';
    h += 'No templates yet.<br><br>Design a sub-circuit on the Canvas,<br>then click <b>SAVE CURRENT</b> to store it here.</div>';
  } else {
    h += '<div style="flex:1;overflow-y:auto;padding:10px;display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px">';
    SC_TEMPLATES.forEach(function(tmpl){
      h += '<div style="background:var(--bg1);border:1px solid var(--border);border-radius:4px;padding:10px">';
      h += '<div style="font-weight:bold;color:var(--accent);margin-bottom:4px;font-size:10px">'+esc(tmpl.name)+'</div>';
      h += '<div style="font-size:8px;color:var(--text3);margin-bottom:6px">';
      h += (tmpl.elements||[]).length+' connectors &middot; '+(tmpl.wires||[]).length+' wires';
      h += (tmpl.created?'<br>'+new Date(tmpl.created).toLocaleDateString():'');
      h += '</div>';
      h += '<div style="display:flex;gap:4px;flex-wrap:wrap">';
      h += '<button class="btn btn-g" onclick="scLoadTemplate(\''+tmpl.id+'\')" style="font-size:8px;padding:2px 8px">+ ADD TO CANVAS</button>';
      h += '<button class="btn" onclick="scExportTemplate(\''+tmpl.id+'\')" style="font-size:8px;padding:2px 6px">EXPORT</button>';
      h += '<button class="del" onclick="scDeleteTemplate(\''+tmpl.id+'\')" style="padding:2px 6px">x</button>';
      h += '</div></div>';
    });
    h += '</div>';
  }
  h += '</div>';
  panel.innerHTML = h;
}

scLoad();


/* ============================================================
   EXPORT MODULE — Professional outputs
   - Project JSON save/load
   - BOM CSV / Excel-compatible
   - Point-to-Point wire list CSV
   - Harness summary report
   ============================================================ */

/* ── Project JSON ── */
function exportJSON(){
  var d={version:'v7',state:JSON.parse(JSON.stringify(S)),
         harness:JSON.parse(JSON.stringify(H)),
         partDB:JSON.parse(JSON.stringify(PART_DB)),
         templates:JSON.parse(JSON.stringify(SC_TEMPLATES)),
         exportedAt:new Date().toISOString()};
  var b=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});
  var a=document.createElement('a');a.href=URL.createObjectURL(b);
  a.download='MOTI_'+(S.dwgNo||'project')+'_'+new Date().toISOString().slice(0,10)+'.json';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('Project exported: '+(S.dwgNo||'project'));
}

function importJSON(input){
  var file=input.files[0];if(!file)return;
  var reader=new FileReader();
  reader.onload=function(ev){
    try{
      var d=JSON.parse(ev.target.result);
      if(!confirm('Import project? This will replace current data.'))return;
      var st=d.state||d;
      for(var k in st) S[k]=st[k];
      if(d.harness){H.nodes=d.harness.nodes||[];H.segs=d.harness.segs||[];}
      if(d.partDB) PART_DB=d.partDB;
      if(d.templates) SC_TEMPLATES=d.templates;
      syncCustomConnectors();saveState();buildSidebar();renderAll();syncTBAll();
      toast('Imported: '+(S.title||'project'));
    }catch(e){toast('Import error: '+e.message,true);}
  };
  reader.readAsText(file);input.value='';
}

function saveHTML(){
  var b=new Blob([document.documentElement.outerHTML],{type:'text/html'});
  var a=document.createElement('a');
  a.href=URL.createObjectURL(b);
  a.download='MOTI_'+(S.dwgNo||'drawing')+'.html';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('HTML saved');
}

/* ── BOM CSV export ── */
function exportBOMCSV(){
  var rows = [['ITEM','PART NUMBER','DESCRIPTION','CATEGORY','QTY','UNIT','STANDARD']];
  /* Auto-include connectors from canvas */
  var connEls=S.elements.filter(function(e){return e.kind==='connector';});
  connEls.forEach(function(el,i){
    var lib=CL[el.connId];if(!lib)return;
    rows.push([i+1, lib.pn||lib.id, lib.name, 'CONNECTOR', 1, 'EA', lib.std||'']);
  });
  /* Manual BOM items */
  S.bomItems.forEach(function(it,i){
    rows.push([connEls.length+i+1, it.pn||'', it.desc||'', it.cat||'', it.qty||1, it.unit||'EA', '']);
  });
  var csv = rows.map(function(r){
    return r.map(function(c){return '"'+String(c).replace(/"/g,'""')+'"';}).join(',');
  }).join('\r\n');
  csv = '\uFEFF' + csv; /* BOM for Excel UTF-8 */
  var b=new Blob([csv],{type:'text/csv;charset=utf-8'});
  var a=document.createElement('a');a.href=URL.createObjectURL(b);
  a.download='BOM_'+(S.dwgNo||'project')+'_'+new Date().toISOString().slice(0,10)+'.csv';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('BOM exported: '+rows.length+' items');
}

/* ── Point-to-Point Wire List CSV ── */
function exportP2P(){
  var rows=[['WIRE#','FROM CONNECTOR','FROM PIN','FROM PIN NAME','TO CONNECTOR','TO PIN','TO PIN NAME','SIGNAL','GAUGE','COLOR','LENGTH mm','STRIP A mm','STRIP B mm','CUT LENGTH mm']];
  var connEls=S.elements.filter(function(e){return e.kind==='connector';});

  S.wires.forEach(function(w,i){
    if(!w.fromEl||!w.toEl) return;
    var fromEl=null,toEl=null;
    connEls.forEach(function(e){if(e.id===w.fromEl)fromEl=e;if(e.id===w.toEl)toEl=e;});
    if(!fromEl||!toEl) return;
    var libF=CL[fromEl.connId],libT=CL[toEl.connId];
    var fromPinName='',toPinName='';
    if(libF)(libF.pinout||[]).forEach(function(p){if(String(p.id)===String(w.fromPin))fromPinName=p.n;});
    if(libT)(libT.pinout||[]).forEach(function(p){if(String(p.id)===String(w.toPin))toPinName=p.n;});
    var sf=S.stripFrom||8, st=S.stripTo||8, cable=S.cableLength||500;
    rows.push([
      w.wireNum||String(i+1).padStart(3,'0'),
      fromEl.label||fromEl.id,
      w.fromPin||'',
      fromPinName,
      toEl.label||toEl.id,
      w.toPin||'',
      toPinName,
      w.signal||'',
      w.gauge||'',
      w.colorAbbr||(w.color||''),
      cable,
      sf,
      st,
      cable+sf+st
    ]);
  });

  if(rows.length<2){toast('No wires to export',true);return;}
  var csv=rows.map(function(r){
    return r.map(function(c){return '"'+String(c).replace(/"/g,'""')+'"';}).join(',');
  }).join('\r\n');
  csv='\uFEFF'+csv;
  var b=new Blob([csv],{type:'text/csv;charset=utf-8'});
  var a=document.createElement('a');a.href=URL.createObjectURL(b);
  a.download='P2P_'+(S.dwgNo||'project')+'_'+new Date().toISOString().slice(0,10)+'.csv';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('P2P wire list exported: '+(rows.length-1)+' wires');
}

/* ── Harness Summary Report (HTML) ── */
function exportReport(){
  var connEls=S.elements.filter(function(e){return e.kind==='connector';});
  var totalLen=S.wires.length * (S.cableLength||500) / 1000; /* approx total m */
  var today=new Date().toLocaleDateString('en-GB');

  var html='<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'+
    (S.title||'Cable Assembly')+' -- Report</title><style>';
  html+='body{font-family:\'Courier New\',monospace;background:#fff;color:#111;margin:20px;font-size:11px}';
  html+='h1{font-size:18px;border-bottom:2px solid #111;padding-bottom:6px}';
  html+='h2{font-size:12px;margin-top:16px;color:#336699;letter-spacing:2px;text-transform:uppercase}';
  html+='table{width:100%;border-collapse:collapse;margin:8px 0}';
  html+='th{background:#c4bfb0;padding:4px 8px;text-align:left;font-size:10px;border:1px solid #999}';
  html+='td{padding:3px 8px;border:1px solid #ddd;font-size:10px}';
  html+='tr:nth-child(even){background:#f5f3ee}';
  html+='@media print{body{margin:8px}.no-print{display:none}}';
  html+='</style></head><body>';

  /* Header */
  html+='<h1>'+esc(S.title||'Cable Assembly')+'</h1>';
  html+='<table style="width:auto;margin-bottom:16px"><tr>';
  [['DWG No.',S.dwgNo],['P/N',S.partNo],['Rev',S.rev],['Drawn By',S.drawnBy],
   ['Company',S.company],['Date',today]].forEach(function(f){
    html+='<td style="background:#f0ede4"><b>'+f[0]+':</b></td><td>'+esc(f[1]||'--')+'</td>';
  });
  html+='</tr></table>';

  /* Summary */
  html+='<h2>Summary</h2>';
  html+='<table><tr><th>Item</th><th>Value</th></tr>';
  [['Connectors',connEls.length],
   ['Total wires',S.wires.length],
   ['Cable length',S.cableLength+' mm +/-'+(S.lengthTol||20)],
   ['Strip FROM',S.stripFrom||8+' mm'],['Strip TO',S.stripTo||8+' mm'],
   ['Approx total wire length',totalLen.toFixed(1)+' m']
  ].forEach(function(r){html+='<tr><td>'+r[0]+'</td><td><b>'+r[1]+'</b></td></tr>';});
  html+='</table>';

  /* Connectors */
  html+='<h2>Connectors</h2>';
  html+='<table><tr><th>Label</th><th>Type</th><th>P/N</th><th>Pins</th><th>Side</th></tr>';
  connEls.forEach(function(el){
    var lib=CL[el.connId]||{};
    html+='<tr><td><b>'+esc(el.label||'?')+'</b></td><td>'+esc(lib.name||el.connId)+'</td>'
      +'<td>'+esc(lib.pn||lib.id||'')+'</td><td>'+esc(String(lib.pins||'?'))+'</td>'
      +'<td>'+esc(el.side||'left')+'</td></tr>';
  });
  html+='</table>';

  /* Wire list */
  html+='<h2>Point-to-Point Wire List</h2>';
  html+='<table><tr><th>WIRE#</th><th>FROM</th><th>TO</th><th>SIGNAL</th><th>GAUGE</th><th>COLOR</th></tr>';
  S.wires.forEach(function(w,i){
    var fromEl=null,toEl=null;
    S.elements.forEach(function(e){if(e.id===w.fromEl)fromEl=e;if(e.id===w.toEl)toEl=e;});
    html+='<tr>'
      +'<td>'+esc(w.wireNum||String(i+1).padStart(3,'0'))+'</td>'
      +'<td><b>'+esc((fromEl?fromEl.label:'?')+'.'+w.fromPin)+'</b></td>'
      +'<td><b>'+esc((toEl?toEl.label:'?')+'.'+w.toPin)+'</b></td>'
      +'<td>'+esc(w.signal||'')+'</td>'
      +'<td>'+esc(w.gauge||'')+'</td>'
      +'<td style="background:'+(w.color||'#fff')+';color:'+(w.color?'#fff':'#111')+'">'+esc(w.colorAbbr||w.color||'')+'</td>'
      +'</tr>';
  });
  html+='</table>';

  /* BOM */
  html+='<h2>Bill of Materials</h2>';
  html+='<table><tr><th>#</th><th>P/N</th><th>Description</th><th>Qty</th><th>Unit</th></tr>';
  S.bomItems.forEach(function(it,i){
    html+='<tr><td>'+(i+1)+'</td><td>'+esc(it.pn||'')+'</td><td>'+esc(it.desc||'')+'</td><td>'+esc(String(it.qty||1))+'</td><td>'+esc(it.unit||'EA')+'</td></tr>';
  });
  html+='</table>';

  /* Notes */
  if((S.notes||[]).length){
    html+='<h2>Notes</h2><ol>';
    S.notes.forEach(function(n){html+='<li>'+esc(n)+'</li>';});
    html+='</ol>';
  }

  html+='</body></html>';
  var b=new Blob([html],{type:'text/html;charset=utf-8'});
  var a=document.createElement('a');a.href=URL.createObjectURL(b);
  a.download='Report_'+(S.dwgNo||'project')+'_'+today.replace(/\//g,'-')+'.html';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('Report exported');
}

/* ── Export dropdown UI ── */
function showExportMenu(){
  var existing=document.getElementById('export-menu');
  if(existing){existing.remove();return;}
  var btn=document.getElementById('btn-export');
  if(!btn)return;
  var rect=btn.getBoundingClientRect();
  var menu=document.createElement('div');
  menu.id='export-menu';
  menu.style.cssText='position:fixed;top:'+(rect.bottom+2)+'px;left:'+rect.left+'px;'
    +'background:#0d0d0d;border:1px solid #444;z-index:9998;min-width:200px;box-shadow:0 4px 20px rgba(0,0,0,0.8)';
  var items=[
    ['Project JSON (.json)',  'exportJSON()'],
    ['BOM CSV (.csv)',        'exportBOMCSV()'],
    ['P2P Wire List (.csv)',  'exportP2P()'],
    ['Full Report (.html)',   'exportReport()'],
    ['Save as HTML',          'saveHTML()'],
    ['ENG Drawing PDF',       'openDwgModal()'],
  ];
  items.forEach(function(item){
    var d=document.createElement('div');
    d.style.cssText='padding:8px 14px;cursor:pointer;font-family:monospace;font-size:9px;'
      +'color:#c8c8c8;border-bottom:1px solid #1a1a1a';
    d.onmouseover=function(){this.style.background='#1a1a1a';this.style.color='#c8a840';};
    d.onmouseout=function(){this.style.background='';this.style.color='#c8c8c8';};
    d.textContent=item[0];
    d.onclick=function(){menu.remove();eval(item[1]);};
    menu.appendChild(d);
  });
  document.body.appendChild(menu);
  setTimeout(function(){
    document.addEventListener('click',function h(e){
      if(!menu.contains(e.target)){menu.remove();document.removeEventListener('click',h);}
    });
  },10);
}

function showTab(id,btn){
  document.querySelectorAll(".tab").forEach(function(t){t.classList.remove("on");});
  document.querySelectorAll(".panel").forEach(function(p){p.classList.remove("on");});
  if(btn) btn.classList.add("on");
  document.getElementById("panel-"+id).classList.add("on");
  if(id==="canvas") setTimeout(resizeCanvas,50);
  if(id==="connectors") renderConnectorEditor();
  if(id==="harness") setTimeout(renderHarness,60);
  if(id==="partdb")    renderPartDB();
  if(id==="sc")        renderSCPanel();
}

function setTheme(v){document.body.className=v;localStorage.setItem("moti_theme",v);}

function saveHTML(){
  var b=new Blob([document.documentElement.outerHTML],{type:"text/html"});
  var a=document.createElement("a");
  a.href=URL.createObjectURL(b); a.download="MOTI_"+(S.dwgNo||"drawing")+".html";
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
}

// ============================================================
// INIT
// ============================================================
document.addEventListener("keydown",function(e){
  if(e.key==="Escape"&&wireStart){wireStart=null;updateRouteHint(null);renderCanvas();}
});

loadState();
syncCustomConnectors();

var th=localStorage.getItem("moti_theme")||"";
document.body.className=th;
var thSel=document.getElementById("th-sel");
if(thSel) thSel.value=th;

function syncTB(id,val){var el=document.getElementById(id);if(el)el.value=val||"";}
syncTB("tb-title",S.title); syncTB("tb-pn",S.partNo); syncTB("tb-dwg",S.dwgNo);
syncTB("tb-rev",S.rev); syncTB("tb-co",S.company); syncTB("tb-drawn",S.drawnBy);
syncTB("tb-len",S.cableLength); syncTB("tb-tol",S.lengthTol);

buildSidebar();
initCanvas();
renderAll();
setTool("select");


// ============================================================
// HARNESS VIEW — Physical Cable Layout Engine v2
// Looks like a real harness drawing (RapidHarness style)
// ============================================================

// ── State ──
// Nodes: connectors + junction points (draggable)
// Segs:  cable segments between nodes (trunk/branch)
// Each node has: {id, label, connId, x, y, isJunction, angle}
// Each seg has:  {id, from, to, lengthMm, label, wires[], pts[]}

// ============================================================
// HARNESS VIEW v3 — Engineering Drawing Engine
// Professional harness schematic à la RapidHarness / AIR style
// ============================================================


// ═══════════════════════════════════════════════════════════════
// HARNESS VIEW ENGINE
// Physical cable layout canvas — drag & drop topology editor
// ═══════════════════════════════════════════════════════════════