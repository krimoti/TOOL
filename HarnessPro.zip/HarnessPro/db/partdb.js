/* ============================================================
   PARTDB.JS — Company Part Number Database
   Supports: JSON file import, CSV import, manual edit
   MOTI HarnessPro
   ============================================================ */
'use strict';

/* Default demo parts — replace with company data */
var PART_DB = {
  version: '1.0',
  company: '',
  parts: [
    { pn:'CON-DB9M-001',  desc:'D-SUB 9P Male Solder',      cat:'CONNECTOR', unit:'EA', std:'MIL-C-24308' },
    { pn:'CON-DB9F-001',  desc:'D-SUB 9P Female Solder',    cat:'CONNECTOR', unit:'EA', std:'MIL-C-24308' },
    { pn:'CON-MF4P-001',  desc:'Molex Micro-Fit 4P Plug',   cat:'CONNECTOR', unit:'EA', std:'Molex 43045' },
    { pn:'CON-DT4P-001',  desc:'Deutsch DT 4P Plug',        cat:'CONNECTOR', unit:'EA', std:'DT Series'   },
    { pn:'WIR-22AWG-BK',  desc:'Wire 22AWG Black PVC',      cat:'WIRE',      unit:'M',  std:'UL1007'      },
    { pn:'WIR-22AWG-RD',  desc:'Wire 22AWG Red PVC',        cat:'WIRE',      unit:'M',  std:'UL1007'      },
    { pn:'WIR-22AWG-WH',  desc:'Wire 22AWG White PVC',      cat:'WIRE',      unit:'M',  std:'UL1007'      },
    { pn:'WIR-20AWG-BK',  desc:'Wire 20AWG Black PVC',      cat:'WIRE',      unit:'M',  std:'UL1007'      },
    { pn:'SLV-BR-BK-10',  desc:'Braided Sleeve Black 10mm', cat:'SLEEVE',    unit:'M',  std:''            },
    { pn:'HSK-3MM-BK',    desc:'Heat Shrink 3mm Black 2:1', cat:'HEATSHRINK',unit:'M',  std:''            },
    { pn:'HSK-6MM-BK',    desc:'Heat Shrink 6mm Black 2:1', cat:'HEATSHRINK',unit:'M',  std:''            },
    { pn:'LUG-M4-YE',     desc:'Lug Terminal M4 Yellow',    cat:'TERMINAL',  unit:'EA', std:''            },
    { pn:'FER-1MM-RD',    desc:'Ferrule 1.0mm Red',         cat:'TERMINAL',  unit:'EA', std:''            },
    { pn:'FER-25MM-BU',   desc:'Ferrule 2.5mm Blue',        cat:'TERMINAL',  unit:'EA', std:''            },
  ]
};

/* Load from localStorage if saved */
function partDBLoad() {
  try {
    var raw = localStorage.getItem('moti_partdb');
    if(raw) PART_DB = JSON.parse(raw);
  } catch(e) {}
}

function partDBSave() {
  try { localStorage.setItem('moti_partdb', JSON.stringify(PART_DB)); } catch(e) {}
}

/* Search parts */
function partDBSearch(query) {
  query = (query||'').toLowerCase().trim();
  if(!query) return PART_DB.parts.slice(0,40);
  return PART_DB.parts.filter(function(p){
    return p.pn.toLowerCase().indexOf(query)>-1 ||
           p.desc.toLowerCase().indexOf(query)>-1 ||
           (p.cat||'').toLowerCase().indexOf(query)>-1;
  }).slice(0,40);
}

/* Import from JSON */
function partDBImportJSON(jsonText) {
  var d = JSON.parse(jsonText);
  if(Array.isArray(d)) { PART_DB.parts = d; }
  else if(d.parts) { PART_DB = d; }
  else { throw new Error('Invalid format. Expected array or {parts:[...]}'); }
  partDBSave();
}

/* Import from CSV: pn,desc,cat,unit,std */
function partDBImportCSV(csvText) {
  var lines = csvText.split('\n').filter(function(l){return l.trim();});
  var header = lines[0].toLowerCase().split(',').map(function(h){return h.trim().replace(/"/g,'');});
  var parts = [];
  for(var i=1;i<lines.length;i++){
    var cols = lines[i].split(',').map(function(c){return c.trim().replace(/^"|"$/g,'');});
    var part = {};
    header.forEach(function(h,idx){ part[h]=cols[idx]||''; });
    if(part.pn) parts.push(part);
  }
  PART_DB.parts = PART_DB.parts.concat(parts);
  partDBSave();
  return parts.length;
}

partDBLoad();
