/* ============================================================
   APP.JS v2 — State, Undo/Redo, utilities, init, tabs
   MOTI HarnessPro
   ============================================================ */

'use strict';

var CL = {};

function defaultState() {
  return {
    elements: [], wires: [], dimensions: [], labels: [],
    title: "CABLE ASS'Y", partNo: 'PN-00001', dwgNo: 'DWG-001',
    rev: 'A', drawnBy: '', company: '',
    cableLength: 500, lengthTol: 20, stripFrom: 8, stripTo: 8,
    notes: [
      'No open/short or intermittent failures.',
      '100% electrical test required.',
      'Voltage test: DC 300V; Insulation: 5M\u03a9 min.',
      'All dimensions in mm unless noted. RoHS Compliant.'
    ],
    bomItems: [], zoom: 1, panX: 50, panY: 50,
    nextConnLabel: 1, customConnectors: []
  };
}

var S = defaultState();
var H = { nodes:[], segs:[], zoom:1, panX:120, panY:150, sel:null, drag:null };

/* ════ UNDO / REDO ════ */
var UNDO_STACK=[], REDO_STACK=[], UNDO_MAX=60, _undoLock=false;

function _snap(){
  return JSON.stringify({
    S:{ elements:S.elements, wires:S.wires, dimensions:S.dimensions, labels:S.labels||[],
        bomItems:S.bomItems, notes:S.notes, title:S.title, partNo:S.partNo, dwgNo:S.dwgNo,
        rev:S.rev, drawnBy:S.drawnBy, company:S.company, cableLength:S.cableLength,
        lengthTol:S.lengthTol, stripFrom:S.stripFrom||8, stripTo:S.stripTo||8,
        nextConnLabel:S.nextConnLabel, customConnectors:S.customConnectors },
    H:{ nodes:H.nodes, segs:H.segs }
  });
}
function _restore(snap){
  var d=JSON.parse(snap);
  var keys=Object.keys(d.S); for(var i=0;i<keys.length;i++) S[keys[i]]=d.S[keys[i]];
  if(!S.labels) S.labels=[];
  H.nodes=d.H.nodes||[]; H.segs=d.H.segs||[];
  mergeCL();
}
function pushUndo(){
  if(_undoLock) return;
  UNDO_STACK.push(_snap());
  if(UNDO_STACK.length>UNDO_MAX) UNDO_STACK.shift();
  REDO_STACK=[];
  _updateUndoUI();
}
function undoAction(){
  if(!UNDO_STACK.length) return;
  REDO_STACK.push(_snap());
  _undoLock=true; _restore(UNDO_STACK.pop()); _undoLock=false;
  saveState(); buildSidebar(); renderAll(); syncTBAll();
  _updateUndoUI(); toast('Undo');
}
function redoAction(){
  if(!REDO_STACK.length) return;
  UNDO_STACK.push(_snap());
  _undoLock=true; _restore(REDO_STACK.pop()); _undoLock=false;
  saveState(); buildSidebar(); renderAll(); syncTBAll();
  _updateUndoUI(); toast('Redo');
}
function _updateUndoUI(){
  var bu=document.getElementById('btn-undo'), br=document.getElementById('btn-redo');
  if(bu){ bu.disabled=!UNDO_STACK.length; bu.style.opacity=UNDO_STACK.length?'1':'0.4'; }
  if(br){ br.disabled=!REDO_STACK.length; br.style.opacity=REDO_STACK.length?'1':'0.4'; }
}

/* ════ NEW PROJECT ════ */
function newProject(){
  if(!confirm('Start a new project? All unsaved changes will be lost.')) return;
  pushUndo();
  var fresh=defaultState();
  var keys=Object.keys(fresh); for(var i=0;i<keys.length;i++) S[keys[i]]=fresh[keys[i]];
  H.nodes=[]; H.segs=[];
  UNDO_STACK=[]; REDO_STACK=[];
  saveState(); buildSidebar(); renderAll(); syncTBAll();
  _updateUndoUI(); toast('New project started');
}

/* ════ AWG WARNING SYSTEM ════ */
function checkAWGWarnings(){
  var warnings=[];
  S.wires.forEach(function(w){
    if(!w.fromEl||!w.fromPin) return;
    var lib=null;
    S.elements.forEach(function(e){ if(e.id===w.fromEl) lib=CL[e.connId]; });
    if(!lib) return;
    var pin=null;
    lib.pinout.forEach(function(p){ if(String(p.id)===String(w.fromPin)) pin=p; });
    if(!pin||!pin.g||!w.gauge) return;
    var pinAWG=parseInt(pin.g), wireAWG=parseInt(w.gauge);
    if(!isNaN(pinAWG)&&!isNaN(wireAWG)&&wireAWG!==pinAWG){
      var diff=Math.abs(wireAWG-pinAWG);
      warnings.push({
        wid:w.id,
        msg:'Wire "'+(w.signal||w.id)+'": gauge '+w.gauge+' \u2260 pin '+pin.id+' spec ('+pin.g+')',
        suggestion: wireAWG>pinAWG
          ? 'Wire thinner than spec \u2014 overheating risk. Use '+pin.g+' or thicker.'
          : 'Wire thicker than spec \u2014 may not fit. Use '+pin.g+'.',
        severity: diff>=4?'error':'warn'
      });
    }
  });
  var el=document.getElementById('awg-warnings');
  if(el){
    if(!warnings.length){ el.style.display='none'; return warnings; }
    el.style.display='block';
    el.innerHTML=warnings.map(function(w){
      var col=w.severity==='error'?'#e74c3c':'#f39c12';
      return '<div style="padding:4px 8px;border-left:3px solid '+col+';margin-bottom:4px;font-size:8px">'
        +'<b style="color:'+col+'">'+(w.severity==='error'?'\u26d4':'\u26a0\ufe0f')+' '+esc(w.msg)+'</b>'
        +'<div style="color:var(--text2);margin-top:2px">'+esc(w.suggestion)+'</div></div>';
    }).join('');
  }
  return warnings;
}

/* ════ BOM AUTO-GENERATE ════ */
function generateBOM(){
  pushUndo();
  var added=0;
  // Connectors
  S.elements.forEach(function(el){
    if(el.kind!=='connector') return;
    var lib=CL[el.connId]; if(!lib) return;
    var dup=false;
    S.bomItems.forEach(function(b){ if(b.pn===lib.pn||b.desc===lib.name) dup=true; });
    if(!dup){ S.bomItems.push({id:uid(),qty:1,unit:'EA',pn:lib.pn||lib.id,desc:lib.name,cat:'PURCHASED'}); added++; }
  });
  // Wire by gauge
  var gMap={};
  S.wires.forEach(function(w){ if(w.active!==false&&w.gauge) gMap[w.gauge]=(gMap[w.gauge]||0)+1; });
  Object.keys(gMap).forEach(function(g){
    var dup=false;
    S.bomItems.forEach(function(b){ if(b.desc&&b.desc.indexOf('wire '+g)>-1) dup=true; });
    if(!dup){
      var len=Math.ceil(S.cableLength/1000*gMap[g]*1.15*10)/10;
      S.bomItems.push({id:uid(),qty:len,unit:'M',pn:'',desc:'Hook-up wire '+g+' (\xd7'+gMap[g]+')',cat:'MATERIAL'});
      added++;
    }
  });
  if(!added){ toast('BOM already up to date'); return; }
  saveState(); renderBOM(); toast('Added '+added+' items to BOM');
}

/* ════ UTILITIES ════ */
function uid()  { return 'e'+Date.now().toString(36)+Math.random().toString(36).slice(2,5); }
function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function sc(c)  { return(c&&(c[0]==='#'||c.indexOf('hsl')===0||c.indexOf('rgb')===0))?c:'#888'; }
function clamp(v,a,b){ return v<a?a:v>b?b:v; }
function hslc(h){ return 'hsl('+h+',65%,45%)'; }
function mkpins(n,pre,sig,awg,hStep){
  var r=[];for(var i=0;i<n;i++)r.push({id:i+1,n:pre+(i+1),sig:sig,g:awg,c:hslc(i*hStep)});return r;
}
function arrFind(arr,fn){ for(var i=0;i<arr.length;i++)if(fn(arr[i],i))return arr[i];return null; }

function toast(msg,err){
  var t=document.getElementById('toast');
  t.textContent=msg; t.className='show'+(err?' err':'');
  clearTimeout(t._tid); t._tid=setTimeout(function(){t.className='';},2600);
}

/* ════ CL ════ */
function mergeCL(){
  for(var k in CL){ if(!CL[k].builtin) delete CL[k]; }
  for(var i=0;i<S.customConnectors.length;i++){ var c=S.customConnectors[i]; CL[c.id]=c; }
}
function initCL(){ for(var k in CL_BUILTIN) CL[k]=CL_BUILTIN[k]; mergeCL(); }

/* ════ PERSISTENCE ════ */
var STORAGE_KEY='moti_harnesspro_v2';

function saveState(){
  try{ if(!S.labels)S.labels=[]; localStorage.setItem(STORAGE_KEY,JSON.stringify({S:S,H:{nodes:H.nodes,segs:H.segs}})); }catch(e){}
}
function loadState(){
  try{
    var raw=localStorage.getItem(STORAGE_KEY); if(!raw)return;
    var d=JSON.parse(raw);
    if(d.S){ var keys=Object.keys(d.S); for(var i=0;i<keys.length;i++) S[keys[i]]=d.S[keys[i]]; }
    if(!S.labels) S.labels=[];
    if(!S.stripFrom) S.stripFrom=8;
    if(!S.stripTo) S.stripTo=8;
    if(d.H){ if(d.H.nodes)H.nodes=d.H.nodes; if(d.H.segs)H.segs=d.H.segs; }
  }catch(e){}
}

/* ════ EXPORT / IMPORT ════ */
function exportJSON(){
  var data={version:'2.0',exportedAt:new Date().toISOString(),S:JSON.parse(JSON.stringify(S)),H:{nodes:JSON.parse(JSON.stringify(H.nodes)),segs:JSON.parse(JSON.stringify(H.segs))}};
  var b=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
  var a=document.createElement('a'); a.href=URL.createObjectURL(b);
  a.download='MOTI_'+(S.dwgNo||'project')+'_'+new Date().toISOString().slice(0,10)+'.json';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('Project exported');
}
function importJSON(input){
  var file=input.files[0]; if(!file)return;
  var reader=new FileReader();
  reader.onload=function(ev){
    try{
      var d=JSON.parse(ev.target.result);
      if(!confirm('Import project? Current data will be replaced.'))return;
      pushUndo();
      var st=d.S||d; var keys=Object.keys(st); for(var i=0;i<keys.length;i++) S[keys[i]]=st[keys[i]];
      if(!S.labels)S.labels=[];
      if(d.H){H.nodes=d.H.nodes||[];H.segs=d.H.segs||[];}
      mergeCL();saveState();buildSidebar();renderAll();syncTBAll();
      toast('Project imported');
    }catch(e){toast('Import error: '+e.message,true);}
  };
  reader.readAsText(file); input.value='';
}
function saveHTML(){
  var b=new Blob([document.documentElement.outerHTML],{type:'text/html'});
  var a=document.createElement('a');a.href=URL.createObjectURL(b);
  a.download='MOTI_'+(S.dwgNo||'project')+'.html';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
}

/* ════ TOOLBAR SYNC ════ */
function syncTBAll(){
  function stb(id,val){var e=document.getElementById(id);if(e)e.value=val||'';}
  stb('tb-title',S.title);stb('tb-pn',S.partNo);stb('tb-dwg',S.dwgNo);
  stb('tb-rev',S.rev);stb('tb-co',S.company);stb('tb-drawn',S.drawnBy);
  stb('tb-len',S.cableLength);stb('tb-tol',S.lengthTol);
}

function setTheme(v){document.body.className=v;localStorage.setItem('moti_theme',v);}

/* ════ TABS ════ */
function showTab(id,btn){
  document.querySelectorAll('.tab').forEach(function(t){t.classList.remove('on');});
  document.querySelectorAll('.panel').forEach(function(p){p.classList.remove('on');});
  if(btn)btn.classList.add('on');
  var panel=document.getElementById('panel-'+id);
  if(panel)panel.classList.add('on');
  if(id==='canvas')    setTimeout(resizeCanvas,50);
  if(id==='harness')   setTimeout(renderHarness,60);
  if(id==='connectors')renderConnectorEditor();
  if(id==='partdb')renderPartDB();
}

/* ════ RENDER ALL ════ */
function renderAll(){
  saveState();
  renderDrawing();
  renderRoutes();
  renderBOM();
  renderCutList();
  renderCanvas();
  checkAWGWarnings();
  _updateUndoUI();
}

/* ════ INIT ════ */
window.addEventListener('load',function(){
  loadState(); initCL(); mergeCL();
  var th=localStorage.getItem('moti_theme')||'';
  document.body.className=th;
  var thSel=document.getElementById('th-sel'); if(thSel)thSel.value=th;
  syncTBAll(); buildSidebar(); initCanvas(); renderAll(); setTool('select');
  _updateUndoUI();

  document.addEventListener('keydown',function(e){
    var ctrl=e.ctrlKey||e.metaKey;
    if(e.key==='Escape'){
      if(document.getElementById('dwg-modal').classList.contains('open'))closeDwgModal();
      if(typeof wireStart!=='undefined'&&wireStart){wireStart=null;updateRouteHint(null);renderCanvas();}
      return;
    }
    if(ctrl&&e.key==='z'){e.preventDefault();undoAction();return;}
    if(ctrl&&(e.key==='y'||(e.shiftKey&&e.key==='z'))){e.preventDefault();redoAction();return;}
    if(ctrl&&e.key==='n'){e.preventDefault();newProject();return;}
    if(ctrl&&e.key==='s'){e.preventDefault();saveHTML();return;}
    var active=document.activeElement;
    var inInput=active.tagName==='INPUT'||active.tagName==='TEXTAREA'||active.tagName==='SELECT';
    if(!inInput){
      if(e.key==='v')setTool('select');
      if(e.key==='w')setTool('wire');
      if(e.key==='r')setTool('autoroute');
      if(e.key==='p')setTool('pan');
      if(e.key==='t')setTool('label');
      if((e.key==='Delete'||e.key==='Backspace')&&typeof selected!=='undefined'&&selected){
        pushUndo(); deleteEl(selected.id);
      }
    }
  });
});
