/* ============================================================
   PANELS.JS v2 — Routes, BOM, Cut List (improved)
   MOTI HarnessPro
   ============================================================ */

'use strict';

/* ════════════════════════════════════════════════════════════
   ROUTES PANEL
   - Shows ALL connectors (not just those with wires)
   - AWG mismatch warning badge
   - pushUndo before changes
   ════════════════════════════════════════════════════════════ */
function renderRoutes(){
  var connEls=S.elements.filter(function(e){return e.kind==='connector';});
  var gauges=['12AWG','14AWG','16AWG','18AWG','20AWG','22AWG','24AWG','26AWG','28AWG','30AWG'];

  var h='<div style="padding:14px;flex:1;overflow:auto">';
  // Header
  h+='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">';
  h+='<span style="font-size:11px;color:var(--accent);letter-spacing:2px">WIRE ROUTES';
  h+=' <span style="color:var(--text3);font-size:9px">('+S.wires.length+' wires / '+connEls.length+' connectors)</span></span>';
  h+='<div style="display:flex;gap:6px">';
  h+='<button class="btn btn-g" onclick="addWireRow()">+ ADD WIRE</button>';
  h+='<button class="btn" onclick="autoRouteAll()" title="Auto-connect all pins">⚡ ROUTE ALL</button>';
  h+='<button class="btn btn-r" onclick="clearWires()">CLEAR</button>';
  h+='</div></div>';

  // AWG warning panel
  h+='<div id="awg-warnings" style="margin-bottom:8px;display:none"></div>';

  // Connector summary badges
  if(connEls.length){
    h+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">';
    connEls.forEach(function(el){
      var lib=CL[el.connId];
      var total=lib?lib.pins:0;
      var used=S.wires.filter(function(w){return w.fromEl===el.id||w.toEl===el.id;}).length;
      var pct=total?Math.round(used/total*100):0;
      var col=pct===100?'#27ae60':pct>0?'#f39c12':'#555';
      h+='<div style="border:1px solid '+col+';padding:3px 7px;font-size:8px;color:'+col+'">';
      h+=esc(el.label)+' <span style="color:var(--text3)">'+used+'/'+total+'P</span></div>';
    });
    h+='</div>';
  }

  h+='<div style="overflow-x:auto">';
  h+='<table class="rt"><thead><tr>';
  h+='<th>ON</th><th>FROM</th><th>F.PIN</th><th>TO</th><th>T.PIN</th>';
  h+='<th>SIGNAL</th><th>GAUGE</th><th>COLOR</th><th>⚠</th><th>DEL</th>';
  h+='</tr></thead><tbody>';

  for(var i=0;i<S.wires.length;i++){
    var w=S.wires[i], wid=w.id;
    var fi='background:var(--bg1);border:1px solid var(--border);color:var(--accent);padding:2px 3px;font-size:9px';

    // Check AWG mismatch
    var awgWarn='';
    if(w.fromEl&&w.fromPin&&w.gauge){
      var fLib2=getElLib(w.fromEl);
      if(fLib2){
        var fPin=null;
        fLib2.pinout.forEach(function(pp){if(String(pp.id)===String(w.fromPin))fPin=pp;});
        if(fPin&&fPin.g&&parseInt(fPin.g)!==parseInt(w.gauge)){
          awgWarn='<span title="Gauge mismatch: pin spec='+esc(fPin.g)+'" style="color:#f39c12;cursor:help">⚠</span>';
        }
      }
    }

    h+='<tr'+(awgWarn?' style="background:rgba(243,156,18,0.06)"':'')+'>'; 
    h+='<td style="text-align:center"><input type="checkbox"'+(w.active!==false?' checked':'')+' onchange="wUpd(\''+wid+'\',\'active\',this.checked)"/></td>';

    // FROM connector
    h+='<td><select style="'+fi+';width:72px" onchange="wUpd(\''+wid+'\',\'fromEl\',this.value);renderRoutes()">';
    h+='<option value="">--</option>';
    connEls.forEach(function(el){h+='<option value="'+el.id+'"'+(w.fromEl===el.id?' selected':'')+'>'+esc(el.label)+'</option>';});
    h+='</select></td>';

    // FROM PIN
    var fLib=w.fromEl?getElLib(w.fromEl):null;
    h+='<td><select style="'+fi+';width:72px" onchange="wUpd(\''+wid+'\',\'fromPin\',this.value)">';
    h+='<option value="">--</option>';
    if(fLib){fLib.pinout.forEach(function(p){h+='<option value="'+p.id+'"'+(String(w.fromPin)===String(p.id)?' selected':'')+'>'+p.id+' '+p.n+'</option>';});}
    h+='</select></td>';

    // TO connector
    h+='<td><select style="'+fi+';width:72px" onchange="wUpd(\''+wid+'\',\'toEl\',this.value);renderRoutes()">';
    h+='<option value="">--</option>';
    connEls.forEach(function(el){h+='<option value="'+el.id+'"'+(w.toEl===el.id?' selected':'')+'>'+esc(el.label)+'</option>';});
    h+='</select></td>';

    // TO PIN
    var tLib=w.toEl?getElLib(w.toEl):null;
    h+='<td><select style="'+fi+';width:72px" onchange="wUpd(\''+wid+'\',\'toPin\',this.value)">';
    h+='<option value="">--</option>';
    if(tLib){tLib.pinout.forEach(function(p){h+='<option value="'+p.id+'"'+(String(w.toPin)===String(p.id)?' selected':'')+'>'+p.id+' '+p.n+'</option>';});}
    h+='</select></td>';

    h+='<td><input value="'+esc(w.signal||'')+'" style="'+fi+';width:65px" oninput="wUpd(\''+wid+'\',\'signal\',this.value)"/></td>';

    h+='<td><select style="'+fi+'" onchange="wUpd(\''+wid+'\',\'gauge\',this.value)">';
    gauges.forEach(function(g){h+='<option'+(w.gauge===g?' selected':'')+'>'+g+'</option>';});
    h+='</select></td>';

    var safeC=(w.color&&w.color[0]==='#')?w.color:'#888888';
    h+='<td><input type="color" value="'+safeC+'" style="width:28px;height:20px;border:none;padding:0;cursor:pointer" oninput="wUpd(\''+wid+'\',\'color\',this.value)"/></td>';
    h+='<td style="text-align:center">'+awgWarn+'</td>';
    h+='<td style="text-align:center"><button class="del" onclick="delWire(\''+wid+'\')">&#215;</button></td>';
    h+='</tr>';
  }

  // Unconnected pins summary
  if(connEls.length){
    var unconnected=[];
    connEls.forEach(function(el){
      var lib=CL[el.connId]; if(!lib) return;
      lib.pinout.forEach(function(p){
        var used=S.wires.some(function(w){
          return (w.fromEl===el.id&&String(w.fromPin)===String(p.id))||
                 (w.toEl  ===el.id&&String(w.toPin)  ===String(p.id));
        });
        if(!used) unconnected.push(el.label+'.'+p.id);
      });
    });
    if(unconnected.length){
      h+='<tr><td colspan="10" style="padding:6px 4px;color:#f39c12;font-size:8px;border-top:1px solid var(--border2)">';
      h+='⚠ Unconnected pins: '+unconnected.slice(0,20).map(esc).join(', ');
      if(unconnected.length>20) h+=' … and '+(unconnected.length-20)+' more';
      h+='</td></tr>';
    }
  }

  h+='</tbody></table></div></div>';
  document.getElementById('panel-routes').innerHTML=h;
  checkAWGWarnings();
}

function getElLib(elId){
  for(var i=0;i<S.elements.length;i++){
    if(S.elements[i].id===elId&&S.elements[i].kind==='connector') return CL[S.elements[i].connId];
  }
  return null;
}
function wUpd(id,k,v){
  pushUndo();
  for(var i=0;i<S.wires.length;i++){if(S.wires[i].id===id){S.wires[i][k]=v;break;}}
  saveState(); renderCanvas(); checkAWGWarnings();
}
function addWireRow(){
  pushUndo();
  S.wires.push({id:uid(),fromEl:'',fromPin:'',toEl:'',toPin:'',signal:'',gauge:'22AWG',color:'#888888',active:true});
  renderAll();
}
function clearWires(){
  if(!confirm('Clear all wires?')) return;
  pushUndo(); S.wires=[]; renderAll();
}
function delWire(id){
  pushUndo();
  S.wires=S.wires.filter(function(w){return w.id!==id;});
  renderAll();
}


/* ── Wire color picker (IEC standard) ── */
var _colorPickerWid = null;
function wOpenColorPicker(wid){
  _colorPickerWid = wid;
  var w = null; S.wires.forEach(function(x){if(x.id===wid)w=x;});
  if(!w) return;
  var existing = document.getElementById('color-picker-modal');
  if(existing) existing.remove();
  var modal = document.createElement('div');
  modal.id = 'color-picker-modal';
  modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);z-index:9998;display:flex;align-items:center;justify-content:center';
  modal.onclick = function(e){if(e.target===modal)modal.remove();};
  var inner = document.createElement('div');
  inner.style.cssText = 'background:var(--bg1);border:1px solid var(--border2);padding:0;min-width:500px;max-width:90vw';
  var hdr = '<div style="padding:8px 12px;background:var(--bg0);border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center">'
    +'<span style="font-size:10px;color:var(--accent);letter-spacing:2px">WIRE COLOR — IEC 60757</span>'
    +'<button id="cp-close-btn" style="background:none;border:none;color:var(--text2);cursor:pointer;font-size:14px">×</button>'
    +'</div>';
  var body = '<div style="padding:12px">' + renderColorPicker(w.color||'#888', w.color2||null, 'wSetColor', 'IEC') + '</div>';
  inner.innerHTML = hdr + body;
  modal.appendChild(inner);
  document.body.appendChild(modal);
  var closeBtn = document.getElementById('cp-close-btn');
  if(closeBtn) closeBtn.onclick = function(){ modal.remove(); };
}
function wSetColor(hex, hex2, abbr){
  if(!_colorPickerWid) return;
  pushUndo();
  S.wires.forEach(function(w){
    if(w.id===_colorPickerWid){
      w.color=hex; w.color2=hex2||null; w.colorAbbr=abbr||'';
    }
  });
  saveState(); renderRoutes(); renderCanvas();
  var modal=document.getElementById('color-picker-modal');
  if(modal)modal.remove();
}

/* ════════════════════════════════════════════════════════════
   BOM PANEL — with Generate button
   ════════════════════════════════════════════════════════════ */
function renderBOM(){
  var h='<div style="padding:14px;flex:1;overflow:auto">';
  h+='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">';
  h+='<span style="font-size:11px;color:var(--accent);letter-spacing:2px">BILL OF MATERIALS</span>';
  h+='<div style="display:flex;gap:6px">';
  h+='<button class="btn btn-g" onclick="generateBOM()" title="Auto-generate from canvas">⚙ GENERATE</button>';
  h+='<button class="btn" onclick="addBOM()">+ ADD</button>';
  h+='<button class="btn btn-r" onclick="clearBOM()">CLEAR</button>';
  h+='</div></div>';

  h+='<table class="rt"><thead><tr><th>#</th><th>QTY</th><th>UNIT</th><th>PART NO.</th><th>DESCRIPTION</th><th>CAT</th><th>DEL</th></tr></thead><tbody>';
  for(var i=0;i<S.bomItems.length;i++){
    var it=S.bomItems[i], bid=it.id;
    var fi='background:var(--bg1);border:1px solid var(--border);color:var(--accent);padding:2px 3px;font-size:9px';
    h+='<tr><td style="text-align:center;font-weight:bold;color:var(--accent)">'+(i+1)+'</td>';
    h+='<td><input type="number" min="0.01" step="0.01" value="'+esc(it.qty||1)+'" style="'+fi+';width:52px" oninput="bUpd(\''+bid+'\',\'qty\',this.value)"/></td>';
    h+='<td><select style="'+fi+'" onchange="bUpd(\''+bid+'\',\'unit\',this.value)">';
    ['EA','M','FT','SET','LOT','KG','CM'].forEach(function(u){h+='<option'+(it.unit===u?' selected':'')+'>'+u+'</option>';});
    h+='</select></td>';
    h+='<td><input value="'+esc(it.pn||'')+'" style="'+fi+';width:95px" placeholder="Part #" oninput="bUpd(\''+bid+'\',\'pn\',this.value)"/></td>';
    h+='<td><input value="'+esc(it.desc||'')+'" style="'+fi+';width:190px" placeholder="Description" oninput="bUpd(\''+bid+'\',\'desc\',this.value)"/></td>';
    h+='<td><select style="'+fi+'" onchange="bUpd(\''+bid+'\',\'cat\',this.value)">';
    ['PURCHASED','MATERIAL','HARDWARE','REFERENCE','FASTENER'].forEach(function(c){h+='<option'+(it.cat===c?' selected':'')+'>'+c+'</option>';});
    h+='</select></td>';
    h+='<td style="text-align:center"><button class="del" onclick="delBOM(\''+bid+'\')">&#215;</button></td></tr>';
  }
  if(!S.bomItems.length){
    h+='<tr><td colspan="7" style="padding:20px;text-align:center;color:var(--text3)">No items. Click ⚙ GENERATE or + ADD</td></tr>';
  }
  h+='</tbody></table>';

  // Totals
  var cats={};
  S.bomItems.forEach(function(it){ cats[it.cat]=(cats[it.cat]||0)+1; });
  if(S.bomItems.length){
    h+='<div style="margin-top:8px;font-size:8px;color:var(--text3)">';
    h+='Total: '+S.bomItems.length+' items';
    Object.keys(cats).forEach(function(c){ h+=' &nbsp;|&nbsp; '+c+': '+cats[c]; });
    h+='</div>';
  }
  h+='</div>';
  document.getElementById('panel-bom').innerHTML=h;
}
function bUpd(id,k,v){
  for(var i=0;i<S.bomItems.length;i++){if(S.bomItems[i].id===id){S.bomItems[i][k]=v;break;}}
  saveState();
}
function addBOM(){
  pushUndo();
  S.bomItems.push({id:uid(),qty:1,unit:'EA',pn:'',desc:'',cat:'PURCHASED'});
  renderAll();
}
function delBOM(id){
  pushUndo();
  S.bomItems=S.bomItems.filter(function(b){return b.id!==id;});
  renderAll();
}
function clearBOM(){
  if(!confirm('Clear all BOM items?')) return;
  pushUndo(); S.bomItems=[]; renderAll();
}

/* ════════════════════════════════════════════════════════════
   CUT LIST — with strip lengths both sides
   ════════════════════════════════════════════════════════════ */
function renderCutList(){
  var active=S.wires.filter(function(w){return w.active!==false&&w.fromEl&&w.toEl;});
  var stripFrom=S.stripFrom||8;
  var stripTo  =S.stripTo  ||8;

  var h='<div style="padding:14px;flex:1;overflow:auto">';
  h+='<div style="font-size:11px;color:var(--accent);letter-spacing:2px;margin-bottom:10px">CUT LIST</div>';

  // Strip length controls
  h+='<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;padding:8px;background:var(--bg1);border:1px solid var(--border)">';
  h+='<span style="font-size:8px;color:var(--text3)">STRIP LENGTHS:</span>';
  h+='<label style="font-size:9px;color:var(--text2)">FROM side&nbsp;';
  h+='<input type="number" min="1" max="50" value="'+stripFrom+'" style="width:45px;background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:2px 4px;font-size:9px" oninput="S.stripFrom=+this.value;saveState();renderCutList()"/> mm</label>';
  h+='<label style="font-size:9px;color:var(--text2)">TO side&nbsp;';
  h+='<input type="number" min="1" max="50" value="'+stripTo+'" style="width:45px;background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:2px 4px;font-size:9px" oninput="S.stripTo=+this.value;saveState();renderCutList()"/> mm</label>';
  h+='<span style="font-size:8px;color:var(--text3);margin-left:8px">Cut length = cable length + strip (FROM) + strip (TO)</span>';
  h+='</div>';

  // Table
  h+='<table class="rt"><thead><tr>';
  h+='<th>#</th><th>FROM</th><th>TO</th><th>SIGNAL</th><th>GAUGE</th><th>COLOR</th>';
  h+='<th>CABLE mm</th><th>STRIP FROM</th><th>STRIP TO</th><th>CUT LENGTH</th>';
  h+='</tr></thead><tbody>';

  active.forEach(function(w,i){
    var fEl=null, tEl=null;
    S.elements.forEach(function(e){if(e.id===w.fromEl)fEl=e;if(e.id===w.toEl)tEl=e;});
    var cutLen=S.cableLength+stripFrom+stripTo;

    h+='<tr>';
    h+='<td style="text-align:center;color:var(--text2)">'+(i+1)+'</td>';
    h+='<td style="font-weight:bold;color:var(--accent3)">'+esc((fEl?fEl.label:'?')+'.'+w.fromPin)+'</td>';
    h+='<td style="font-weight:bold;color:var(--accent3)">'+esc((tEl?tEl.label:'?')+'.'+w.toPin)+'</td>';
    h+='<td>'+esc(w.signal||'--')+'</td>';
    h+='<td style="text-align:center">'+esc(w.gauge)+'</td>';
    h+='<td style="text-align:center"><span style="display:inline-flex;align-items:center;gap:4px">'
      +'<span style="display:inline-block;width:13px;height:13px;border-radius:50%;background:'+sc(w.color||'#888')+';border:1px solid #333"></span>'
      +esc(w.color)+'</span></td>';
    h+='<td style="text-align:center">'+S.cableLength+' ±'+S.lengthTol+'</td>';
    h+='<td style="text-align:center;color:var(--accent2)">'+stripFrom+'</td>';
    h+='<td style="text-align:center;color:var(--accent2)">'+stripTo+'</td>';
    h+='<td style="text-align:center;font-weight:bold;color:var(--accent)">'+cutLen+' mm</td>';
    h+='</tr>';
  });

  // Summary
  h+='<tr><td colspan="10" style="padding:8px 4px;color:var(--text2);font-size:8px;border-top:1px solid var(--border2)">';
  h+='Total: '+active.length+' wires';
  h+=' &nbsp;|&nbsp; Cable: '+S.cableLength+'mm ±'+S.lengthTol;
  h+=' &nbsp;|&nbsp; Cut length: '+(S.cableLength+stripFrom+stripTo)+'mm';
  h+=' &nbsp;|&nbsp; Strip FROM: '+stripFrom+'mm &nbsp; Strip TO: '+stripTo+'mm';
  h+='</td></tr>';

  h+='</tbody></table>';

  if(!active.length){
    h+='<div style="padding:20px;text-align:center;color:var(--text3);font-size:9px">No active wires with both endpoints connected.</div>';
  }

  h+='</div>';
  document.getElementById('panel-cutlist').innerHTML=h;
}

// ── renderDrawing (DRAWING tab) ──
function renderDrawing(){
  // placeholder — main drawing is in the ENG DRAWING modal
  var el=document.getElementById('panel-drawing');
  if(!el) return;
  el.innerHTML='<div style="padding:20px;color:var(--text3);font-size:9px">'
    +'Use the <b style="color:var(--accent)">📐 ENG DRAWING</b> button in the toolbar for the full engineering drawing.<br><br>'
    +'This tab shows a quick schematic view.</div>';
}
