/* ============================================================
   PARTDB_PANEL.JS — Part Database UI panel
   MOTI HarnessPro
   ============================================================ */
'use strict';

function renderPartDB() {
  var panel = document.getElementById('panel-partdb');
  if(!panel) return;

  var h = '<div style="display:grid;grid-template-columns:1fr 320px;height:100%;overflow:hidden">';

  /* ── Left: parts table ── */
  h += '<div style="display:flex;flex-direction:column;overflow:hidden;border-right:1px solid var(--border2)">';
  h += '<div style="padding:10px 14px 8px;background:var(--bg1);border-bottom:1px solid var(--border);flex-shrink:0;display:flex;gap:8px;align-items:center">';
  h += '<span style="font-size:10px;color:var(--accent);letter-spacing:2px">PART DATABASE</span>';
  h += '<span style="color:var(--text3);font-size:8px">'+(PART_DB.parts.length)+' parts</span>';
  h += '<span style="flex:1"></span>';
  h += '<input id="pdb-search" placeholder="Search P/N or description…" style="background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:3px 8px;font-size:9px;width:200px;font-family:monospace" oninput="pdbFilter()">';
  h += '<button class="btn btn-g" onclick="pdbAddPart()">+ ADD</button>';
  h += '<button class="btn" onclick="document.getElementById(\'pdb-import-json\').click()">⬆ JSON</button>';
  h += '<input id="pdb-import-json" type="file" accept=".json" style="display:none" onchange="pdbImportJSON(this)">';
  h += '<button class="btn" onclick="document.getElementById(\'pdb-import-csv\').click()">⬆ CSV</button>';
  h += '<input id="pdb-import-csv" type="file" accept=".csv,.txt" style="display:none" onchange="pdbImportCSV(this)">';
  h += '<button class="btn" onclick="pdbExport()">⬇ EXPORT</button>';
  h += '</div>';

  h += '<div style="flex:1;overflow:auto;padding:0">';
  h += '<table class="rt" id="pdb-table"><thead><tr>';
  h += '<th>PART NUMBER</th><th>DESCRIPTION</th><th>CAT</th><th>UNIT</th><th>STANDARD</th><th>USE</th><th>DEL</th>';
  h += '</tr></thead><tbody id="pdb-tbody">';
  h += _pdbRows(PART_DB.parts);
  h += '</tbody></table></div></div>';

  /* ── Right: part editor ── */
  h += '<div id="pdb-editor" style="background:var(--bg0);display:flex;flex-direction:column;overflow:auto">';
  h += '<div style="padding:12px 14px 8px;border-bottom:1px solid var(--border);flex-shrink:0">';
  h += '<span style="font-size:10px;color:var(--accent);letter-spacing:2px">PART EDITOR</span></div>';
  h += '<div style="padding:14px;color:var(--text3);font-size:9px">Select a part to edit, or click + ADD</div>';
  h += '</div>';

  h += '</div>';
  panel.innerHTML = h;
}

function _pdbRows(parts) {
  var fi = 'background:var(--bg1);border:1px solid var(--border);color:var(--accent);padding:2px 4px;font-size:8px;font-family:monospace';
  var h = '';
  parts.forEach(function(p, i){
    h += '<tr onclick="pdbSelectPart(\''+esc(p.pn)+'\')" style="cursor:pointer">';
    h += '<td style="font-weight:bold;color:var(--accent3)">'+esc(p.pn)+'</td>';
    h += '<td>'+esc(p.desc)+'</td>';
    h += '<td><span style="font-size:7px;padding:1px 5px;background:var(--bg3);color:var(--text2);border-radius:8px">'+esc(p.cat||'')+'</span></td>';
    h += '<td style="text-align:center;color:var(--text2)">'+esc(p.unit||'EA')+'</td>';
    h += '<td style="color:var(--text3);font-size:8px">'+esc(p.std||'')+'</td>';
    h += '<td style="text-align:center"><button class="btn btn-g" style="padding:2px 6px;font-size:7px" onclick="event.stopPropagation();pdbUsePart(\''+esc(p.pn)+'\')">+ BOM</button></td>';
    h += '<td style="text-align:center"><button class="del" onclick="event.stopPropagation();pdbDelPart(\''+esc(p.pn)+'\')">&#215;</button></td>';
    h += '</tr>';
  });
  if(!parts.length) h += '<tr><td colspan="7" style="padding:20px;text-align:center;color:var(--text3)">No parts found</td></tr>';
  return h;
}

function pdbFilter() {
  var q = document.getElementById('pdb-search');
  var tbody = document.getElementById('pdb-tbody');
  if(!q||!tbody) return;
  tbody.innerHTML = _pdbRows(partDBSearch(q.value));
}

function pdbSelectPart(pn) {
  var part = null;
  PART_DB.parts.forEach(function(p){ if(p.pn===pn) part=p; });
  if(!part) return;

  var cats = ['CONNECTOR','WIRE','SLEEVE','HEATSHRINK','TERMINAL','HARDWARE','MATERIAL','OTHER'];
  var fi = 'background:var(--bg2);border:1px solid var(--border);color:var(--accent);padding:4px 6px;font-size:9px;width:100%;font-family:monospace;box-sizing:border-box';
  var ed = document.getElementById('pdb-editor');
  if(!ed) return;

  ed.innerHTML = '<div style="padding:12px 14px 8px;border-bottom:1px solid var(--border);flex-shrink:0;display:flex;justify-content:space-between;align-items:center">'
    +'<span style="font-size:10px;color:var(--accent);letter-spacing:2px">EDIT PART</span>'
    +'<button class="btn btn-g" onclick="pdbSaveSelected()" style="padding:3px 10px">💾 SAVE</button>'
    +'</div>'
    +'<div style="padding:14px">'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">PART NUMBER</div>'
    +'<input id="ped-pn" value="'+esc(part.pn)+'" style="'+fi+'"/></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">DESCRIPTION</div>'
    +'<input id="ped-desc" value="'+esc(part.desc||'')+'" style="'+fi+'"/></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">CATEGORY</div>'
    +'<select id="ped-cat" style="'+fi+'">'
    +cats.map(function(c){return '<option'+(part.cat===c?' selected':'')+'>'+c+'</option>';}).join('')
    +'</select></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">UNIT</div>'
    +'<select id="ped-unit" style="'+fi+'">'
    +['EA','M','FT','KG','SET','LOT'].map(function(u){return '<option'+(part.unit===u?' selected':'')+'>'+u+'</option>';}).join('')
    +'</select></div>'
    +'<div style="margin-bottom:8px"><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">STANDARD / SPEC</div>'
    +'<input id="ped-std" value="'+esc(part.std||'')+'" placeholder="e.g. MIL-C-24308, UL1007" style="'+fi+'"/></div>'
    +'<div><div style="font-size:7px;color:var(--text3);margin-bottom:3px;letter-spacing:1px">NOTES</div>'
    +'<textarea id="ped-notes" rows="3" style="'+fi+';resize:vertical">'+esc(part.notes||'')+'</textarea></div>'
    +'<div style="margin-top:4px"><input type="hidden" id="ped-orig-pn" value="'+esc(part.pn)+'"></div>'
    +'</div>';
}

function pdbSaveSelected() {
  var origPn = document.getElementById('ped-orig-pn');
  if(!origPn) return;
  var pn   = document.getElementById('ped-pn').value.trim();
  var desc = document.getElementById('ped-desc').value.trim();
  var cat  = document.getElementById('ped-cat').value;
  var unit = document.getElementById('ped-unit').value;
  var std  = document.getElementById('ped-std').value.trim();
  var notes= document.getElementById('ped-notes').value.trim();
  if(!pn) { toast('Part number required', true); return; }

  var found = false;
  PART_DB.parts.forEach(function(p){
    if(p.pn === origPn.value) { p.pn=pn; p.desc=desc; p.cat=cat; p.unit=unit; p.std=std; p.notes=notes; found=true; }
  });
  if(!found) PART_DB.parts.push({pn:pn,desc:desc,cat:cat,unit:unit,std:std,notes:notes});
  partDBSave();
  renderPartDB();
  toast('Part saved: '+pn);
}

function pdbAddPart() {
  var newPn = 'PN-' + Date.now().toString(36).toUpperCase();
  PART_DB.parts.push({pn:newPn, desc:'New Part', cat:'MATERIAL', unit:'EA', std:'', notes:''});
  partDBSave();
  renderPartDB();
  pdbSelectPart(newPn);
}

function pdbDelPart(pn) {
  if(!confirm('Delete part '+pn+'?')) return;
  PART_DB.parts = PART_DB.parts.filter(function(p){return p.pn!==pn;});
  partDBSave();
  renderPartDB();
}

function pdbUsePart(pn) {
  var part = null;
  PART_DB.parts.forEach(function(p){ if(p.pn===pn) part=p; });
  if(!part) return;
  pushUndo();
  S.bomItems.push({id:uid(), qty:1, unit:part.unit||'EA', pn:part.pn, desc:part.desc, cat:part.cat||'PURCHASED'});
  saveState();
  toast('Added to BOM: '+pn);
}

function pdbImportJSON(input) {
  var file = input.files[0]; if(!file) return;
  var reader = new FileReader();
  reader.onload = function(ev){
    try {
      partDBImportJSON(ev.target.result);
      renderPartDB();
      toast('Imported '+PART_DB.parts.length+' parts');
    } catch(e) { toast('Import error: '+e.message, true); }
  };
  reader.readAsText(file); input.value='';
}

function pdbImportCSV(input) {
  var file = input.files[0]; if(!file) return;
  var reader = new FileReader();
  reader.onload = function(ev){
    try {
      var n = partDBImportCSV(ev.target.result);
      renderPartDB();
      toast('Imported '+n+' parts from CSV');
    } catch(e) { toast('CSV import error: '+e.message, true); }
  };
  reader.readAsText(file); input.value='';
}

function pdbExport() {
  var b = new Blob([JSON.stringify(PART_DB,null,2)],{type:'application/json'});
  var a = document.createElement('a'); a.href=URL.createObjectURL(b);
  a.download='parts_db_'+(PART_DB.company||'company')+'_'+new Date().toISOString().slice(0,10)+'.json';
  document.body.appendChild(a);a.click();document.body.removeChild(a);
  toast('Part database exported');
}
