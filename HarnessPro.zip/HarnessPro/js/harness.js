/* ============================================================
   HARNESS.JS v3 — Physical Harness View
   - Proper backbone/branch topology (like reference image)
   - Connectors with real exit angles
   - Branch merge points visible
   - Wire color stripes per IEC standard
   MOTI HarnessPro
   ============================================================ */
'use strict';

/* H is declared in app.js */
var HVC=null, HVCTX=null;
var hvPan={a:false,sx:0,sy:0,px:0,py:0};

/* ── coordinate helpers ── */
function hw2s(x,y){return{x:x*H.zoom+H.panX, y:y*H.zoom+H.panY};}
function hs2w(x,y){return{x:(x-H.panX)/H.zoom, y:(y-H.panY)/H.zoom};}
function hvNById(id){for(var i=0;i<H.nodes.length;i++)if(H.nodes[i].id===id)return H.nodes[i];return null;}
function hvSById(id){for(var i=0;i<H.segs.length;i++) if(H.segs[i].id===id)return H.segs[i];return null;}
function hvDist(ax,ay,bx,by){return Math.sqrt((bx-ax)*(bx-ax)+(by-ay)*(by-ay));}
function hvPSD(px,py,ax,ay,bx,by){
  var dx=bx-ax,dy=by-ay,l2=dx*dx+dy*dy;
  if(l2<.001)return hvDist(px,py,ax,ay);
  var t=Math.max(0,Math.min(1,((px-ax)*dx+(py-ay)*dy)/l2));
  return hvDist(px,py,ax+t*dx,ay+t*dy);
}
function hvSegThick(seg){return Math.max(5,Math.min(32,5+(seg.wires?seg.wires.length:0)*2.4));}

/* ── Build topology from S.elements + S.wires ── */
function hvBuildTopology(){
  var connEls=S.elements.filter(function(e){return e.kind==='connector';});

  /* Preserve positions of existing nodes */
  var posCache={};
  H.nodes.forEach(function(n){posCache[n.id]={x:n.x,y:n.y,angle:n.angle};});
  var junctions=H.nodes.filter(function(n){return n.isJunction;});

  /* Rebuild connector nodes */
  H.nodes=connEls.map(function(el,i){
    var c=posCache[el.id];
    var n=connEls.length, a=(i/Math.max(n,1))*Math.PI*2-Math.PI/2, r=180+n*28;
    return{
      id:el.id, label:el.label, connId:el.connId,
      x:c?c.x:Math.cos(a)*r, y:c?c.y:Math.sin(a)*r,
      angle:c&&c.angle!==undefined?c.angle:(a*180/Math.PI+90),
      isJunction:false
    };
  }).concat(junctions);

  /* Deduplicate */
  var seen={};
  H.nodes=H.nodes.filter(function(n){if(seen[n.id])return false;seen[n.id]=true;return true;});

  /* Build segments — group wires between same connector pairs */
  var segMap={};
  S.wires.forEach(function(w){
    if(!w.fromEl||!w.toEl) return;
    var key=[w.fromEl,w.toEl].sort().join('~~');
    if(!segMap[key]) segMap[key]={from:w.fromEl,to:w.toEl,wires:[]};
    segMap[key].wires.push(w.id);
  });

  var scache={};
  H.segs.forEach(function(s){scache[s.id]=s;});

  H.segs=Object.keys(segMap).map(function(key){
    var sm=segMap[key], ex=scache[key];
    return{
      id:key, from:sm.from, to:sm.to, wires:sm.wires,
      lengthMm: ex?ex.lengthMm:(S.cableLength||500),
      label:    ex?ex.label:'',
      pts:      ex&&ex.pts?ex.pts:[]
    };
  });
}

/* ── Auto-layout: intelligent branching like reference image ──
   Puts one connector as "main", others spread around it.
   If connectors share many wires → they're close on backbone.
*/
function hvAutoLayout(){
  var cn=H.nodes.filter(function(n){return !n.isJunction;}), n=cn.length;
  if(!n) return;
  if(n===1){cn[0].x=0;cn[0].y=0;cn[0].angle=0;return;}
  if(n===2){cn[0].x=-240;cn[0].y=0;cn[0].angle=180;cn[1].x=240;cn[1].y=0;cn[1].angle=0;return;}

  /* Find connector with most wire connections → "hub" */
  var wireCount={};
  cn.forEach(function(nd){wireCount[nd.id]=0;});
  S.wires.forEach(function(w){
    if(wireCount[w.fromEl]!==undefined) wireCount[w.fromEl]++;
    if(wireCount[w.toEl]!==undefined)   wireCount[w.toEl]++;
  });
  cn.sort(function(a,b){return wireCount[b.id]-wireCount[a.id];});

  /* Hub goes right-center, branches spread out to left */
  var hub=cn[0];
  hub.x=280; hub.y=0; hub.angle=0;

  var branches=cn.slice(1);
  if(branches.length===1){
    branches[0].x=-280; branches[0].y=0; branches[0].angle=180;
    return;
  }

  /* Spread branches in a fan on the left side */
  var fanH=Math.min(300, branches.length*70);
  branches.forEach(function(nd,i){
    var t=(branches.length===1)?0.5:(i/(branches.length-1));
    nd.x = -280 + (Math.random()*40-20);  /* slight x variance */
    nd.y = -fanH/2 + t*fanH;
    nd.angle = 180 + (nd.y>0?-15:15);    /* slight tilt toward hub */
  });
}

/* ── Get cable path points (with stub from connector) ── */
function hvGetPath(seg,n1,n2){
  var stub=Math.max(25,Math.min(60,30));
  var a1=(n1.angle||0)*Math.PI/180, a2=(n2.angle||0)*Math.PI/180;
  var s1={x:n1.x+Math.cos(a1)*stub, y:n1.y+Math.sin(a1)*stub};
  var s2={x:n2.x+Math.cos(a2)*stub, y:n2.y+Math.sin(a2)*stub};
  return [{x:n1.x,y:n1.y}, s1].concat(seg.pts||[]).concat([s2, {x:n2.x,y:n2.y}]);
}

/* ── Main render entry ── */
function renderHarness(){
  hvBuildTopology();
  HVC=document.getElementById('hv-cv');
  if(!HVC) return;
  var wrap=document.getElementById('hv-wrap');
  if(!wrap) return;
  HVC.width=wrap.clientWidth||900;
  HVC.height=wrap.clientHeight||560;
  HVCTX=HVC.getContext('2d');
  hvFit();
  /* Events */
  HVC.onmousedown=hvMD; HVC.onmousemove=hvMM; HVC.onmouseup=hvMU;
  HVC.addEventListener('wheel',hvMW,{passive:false});
  HVC.ondblclick=hvDbl;
  window.addEventListener('resize',hvResize);
}

function hvFit(){
  if(!HVC) return;
  var pts=[];
  H.nodes.forEach(function(n){pts.push({x:n.x,y:n.y});});
  if(!pts.length){H.zoom=1;H.panX=HVC.width/2;H.panY=HVC.height/2;hvDraw();return;}
  var mn={x:pts[0].x-100,y:pts[0].y-100},mx={x:pts[0].x+100,y:pts[0].y+100};
  pts.forEach(function(p){mn.x=Math.min(mn.x,p.x-100);mn.y=Math.min(mn.y,p.y-100);mx.x=Math.max(mx.x,p.x+100);mx.y=Math.max(mx.y,p.y+100);});
  var pw=HVC.width-80, ph=HVC.height-80;
  H.zoom=Math.max(0.1,Math.min(3,Math.min(pw/(mx.x-mn.x||1),ph/(mx.y-mn.y||1))));
  H.panX=40-mn.x*H.zoom; H.panY=40-mn.y*H.zoom;
  hvDraw();
}

function hvSync(){hvBuildTopology();hvDraw();toast('Synced from canvas');}

/* ════════════════════════════════════════════════════════════
   DRAW
   ════════════════════════════════════════════════════════════ */
function hvDraw(){
  if(!HVC||!HVCTX) return;
  var W=HVC.width, Ht=HVC.height, z=H.zoom;
  HVCTX.clearRect(0,0,W,Ht);

  /* Paper background */
  HVCTX.fillStyle='#c8c4b8'; HVCTX.fillRect(0,0,W,Ht);

  /* Dot grid */
  HVCTX.fillStyle='rgba(0,0,0,0.07)';
  var step=25*z, ox=((H.panX%step)+step)%step, oy=((H.panY%step)+step)%step;
  for(var gx=ox;gx<W;gx+=step) for(var gy=oy;gy<Ht;gy+=step){
    HVCTX.beginPath(); HVCTX.arc(gx,gy,0.9,0,Math.PI*2); HVCTX.fill();
  }

  /* Draw cables */
  H.segs.forEach(function(seg){hvDrawCable(seg);});

  /* Draw connectors */
  H.nodes.forEach(function(nd){hvDrawNode(nd);});

  /* Dimension labels */
  H.segs.forEach(function(seg){hvDrawDimLabel(seg);});

  /* Bend handles for selected segment */
  if(H.sel&&H.sel.type==='seg'){
    var sg=hvSById(H.sel.id);
    if(sg)(sg.pts||[]).forEach(function(p){
      var s=hw2s(p.x,p.y);
      HVCTX.beginPath(); HVCTX.arc(s.x,s.y,6*z,0,Math.PI*2);
      HVCTX.fillStyle='rgba(200,168,40,.9)'; HVCTX.fill();
      HVCTX.strokeStyle='#fff'; HVCTX.lineWidth=1.5; HVCTX.stroke();
    });
  }
}

/* ── Draw cable segment with braided sheath + wire stripes ── */
function hvDrawCable(seg){
  var n1=hvNById(seg.from), n2=hvNById(seg.to);
  if(!n1||!n2) return;
  var thick=hvSegThick(seg), isSel=(H.sel&&H.sel.id===seg.id);
  var pts=hvGetPath(seg,n1,n2);
  var spts=pts.map(function(p){return hw2s(p.x,p.y);});
  var z=H.zoom;

  function poly(pts2){
    HVCTX.beginPath(); HVCTX.moveTo(pts2[0].x,pts2[0].y);
    for(var i=1;i<pts2.length;i++) HVCTX.lineTo(pts2[i].x,pts2[i].y);
    HVCTX.stroke();
  }

  /* Shadow */
  HVCTX.shadowColor='rgba(0,0,0,.35)'; HVCTX.shadowBlur=6*z; HVCTX.shadowOffsetY=2*z;
  HVCTX.strokeStyle=isSel?'#b85810':'#1e1c16';
  HVCTX.lineWidth=thick*z; HVCTX.lineCap='round'; HVCTX.lineJoin='round';
  HVCTX.setLineDash([]);
  poly(spts);
  HVCTX.shadowBlur=0; HVCTX.shadowOffsetY=0;

  /* Highlight stripe */
  HVCTX.strokeStyle=isSel?'rgba(220,140,40,.5)':'rgba(170,155,118,.38)';
  HVCTX.lineWidth=thick*z*.36; poly(spts);

  /* Braid hatch */
  for(var pi=0;pi<spts.length-1;pi++){
    var ax=spts[pi].x,ay=spts[pi].y,bx=spts[pi+1].x,by=spts[pi+1].y;
    var slen=Math.sqrt((bx-ax)*(bx-ax)+(by-ay)*(by-ay));
    if(slen<1) continue;
    var ag=Math.atan2(by-ay,bx-ax);
    var nx=Math.cos(ag+Math.PI/2)*thick*z*.44, ny=Math.sin(ag+Math.PI/2)*thick*z*.44;
    var sp=Math.max(7,thick*z*.9);
    HVCTX.strokeStyle='rgba(195,182,148,.32)'; HVCTX.lineWidth=0.7;
    for(var t=sp/2;t<slen-sp/2;t+=sp){
      var tx=ax+Math.cos(ag)*t, ty=ay+Math.sin(ag)*t;
      var dx=Math.cos(ag)*4*z, dy=Math.sin(ag)*4*z;
      HVCTX.beginPath(); HVCTX.moveTo(tx+nx,ty+ny); HVCTX.lineTo(tx-nx+dx,ty-ny+dy); HVCTX.stroke();
      HVCTX.beginPath(); HVCTX.moveTo(tx-nx,ty-ny); HVCTX.lineTo(tx+nx+dx,ty+ny+dy); HVCTX.stroke();
    }
  }

  /* Wire colour stripes (IEC order) */
  var wCols=[];
  (seg.wires||[]).forEach(function(wid){
    for(var i=0;i<S.wires.length;i++){
      var w=S.wires[i];
      if(w.id===wid){
        wCols.push({c1:w.color||'#888', c2:w.color2||null});
        break;
      }
    }
  });
  var maxS=Math.min(wCols.length,10);
  if(maxS>0){
    var sw=Math.max(1,thick*z*.11), spread=thick*z*.3;
    wCols.slice(0,maxS).forEach(function(wc,ci){
      var t2=maxS===1?0:((ci/(maxS-1))*2-1)*spread;
      /* Build path offset */
      var dOff='';
      for(var pi2=0;pi2<spts.length-1;pi2++){
        var ddx=spts[pi2+1].x-spts[pi2].x, ddy=spts[pi2+1].y-spts[pi2].y;
        var l=Math.sqrt(ddx*ddx+ddy*ddy)||1;
        var nnx=-ddy/l*t2, nny=ddx/l*t2;
        if(pi2===0){ HVCTX.beginPath(); HVCTX.moveTo(spts[0].x+nnx,spts[0].y+nny); }
        HVCTX.lineTo(spts[pi2+1].x+nnx,spts[pi2+1].y+nny);
      }
      HVCTX.strokeStyle=sc(wc.c1); HVCTX.lineWidth=sw; HVCTX.lineCap='butt'; HVCTX.stroke();
      /* Stripe overlay if combo color */
      if(wc.c2){
        HVCTX.setLineDash([sw*2,sw*2]);
        HVCTX.strokeStyle=sc(wc.c2); HVCTX.lineWidth=sw*0.6;
        HVCTX.beginPath();
        for(var pi3=0;pi3<spts.length-1;pi3++){
          var ddx2=spts[pi3+1].x-spts[pi3].x, ddy2=spts[pi3+1].y-spts[pi3].y;
          var l2=Math.sqrt(ddx2*ddx2+ddy2*ddy2)||1;
          var nnx2=-ddy2/l2*t2, nny2=ddx2/l2*t2;
          if(pi3===0) HVCTX.moveTo(spts[0].x+nnx2,spts[0].y+nny2);
          HVCTX.lineTo(spts[pi3+1].x+nnx2,spts[pi3+1].y+nny2);
        }
        HVCTX.stroke();
        HVCTX.setLineDash([]);
      }
    });
  }

  /* Selection outline */
  if(isSel){
    HVCTX.strokeStyle='rgba(200,120,40,.6)'; HVCTX.lineWidth=(thick+4)*z;
    HVCTX.setLineDash([5*z,4*z]); poly(spts); HVCTX.setLineDash([]);
  }
}

/* ── Dimension label on cable ── */
function hvDrawDimLabel(seg){
  var n1=hvNById(seg.from), n2=hvNById(seg.to);
  if(!n1||!n2) return;
  var pts=hvGetPath(seg,n1,n2);
  var spts=pts.map(function(p){return hw2s(p.x,p.y);});
  var thick=hvSegThick(seg), z=H.zoom, isSel=(H.sel&&H.sel.id===seg.id);

  /* Find midpoint + angle */
  var totLen=0, cumL=[0];
  for(var i=0;i<spts.length-1;i++){
    var dx=spts[i+1].x-spts[i].x, dy=spts[i+1].y-spts[i].y;
    totLen+=Math.sqrt(dx*dx+dy*dy); cumL.push(totLen);
  }
  if(totLen<20) return;
  var half=totLen/2, mid={x:0,y:0}, mAng=0;
  for(var i=1;i<spts.length;i++){
    if(cumL[i]>=half){
      var tt=(half-cumL[i-1])/(cumL[i]-cumL[i-1]);
      mid={x:spts[i-1].x+(spts[i].x-spts[i-1].x)*tt, y:spts[i-1].y+(spts[i].y-spts[i-1].y)*tt};
      mAng=Math.atan2(spts[i].y-spts[i-1].y,spts[i].x-spts[i-1].x); break;
    }
  }
  var px=Math.cos(mAng+Math.PI/2), py=Math.sin(mAng+Math.PI/2);
  if(py>0){px=-px;py=-py;}
  var off=(thick*z/2)+18;
  var lx=mid.x+px*off, ly=mid.y+py*off;
  var txt=(seg.label?seg.label+' | ':'')+seg.lengthMm+' mm'+(S.lengthTol?' ±'+S.lengthTol:'');
  var drawAng=(mAng>Math.PI/2||mAng<-Math.PI/2)?mAng+Math.PI:mAng;

  HVCTX.save();
  HVCTX.translate(lx,ly); HVCTX.rotate(drawAng);
  HVCTX.font='bold '+(9*z)+'px \'Courier New\'';
  HVCTX.textAlign='center';
  var tw=HVCTX.measureText(txt).width+12;
  hvRR(HVCTX,-tw/2,-10*z,tw,12*z,2*z);
  HVCTX.fillStyle=isSel?'rgba(185,90,10,.95)':'rgba(245,240,225,.95)';
  HVCTX.strokeStyle=isSel?'#d06010':'#336699'; HVCTX.lineWidth=0.8;
  HVCTX.fill(); HVCTX.stroke();
  HVCTX.fillStyle=isSel?'#fff':'#336699';
  HVCTX.fillText(txt,0,0);
  HVCTX.restore();

  /* Dimension line */
  var ep1={x:lx-Math.cos(mAng)*totLen*.46, y:ly-Math.sin(mAng)*totLen*.46};
  var ep2={x:lx+Math.cos(mAng)*totLen*.46, y:ly+Math.sin(mAng)*totLen*.46};
  HVCTX.strokeStyle='#336699'; HVCTX.lineWidth=0.8*z; HVCTX.setLineDash([3,2]);
  HVCTX.beginPath(); HVCTX.moveTo(spts[0].x,spts[0].y); HVCTX.lineTo(ep1.x,ep1.y); HVCTX.stroke();
  HVCTX.beginPath(); HVCTX.moveTo(spts[spts.length-1].x,spts[spts.length-1].y); HVCTX.lineTo(ep2.x,ep2.y); HVCTX.stroke();
  HVCTX.setLineDash([]);
  HVCTX.beginPath(); HVCTX.moveTo(ep1.x,ep1.y); HVCTX.lineTo(ep2.x,ep2.y); HVCTX.stroke();
  function hvArr(px2,py2,a2){
    var s=7*z,a1=a2+2.65,a3=a2-2.65;
    HVCTX.beginPath(); HVCTX.moveTo(px2,py2); HVCTX.lineTo(px2+Math.cos(a1)*s,py2+Math.sin(a1)*s);
    HVCTX.moveTo(px2,py2); HVCTX.lineTo(px2+Math.cos(a3)*s,py2+Math.sin(a3)*s); HVCTX.stroke();
  }
  hvArr(ep1.x,ep1.y,Math.atan2(ep2.y-ep1.y,ep2.x-ep1.x)+Math.PI);
  hvArr(ep2.x,ep2.y,Math.atan2(ep1.y-ep2.y,ep1.x-ep2.x)+Math.PI);
}

/* ── Draw connector node ── */
function hvDrawNode(node){
  var s=hw2s(node.x,node.y);
  var isSel=(H.sel&&H.sel.id===node.id);
  var lib=CL[node.connId];
  var z=H.zoom;

  if(node.isJunction){
    HVCTX.shadowColor='rgba(0,0,0,.4)'; HVCTX.shadowBlur=5*z;
    HVCTX.beginPath(); HVCTX.arc(s.x,s.y,9*z,0,Math.PI*2);
    HVCTX.fillStyle=isSel?'#b85810':'#282010'; HVCTX.fill();
    HVCTX.strokeStyle=isSel?'#e08020':'#806840'; HVCTX.lineWidth=1.2; HVCTX.stroke();
    HVCTX.shadowBlur=0;
    HVCTX.fillStyle='#f0e0c0'; HVCTX.font='bold '+(7.5*z)+'px \'Courier New\'';
    HVCTX.textAlign='center'; HVCTX.fillText(node.label||'J',s.x,s.y+2.8*z);
    return;
  }
  if(!lib) return;

  var ang=(node.angle||0)*Math.PI/180;
  var bw=Math.max(24,Math.min(42,20+lib.pins*1.1))*z;
  var bh=Math.max(18,Math.min(38,12+lib.pins*1.7))*z;

  HVCTX.save(); HVCTX.translate(s.x,s.y); HVCTX.rotate(ang);
  HVCTX.shadowColor='rgba(0,0,0,.45)'; HVCTX.shadowBlur=8*z; HVCTX.shadowOffsetY=2*z;

  var g=HVCTX.createLinearGradient(-bw/2,-bh/2,bw/2,bh/2);
  g.addColorStop(0,'#a8a090'); g.addColorStop(.4,'#c0b8a8'); g.addColorStop(.6,'#b0a898'); g.addColorStop(1,'#686058');
  HVCTX.fillStyle=g; HVCTX.strokeStyle=isSel?'#c07030':'#504840'; HVCTX.lineWidth=isSel?2*z:1*z;
  hvRR(HVCTX,-bw/2,-bh/2,bw,bh,3*z); HVCTX.fill(); HVCTX.stroke();
  HVCTX.shadowBlur=0; HVCTX.shadowOffsetY=0;

  var ig=HVCTX.createLinearGradient(-bw*.4,-bh*.38,bw*.4,bh*.38);
  ig.addColorStop(0,'#352c20'); ig.addColorStop(1,'#181008');
  HVCTX.fillStyle=ig; HVCTX.strokeStyle='#100808'; HVCTX.lineWidth=0.7*z;
  hvRR(HVCTX,-bw*.42,-bh*.4,bw*.84,bh*.8,2*z); HVCTX.fill(); HVCTX.stroke();

  /* Keying tab */
  HVCTX.fillStyle='#807060'; HVCTX.strokeStyle='#585040'; HVCTX.lineWidth=0.7*z;
  hvRR(HVCTX,-bw*.24,-bh/2-4*z,bw*.48,5*z,2*z); HVCTX.fill(); HVCTX.stroke();

  /* Pin dots with color from IEC standard if available */
  var cols=Math.ceil(Math.sqrt(lib.pins)), rows=Math.ceil(lib.pins/cols);
  var cw2=bw*.84/cols, ch2=bh*.8/rows, dr=Math.max(1.5,Math.min(3.8,cw2*.32));
  lib.pinout.forEach(function(pp,i){
    var c=i%cols, r=Math.floor(i/cols);
    var px=-bw*.42+cw2*(c+.5), py=-bh*.4+ch2*(r+.5);
    HVCTX.beginPath(); HVCTX.arc(px,py,dr,0,Math.PI*2);
    HVCTX.fillStyle=sc(pp.c); HVCTX.fill();
    HVCTX.strokeStyle='rgba(0,0,0,.6)'; HVCTX.lineWidth=.4*z; HVCTX.stroke();
  });

  /* Selection dashes */
  if(isSel){
    HVCTX.strokeStyle='rgba(200,120,40,.7)'; HVCTX.lineWidth=2*z;
    HVCTX.setLineDash([4*z,3*z]);
    hvRR(HVCTX,-bw/2-4*z,-bh/2-4*z,bw+8*z,bh+8*z,5*z); HVCTX.stroke();
    HVCTX.setLineDash([]);
  }
  HVCTX.restore();

  /* Labels below (unrotated) */
  HVCTX.fillStyle='#111';
  HVCTX.font='bold '+(8.5*z)+'px \'Courier New\'';
  HVCTX.textAlign='center';
  HVCTX.fillText(node.label||'?', s.x, s.y+bh/2+12*z);
  HVCTX.fillStyle='#555';
  HVCTX.font=(6.5*z)+'px \'Courier New\'';
  HVCTX.fillText(lib.short, s.x, s.y+bh/2+21*z);

  /* Pin table popup when selected */
  if(isSel) hvPinPopup(node,s,bw,bh,lib,z);
}

/* ── Pin table popup ── */
function hvPinPopup(node,s,bw,bh,lib,z){
  var ang=(node.angle||0)*Math.PI/180;
  var cx=s.x+Math.cos(ang)*(bw*.5+14*z)+14;
  var cy=s.y+Math.sin(ang)*(bw*.5+14*z);
  var cw=190*z, rh=12*z, hh=16*z, ch=hh+(lib.pinout.length+1)*rh+8*z;
  if(cx+cw>HVC.width-10) cx=s.x-cw-20;
  cy=Math.max(5,Math.min(HVC.height-ch-5,cy));

  HVCTX.shadowColor='rgba(0,0,0,.35)'; HVCTX.shadowBlur=8*z;
  HVCTX.fillStyle='#faf7ee'; HVCTX.strokeStyle='#c07030'; HVCTX.lineWidth=1.2;
  hvRR(HVCTX,cx,cy,cw,ch,4*z); HVCTX.fill(); HVCTX.stroke(); HVCTX.shadowBlur=0;

  HVCTX.fillStyle='#336699';
  hvRR(HVCTX,cx,cy,cw,hh,4*z); HVCTX.fill();
  HVCTX.fillStyle='#fff'; HVCTX.font='bold '+(7*z)+'px \'Courier New\''; HVCTX.textAlign='center';
  HVCTX.fillText((node.label||'?')+' — '+lib.short+' ('+lib.pins+'P)', cx+cw/2, cy+11*z);

  var cxs=[cx+3*z,cx+22*z,cx+64*z,cx+104*z,cx+130*z,cx+154*z];
  ['#','NAME','SIG','AWG','C','→TO'].forEach(function(h,i){
    HVCTX.fillStyle='#7a6040'; HVCTX.font=(5.5*z)+'px \'Courier New\'';
    HVCTX.textAlign='left'; HVCTX.fillText(h,cxs[i],cy+hh+8*z);
  });
  HVCTX.strokeStyle='#ddd'; HVCTX.lineWidth=.5;
  HVCTX.beginPath(); HVCTX.moveTo(cx+2,cy+hh+10*z); HVCTX.lineTo(cx+cw-2,cy+hh+10*z); HVCTX.stroke();

  lib.pinout.forEach(function(pp,i){
    var ry=cy+hh+rh*(i+2);
    if(i%2===0){HVCTX.fillStyle='rgba(0,0,0,.04)';HVCTX.fillRect(cx,ry-rh+2*z,cw,rh);}
    var wfp=null;
    S.wires.forEach(function(w){
      if((w.fromEl===node.id&&String(w.fromPin)===String(pp.id))||(w.toEl===node.id&&String(w.toPin)===String(pp.id)))wfp=w;
    });
    var toPin='—';
    if(wfp){
      var oe=null; S.elements.forEach(function(e){if(e.id===(wfp.fromEl===node.id?wfp.toEl:wfp.fromEl))oe=e;});
      toPin=(oe?oe.label:'?')+'.'+( wfp.fromEl===node.id?wfp.toPin:wfp.fromPin);
    }
    HVCTX.fillStyle='#1a1208'; HVCTX.font=(6*z)+'px \'Courier New\''; HVCTX.textAlign='left';
    HVCTX.fillText(String(pp.id),cxs[0],ry);
    HVCTX.fillText(pp.n.substring(0,6),cxs[1],ry);
    HVCTX.fillText((wfp?wfp.signal||pp.sig:pp.sig).substring(0,5),cxs[2],ry);
    HVCTX.fillText(pp.g.substring(0,5),cxs[3],ry);

    /* Color swatch — handle combo colors */
    var wc1=wfp?wfp.color:pp.c, wc2=wfp?wfp.color2:null;
    if(wc2){
      HVCTX.fillStyle=sc(wc1);
      HVCTX.fillRect(cxs[4],ry-3.5*z,4*z,7*z);
      HVCTX.fillStyle=sc(wc2);
      HVCTX.fillRect(cxs[4]+4*z,ry-3.5*z,4*z,7*z);
    } else {
      HVCTX.beginPath(); HVCTX.arc(cxs[4]+4*z,ry-3.5*z,3.5*z,0,Math.PI*2);
      HVCTX.fillStyle=sc(pp.c); HVCTX.fill();
      HVCTX.strokeStyle='#aaa'; HVCTX.lineWidth=.4; HVCTX.stroke();
    }
    HVCTX.fillStyle='#336699'; HVCTX.font='bold '+(5.5*z)+'px \'Courier New\'';
    HVCTX.fillText(toPin.substring(0,9),cxs[5],ry);
  });
}

/* ── Rounded rect helper ── */
function hvRR(ctx,x,y,w,h,r){
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.quadraticCurveTo(x+w,y,x+w,y+r);
  ctx.lineTo(x+w,y+h-r); ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
  ctx.lineTo(x+r,y+h); ctx.quadraticCurveTo(x,y+h,x,y+h-r);
  ctx.lineTo(x,y+r); ctx.quadraticCurveTo(x,y,x+r,y); ctx.closePath();
}

/* ════════════════════════════════════════════════════════════
   HIT TESTING
   ════════════════════════════════════════════════════════════ */
function hvHitNode(wx,wy){
  for(var i=H.nodes.length-1;i>=0;i--){
    var n=H.nodes[i];
    if(n.isJunction){if(hvDist(wx,wy,n.x,n.y)<14/H.zoom)return n;continue;}
    var lib=CL[n.connId];if(!lib)continue;
    var bw=Math.max(24,Math.min(42,20+lib.pins*1.1)),bh=Math.max(18,Math.min(38,12+lib.pins*1.7));
    var ang=(n.angle||0)*Math.PI/180,dx=wx-n.x,dy=wy-n.y;
    var lx=dx*Math.cos(-ang)-dy*Math.sin(-ang),ly=dx*Math.sin(-ang)+dy*Math.cos(-ang);
    if(Math.abs(lx)<bw/2+10&&Math.abs(ly)<bh/2+25)return n;
  }
  return null;
}
function hvHitSeg(wx,wy){
  for(var i=0;i<H.segs.length;i++){
    var s=H.segs[i],n1=hvNById(s.from),n2=hvNById(s.to);if(!n1||!n2)continue;
    var pts=hvGetPath(s,n1,n2),th=(hvSegThick(s)/H.zoom)+5;
    for(var j=0;j<pts.length-1;j++) if(hvPSD(wx,wy,pts[j].x,pts[j].y,pts[j+1].x,pts[j+1].y)<th)return s;
  }
  return null;
}
function hvHitBend(wx,wy){
  if(!H.sel||H.sel.type!=='seg')return null;
  var s=hvSById(H.sel.id);if(!s||!s.pts)return null;
  for(var i=0;i<s.pts.length;i++) if(hvDist(wx,wy,s.pts[i].x,s.pts[i].y)<10/H.zoom) return{segId:s.id,ptIdx:i};
  return null;
}

/* ════════════════════════════════════════════════════════════
   PROPERTIES BAR
   ════════════════════════════════════════════════════════════ */
function hvShowProps(html){var pb=document.getElementById('hv-props');if(pb)pb.innerHTML=html;}

function hvNodeProps(nd){
  var lib=CL[nd.connId];
  hvShowProps('<span style="color:var(--accent);font-weight:bold">'+(nd.isJunction?'JUNCTION':'CONNECTOR')+'</span>&nbsp;'
    +'<span style="color:#c8c8c8">'+esc(nd.label||'?')+'</span>&nbsp;&nbsp;'
    +(lib?'<span style="color:#887040">'+esc(lib.name)+' | '+lib.pins+'P</span>&nbsp;&nbsp;':'')
    +(!nd.isJunction
      ?'<span style="color:#505050">ANGLE:</span>&nbsp;'
        +'<input type="number" value="'+(nd.angle||0).toFixed(0)+'" min="-360" max="360" step="15" '
        +'style="width:50px;background:#120e04;border:1px solid #4a3010;color:var(--accent);padding:2px 4px;font-family:monospace;font-size:9px" '
        +'oninput="hvSetAngle(\''+nd.id+'\',+this.value)"/>&deg;&nbsp;&nbsp;':'')
    +(nd.isJunction?'<button onclick="hvDelJunction(\''+nd.id+'\')" style="background:none;border:1px solid #3a1010;color:var(--red);cursor:pointer;padding:2px 7px;font-family:monospace;font-size:8px">\xd7 DELETE</button>':''));
}

function hvSegProps(seg){
  var n1=hvNById(seg.from),n2=hvNById(seg.to),wc='';
  (seg.wires||[]).slice(0,8).forEach(function(wid){
    S.wires.forEach(function(w){
      if(w.id===wid){
        if(w.color2){
          wc+='<span style="display:inline-flex;width:18px;height:9px;border-radius:2px;overflow:hidden;margin:0 1px;vertical-align:middle">'
            +'<span style="flex:1;background:'+sc(w.color)+'"></span>'
            +'<span style="flex:1;background:'+sc(w.color2)+'"></span></span>';
        } else {
          wc+='<span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:'+sc(w.color||'#888')+';margin:0 1px;vertical-align:middle"></span>';
        }
      }
    });
  });
  hvShowProps('<span style="color:var(--accent);font-weight:bold">CABLE</span>&nbsp;'
    +'<span style="color:#887040">'+(n1?n1.label:'?')+' \u2194 '+(n2?n2.label:'?')+'</span>&nbsp;'
    +wc+'&nbsp;<span style="color:#505050">'+(seg.wires||[]).length+'w</span>&nbsp;&nbsp;'
    +'<span style="color:#505050">LENGTH:</span>&nbsp;'
    +'<input type="number" value="'+seg.lengthMm+'" min="1" style="width:60px;background:#120e04;border:1px solid #4a3010;color:var(--accent);padding:2px 4px;font-family:monospace;font-size:9px" oninput="hvSetLen(\''+seg.id+'\',+this.value)"/>&nbsp;mm&nbsp;&nbsp;'
    +'<span style="color:#505050">LABEL:</span>&nbsp;'
    +'<input value="'+esc(seg.label||'')+'" style="width:70px;background:#120e04;border:1px solid #4a3010;color:var(--accent);padding:2px 4px;font-family:monospace;font-size:9px" placeholder="S1, TRUNK…" oninput="hvSetLabel(\''+seg.id+'\',this.value)"/>&nbsp;&nbsp;'
    +'<span style="color:#444;font-size:8px">Dbl-click cable = bend point</span>');
}

function hvSetAngle(id,v){H.nodes.forEach(function(n){if(n.id===id)n.angle=v;});hvDraw();}
function hvSetLen(id,v){H.segs.forEach(function(s){if(s.id===id)s.lengthMm=v||0;});hvDraw();}
function hvSetLabel(id,v){H.segs.forEach(function(s){if(s.id===id)s.label=v;});hvDraw();}

/* ════════════════════════════════════════════════════════════
   JUNCTION
   ════════════════════════════════════════════════════════════ */
function hvAddJunction(){
  if(!HVC) return;
  var c=hs2w(HVC.width/2,HVC.height/2);
  var cnt=H.nodes.filter(function(n){return n.isJunction;}).length;
  H.nodes.push({id:'J_'+uid(),label:'J'+(cnt+1),connId:null,x:c.x,y:c.y,angle:0,isJunction:true});
  hvDraw(); toast('Junction added');
}
function hvDelJunction(id){
  H.nodes=H.nodes.filter(function(n){return n.id!==id;});
  H.segs=H.segs.filter(function(s){return s.from!==id&&s.to!==id;});
  H.sel=null; hvDraw(); hvShowProps('Click a cable or connector');
}

/* ════════════════════════════════════════════════════════════
   MOUSE EVENTS
   ════════════════════════════════════════════════════════════ */
function hvMD(e){
  var rect=HVC.getBoundingClientRect();
  var sx=e.clientX-rect.left, sy=e.clientY-rect.top, w=hs2w(sx,sy);
  if(e.button===1||(e.altKey&&e.button===0)){
    hvPan={a:true,sx:sx,sy:sy,px:H.panX,py:H.panY}; HVC.style.cursor='grabbing'; return;
  }
  var bp=hvHitBend(w.x,w.y);
  if(bp){H.drag={type:'bend',segId:bp.segId,ptIdx:bp.ptIdx};HVC.style.cursor='grabbing';return;}
  var nd=hvHitNode(w.x,w.y);
  if(nd){H.sel={type:'node',id:nd.id};H.drag={type:'node',id:nd.id,ox:w.x-nd.x,oy:w.y-nd.y};HVC.style.cursor='grabbing';hvDraw();hvNodeProps(nd);return;}
  var sg=hvHitSeg(w.x,w.y);
  if(sg){H.sel={type:'seg',id:sg.id};H.drag=null;hvDraw();hvSegProps(sg);return;}
  H.sel=null;H.drag=null;hvShowProps('Click a cable or connector');hvDraw();
}
function hvMM(e){
  var rect=HVC.getBoundingClientRect();
  var sx=e.clientX-rect.left, sy=e.clientY-rect.top, w=hs2w(sx,sy);
  if(hvPan.a){H.panX=hvPan.px+(sx-hvPan.sx);H.panY=hvPan.py+(sy-hvPan.sy);hvDraw();return;}
  if(H.drag){
    if(H.drag.type==='node') H.nodes.forEach(function(n){if(n.id===H.drag.id){n.x=w.x-H.drag.ox;n.y=w.y-H.drag.oy;}});
    else if(H.drag.type==='bend'){var s=hvSById(H.drag.segId);if(s&&s.pts)s.pts[H.drag.ptIdx]={x:w.x,y:w.y};}
    hvDraw(); return;
  }
  if(hvHitBend(w.x,w.y)){HVC.style.cursor='crosshair';return;}
  if(hvHitNode(w.x,w.y)){HVC.style.cursor='grab';return;}
  HVC.style.cursor=hvHitSeg(w.x,w.y)?'pointer':'default';
}
function hvMU(){hvPan.a=false;H.drag=null;HVC.style.cursor='default';}
function hvMW(e){
  e.preventDefault();
  var rect=HVC.getBoundingClientRect();
  var sx=e.clientX-rect.left, sy=e.clientY-rect.top;
  var f=e.deltaY<0?1.12:.89, nz=Math.max(.08,Math.min(5,H.zoom*f));
  H.panX=sx-(sx-H.panX)*(nz/H.zoom); H.panY=sy-(sy-H.panY)*(nz/H.zoom); H.zoom=nz; hvDraw();
}
function hvDbl(e){
  var rect=HVC.getBoundingClientRect();
  var w=hs2w(e.clientX-rect.left,e.clientY-rect.top);
  var sg=hvHitSeg(w.x,w.y);
  if(sg){if(!sg.pts)sg.pts=[];sg.pts.push({x:w.x,y:w.y});H.sel={type:'seg',id:sg.id};hvDraw();hvSegProps(sg);return;}
  var nd=hvHitNode(w.x,w.y);
  if(nd&&nd.isJunction){var v=prompt('Label:',nd.label||'J');if(v!==null){nd.label=v;hvDraw();}}
}
function hvResize(){
  if(!HVC)return;
  var wrap=document.getElementById('hv-wrap');if(!wrap)return;
  HVC.width=wrap.clientWidth||900;HVC.height=wrap.clientHeight||560;hvDraw();
}
window.addEventListener('resize',function(){hvResize();});
